# Validación de la entrega 0.4

Fecha: 2026-10-09.

- `npm run typecheck`: aprobado, TypeScript estricto.
- `npm run lint`: aprobado, ESLint con reglas TypeScript.
- `npm test`: 139 pruebas aprobadas en 20 archivos.
- `npm run build`: aprobado, compilación de producción Vite.
- `npm ci`: reproducible mediante el package-lock.json incluido; la instalación inicial fue `npm install`.
- Se realizó una petición HTTP GET real a `/api/v3/klines?symbol=BTCUSDT&interval=1h&limit=2` en `data-api.binance.vision`: HTTP 200 y dos velas OHLCV válidas. Sin API key. Esta observación no garantiza disponibilidad futura ni acceso desde todas las regiones.

## Pruebas ejecutadas

1. Normalización de timestamp, volumen y estado de cierre.
2. Rechazo de OHLC incoherente y valores no finitos.
3. Orden y deduplicación sin reabrir una vela cerrada.
4. Rechazo de actualizaciones obsoletas.
5. Detección de huecos.
6. Calendario mensual, año nuevo y febrero bisiesto UTC.
7. Restauración de preferencias/listas desde almacenamiento.
8. Lectura no destructiva de datos corruptos.
9. Rechazo de versión futura y referencia de lista inválida.
10. Copia previa del espacio antes de guardar.
11. WebSocket simulado: deduplicación, reconexión, recuperación y limpieza.
12. Rechazo de eventos de otro símbolo.
13. Integración React/TanStack Query: cambio de símbolo/temporalidad sin mezclar velas, argumentos de consulta correctos y liberación de suscripciones.
14. WebMCP simulado: registro, actualización de estado, rechazo de datos inválidos y cancelación.

Los fixtures sintéticos sólo existen en las pruebas. La aplicación no contiene un modo demo ni genera cotizaciones.

## Fase 2: pruebas añadidas

- 28 casos del motor: referencias numéricas para los 13 indicadores, validación de parámetros, actualización de barra abierta/cierre, reconstrucción de histórico y ausencia de lookahead.
- 4 casos de geometría, Fibonacci, relación riesgo/beneficio e historial acotado.
- 3 casos de almacenamiento de análisis, copia previa, validación y migración del archivo anterior.
- 3 casos de estado: deshacer/rehacer por mercado, ramificación del historial y aplicación de plantillas.

## Verificación manual en navegador

Sobre la SPA local, con datos reales de Binance Spot BTCUSDT 1h:

- Histórico cargado y estado En vivo, con actualizaciones de precio por WebSocket.
- Añadir SMA20 superpuesta y RSI14 en un panel independiente.
- Crear una tendencia con dos puntos, editar su etiqueta y arrastrar el objeto; comprobar el cambio de coordenadas en el inspector.
- Deshacer y rehacer la edición.
- Guardar una plantilla, recargar y comprobar persistencia de dos indicadores, un dibujo y la plantilla.
- Aplicar la plantilla y comprobar el espacio restaurado.

Captura: [docs/phase2-qa.jpg](docs/phase2-qa.jpg). Se corrigieron durante la revisión el generador de identificadores en HTTP, el encuadre inicial al llegar primero una barra del WebSocket y la posición de los diálogos.

## Fase 3: verificación adicional

- 50 casos de lexer/parser/compilador e intérprete: posiciones, precedencia, funciones/argumentos desconocidos, fórmulas SMA/EMA/ATR/RSI/MACD, histórico, var/reasignación, cruces, parámetros, na, diferencias v5/v6, barra abierta, ausencia de lookahead y límites.
- 5 casos del cliente Worker con simulación: respuesta correcta, identidad de trabajo, terminación por timeout/error/cancelación y no arranque de trabajo abortado.
- 3 casos de almacenamiento: fuente original, colección, copia previa, corrupción y esquema.
- Integración de cambio de mercado: cancela la solicitud antigua, ignora su respuesta tardía y retira el script.
- 2 casos del editor: importar sin ejecutar y conservar el original al guardar cambios; mantener la instantánea ante nuevas velas y añadir/retirar resultados.
- Los 52 tests anteriores siguen pasando. Typecheck, lint y build 0.3 aprobados. Vite generó un archivo Worker separado.

En navegador se validó y ejecutó el ejemplo SMA/cruce sobre 500 velas reales, se aplicó a la gráfica y se comprobó persistencia al recargar. `request.security` se rechazó con diagnóstico L3:5. MACD produjo tres series en un panel independiente; se cambió de 1h a 4h y se observó el recálculo. El parámetro SMA se cambió de 20 a 1 y la vista previa devolvió los cierres correspondientes. Se corrigió la invalidación prematura de la instantánea al recibir ticks y se añadió una prueba de regresión. Captura: [docs/phase3-qa.jpg](docs/phase3-qa.jpg).

## Fase 4: verificación adicional

- 13 pruebas del evaluador: umbrales, cruces, variación, cierre, expiración, snapshots, scripts, huecos, deduplicación y omisión de cierres no observados; interpolación de líneas consistente con el eje lógico de la gráfica.
- 2 pruebas React del ciclo de alertas: disparo único, cambios de mercado y reconexión sin reproducir históricos.
- 7 pruebas de estructura: confirmación retrasada, empates, huecos, causalidad, clasificación de rupturas, zonas FVG, barridos y sesión que cruza medianoche.
- 2 pruebas del almacenamiento del monitor, una de pivotes y una de integración del formulario (comprobar sin disparar, crear, editar y pausar).

Revisión manual con Binance Spot BTCUSDT 1m: se armó una regla de prueba «cierre > 0», deliberadamente siempre verdadera para verificar el flujo. La comprobación histórica no creó eventos. Al cierre recibido por WebSocket se registró exactamente un evento a las 22:26:00 UTC del 2026-10-09, correspondiente a la vela de las 22:25, con cierre 82534.01. La regla quedó Disparada (una vez); estado e historial persistieron después de recargar. No es una recomendación de trading ni un precio simulado. Captura: [docs/phase4-alerts-qa.jpg](docs/phase4-alerts-qa.jpg).

Se verificaron visualmente las marcas de estructura sobre velas reales y la carga de ambos paneles D/W, con periodo actual provisional y anterior cerrado. Esto no sustituye una suite visual automatizada ni una comparación con otra plataforma.

## Límites de la verificación

- La revisión de navegador fue manual; no se incorporó una suite end-to-end automatizada.
- No se probaron visualmente todas las combinaciones de las 14 herramientas, todos los pares ni tamaños móviles.
- No se validó WebMCP en una implementación real de navegador.
- Sólo se verificó el subconjunto Pine documentado. Funciones/bloques/MTF/fondos/rellenos/backtesting, funciones Pine de alertas y agregación de intervalos derivados no están implementados ni probados.
- La terminación por timeout se prueba con Worker simulado; la ejecución ordinaria del Worker sí se verificó en navegador. No hay comparación automática con TradingView ni auditoría externa del intérprete.
- La importación de archivos se verificó mediante integración del editor con File de prueba; la revisión manual usó ejemplos y scripts guardados. No se probaron todos los flujos de archivo en todos los navegadores.
- No se realizó auditoría de seguridad, prueba de carga ni prueba con todas las regiones o dispositivos.
- El build y las pruebas no equivalen a una certificación de uso financiero en producción.
