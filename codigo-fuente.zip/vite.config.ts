import { defineConfig } from "vite";
import react from "@vitejs/plugin-react";
import tailwindcss from "@tailwindcss/vite";
export default defineConfig({
  base: "./",
  plugins: [react(), tailwindcss()],
  build: {
    rollupOptions: {
      output: { manualChunks: { "financial-chart": ["lightweight-charts"] } },
    },
  },
  server: { host: "0.0.0.0", port: 4173, allowedHosts: ["terminal.local"] },
});
