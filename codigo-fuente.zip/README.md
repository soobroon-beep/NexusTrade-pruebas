# CRIPTO CHART TERMINAL

Terminal independiente para Binance Spot. **Entrega 0.4: Fases 1 y 2, subconjunto Pine de la Fase 3 y monitor local de la Fase 4**. No es una implementación completa de las cinco fases. Importa y ejecuta un subconjunto documentado de Pine v5/v6; no transmite órdenes. Todos los controles disponibles tienen una función implementada. Las fases posteriores están documentadas, no representadas por botones inertes.

## Arranque local

Requiere Node.js 22 LTS y npm. No requiere cuenta, API key, base de datos ni servicios de pago.

```bash
npm ci
npm run dev
```

Abrir `http://localhost:4173`. La autenticación de la URL privada alojada pertenece al alojamiento, no al terminal local.

```bash
npm run typecheck
npm run lint
npm test
npm run build
npm run preview
```

`dist/` es una SPA estática desplegable. No hay rutas secundarias. No se requieren variables de entorno. **Nunca añadir claves de exchange al frontend**. `.env.example` documenta esta decisión.

## Funciones implementadas

- Binance Spot: catálogo dinámico de pares activos; históricos de 500 velas por página.
- Temporalidades nativas: 1m, 3m, 5m, 15m, 30m, 1h, 2h, 4h, 6h, 8h, 12h, 1d, 3d, 1w, 1M. No se agregan intervalos derivados.
- Velas japonesas, barras OHLC, línea y área; volumen en un panel independiente; cursor con OHLCV, zoom, desplazamiento y ajuste del historial.
- Carga de páginas antiguas mediante botón o al desplazar la gráfica al inicio del historial. Conserva la posición visible al anteponer barras.
- WebSocket para velas del activo seleccionado, deduplicación por timestamp del evento, limpieza de conexiones al cambiar contexto, reconexión exponencial con jitter y detección de flujo inactivo.
- Seguimiento: varias listas, crear/renombrar/eliminar, añadir/quitar pares, subir posiciones, orden alfabético o por variación, filtro. Máximo 20 listas y 20 símbolos por lista. Estadísticas REST cada 30 segundos, no ticks en vivo en las filas.
- Persistencia local versionada de listas, símbolo, intervalo, tipo de gráfico, volumen y visibilidad de paneles. Copia previa bajo la clave `.backup`; importación y exportación JSON con validación. Exportación OHLCV CSV.
- Seguimiento redimensionable en escritorio, paneles ocultables, diseño adaptable a móvil. Atajos `/`, `Alt+W`, `Esc`.
- API WebMCP opcional `select_market`, detectada por capacidad del navegador. Utiliza el mismo estado y validación del catálogo. Probada con un registro simulado; no validada en navegador con WebMCP real.

## Fase 2: análisis y espacios de trabajo

- Registro de 13 indicadores: SMA, EMA, WMA, VWAP diario UTC, Bollinger Bands, ATR, RSI, MACD, Stochastic, volumen, OBV, Supertrend y cruces de dos SMA. Hasta 16 instancias, incluidas repetidas; parámetros validados, color principal, grosor, visibilidad, eliminación y orden editables. Colores secundarios y bajistas predefinidos.
- Superpuestos sobre precio y osciladores en paneles independientes; altura configurable entre 90 y 300 px por instancia. El ajuste numérico se guarda; el arrastre nativo del separador no actualiza esa preferencia.
- 14 dibujos: tendencia, rayo, horizontal, vertical, rectángulo, canal paralelo, flecha, texto, medición, retroceso Fibonacci, extensión Fibonacci, máximos/mínimos del rango y posiciones long/short. Estas últimas son mediciones, nunca órdenes.
- Objetos con coordenadas tiempo/precio por símbolo y temporalidad. Seleccionar, arrastrar objeto o anclas, editar coordenadas y estilo, duplicar, bloquear, ocultar y borrar. Deshacer/rehacer hasta 50 estados por mercado durante la sesión.
- Hasta 20 plantillas: guardar espacio completo, aplicar, renombrar, duplicar, eliminar, importar y exportar JSON. Incluyen seguimiento, preferencias, indicadores y dibujos.

Abra **Indicadores** para añadir y configurar instancias. El selector de dibujos indica el número de puntos: haga clic en las velas para fijarlos; `Esc` cancela. En **Objetos**, edite o seleccione un dibujo; `Delete` elimina la selección desbloqueada. `Ctrl/Cmd+Z` deshace y `Ctrl/Cmd+Shift+Z` rehace fuera de campos de entrada. Los dibujos se limitan al panel de precios y se anclan inicialmente a barras cargadas. Máximos/mínimos usan sólo el histórico cargado del rango seleccionado.

La clave original `workspace.v1` se conserva. El análisis tiene su propio esquema `analysis.v1`, con copia previa y lectura no destructiva de datos inválidos. El archivo de espacio completo usa versión 2; se aceptan archivos anteriores de versión 1 con análisis vacío. Aplicar una plantilla sustituye el espacio actual y mantiene la colección de plantillas. Las importaciones se validan con Zod y tienen un límite de 5 MB. No hay sincronización entre dispositivos.

Consulte [las fórmulas y la guía de extensión](docs/INDICATORS.md). No se afirma equivalencia matemática exacta con TradingView.

## Fase 3: editor y motor parcial

Editor con resaltado, numeración, sugerencias (Ctrl/Cmd+Espacio), errores con línea/columna, importación de texto, guardado, duplicación y exportación de código/original/colección. Primero valide, revise el informe y calcule una vista previa; después añada el script a la gráfica. Hasta 30 guardados y uno activo con 16 salidas. El original importado se conserva. Las colecciones de scripts se exportan **por separado** de las plantillas anteriores.

El intérprete propio corre en un Worker con límites y cancelación. Implementa series e histórico, variables globales y persistentes, operadores, condiciones ternarias, parámetros, siete funciones `ta.*`, líneas, histogramas, niveles y formas. No ejecuta JavaScript importado ni expone APIs del navegador.

**No es compatibilidad completa:** funciones del usuario, bloques, loops, MTF, fondos/rellenos, órdenes, backtesting y funciones Pine de alertas quedan pendientes. `strategy()` sólo declara análisis visual y muestra una advertencia. Consulte la [matriz exacta y las diferencias semánticas](docs/PINE_COMPATIBILITY.md) antes de importar un indicador. Los casos incompatibles se rechazan sin eliminar condiciones.

## Fase 4: monitor local

Abra **Alertas** para crear reglas de precio, variación entre cierres, umbrales de indicadores, cruces de medias, cruces de dibujos y salidas del script activo. Incluye edición, pausa, expiración UTC, frecuencia, historial persistente y comprobación histórica sin disparos. Sólo evalúa nuevos cierres del mercado seleccionado con conexión en vivo; no funciona con la aplicación cerrada ni recupera alertas perdidas.

**Estructura** permite activar swings confirmados, soporte/resistencia, rupturas, BOS/CHoCH, barridos, FVG, bloques definidos por algoritmo y rangos de sesión UTC. **Niveles D/W** consulta velas diarias/semanales reales y calcula pivotes del último periodo cerrado. No hay métricas Futures ni señales institucionales.

La configuración, reglas e historial tienen almacenamiento y exportación propios, separados de las plantillas y scripts. Las reglas importadas quedan pausadas. Consulte [algoritmos, uso y límites del monitor](docs/MONITOR.md).

## Arquitectura

```text
src/
  domain/      Tipos, deduplicación, calendario UTC y detección de huecos
  market/      Adaptador Binance, validación Zod, cola REST y ciclo de datos
  alerts/      Reglas, evaluación de cierres y ciclo local
  structure/   Algoritmos causales y zonas descriptivas
  pine/        Lexer, parser/AST, validación, intérprete, Worker y ejemplos
  indicators/  Registro, validación y motor incremental de 13 indicadores
  drawings/    Modelos de objetos, geometría e historial
  storage/     Esquemas versionados, copias e importación validada
  state/       Estado Zustand y puente opcional WebMCP
  components/  Instancia y series Lightweight Charts
  App.tsx      Pantalla, listas, controles, información y exportaciones
```

React + TypeScript estricto + Vite; Zustand para preferencias; TanStack Query para caché por símbolo/intervalo y cancelación de consultas; Zod en respuestas y almacenamiento; Tailwind CSS v4 y CSS de componentes; Vitest y Testing Library. Se preserva una instancia del gráfico por montaje; las series se reemplazan al cambiar el tipo. Observadores y suscripciones se liberan al desmontar.

La interfaz `MarketAdapter` expone catálogo, velas, estadísticas y suscripción de velas. La suscripción de trades será una extensión futura: no se publicita como disponible. Añadir otro proveedor requiere implementar la interfaz con su normalización propia, sin cambiar las reglas de origen del dato.

## Fuentes reales y fallos

- REST primario: `https://data-api.binance.vision/api/v3/`
- REST secundario: `https://api.binance.com/api/v3/`
- WebSocket: `wss://data-stream.binance.vision/ws/{symbol}@kline_{interval}`
- Documentación oficial: https://github.com/binance/binance-spot-api-docs/blob/master/faqs/market_data_only.md
- Streaming: https://github.com/binance/binance-spot-api-docs/blob/master/web-socket-streams.md
- Gráficos y licencia: https://tradingview.github.io/lightweight-charts/docs/

El fallback REST se intenta tras errores de red o HTTP del endpoint primario. No se intenta eludir HTTP 451, 418 o 429. Ante límites, una cola compartida espera al menos 60 segundos o `Retry-After`; serializa consultas y espacia inicios al menos 500 ms. Las peticiones tienen timeout de 12 s y cancelación. No hay ninguna fuente simulada ni datos de relleno.

Cada vela conserva fuente y recepción; `time` está en segundos UTC, `closeTime` en milisegundos. El estado de cierre histórico usa el reloj local y el tiempo de cierre del proveedor; el WebSocket usa `k.x`. Un reloj de dispositivo incorrecto afecta la clasificación del histórico. La barra en formación está identificada. Los precios de 24h y la vela actual tienen distintos instantes de actualización.

Al reconectar se invalidan las páginas cargadas. Si no hay WebSocket, se consulta REST cada 30 s y se informa de ausencia de flujo en vivo. Los huecos se detectan por el calendario nativo (incluido mensual), se solicita recuperación y se mantiene el aviso si persisten; no se inventan velas para rellenarlos. Todavía no hay reparación selectiva de cada rango faltante. No hay caché duradera de velas: tras recargar se necesita acceso al proveedor. No hay sincronización entre pestañas/dispositivos.

## Validación

Consultar `VALIDATION.md` para los resultados ejecutados y sus límites. Las pruebas incluyen normalización, deduplicación, huecos, límites temporales mensuales, reconexión simulada, liberación de WebSockets, persistencia, entradas inválidas y cambio de símbolo/temporalidad.

## Pendientes explícitos

Consultar `ROADMAP.md`. Los indicadores, dibujos y plantillas ya están disponibles. La ejecución Pine sólo admite el subconjunto de la matriz; las construcciones restantes siguen pendientes. No hay backend, multiusuario, autenticación propia, órdenes ni alertas en servidor. El código importado se interpreta con lexer/parser reales y no usa `eval`/`Function`.

## Licencias

Lightweight Charts™ es de TradingView, distribuido bajo Apache-2.0. Se conserva el encabezado del paquete y el enlace visible de atribución. Véase `THIRD_PARTY_NOTICES.md`. No existe afiliación ni equivalencia con TradingView/OpenMarket. Los datos están sujetos a la disponibilidad, restricciones regionales y condiciones del proveedor. El código fuente del proyecto es original; las dependencias conservan sus licencias.
