# Alcance y siguientes fases

## Fase 1: entregada, con límites explícitos

Gráficos reales, Binance Spot, seguimiento y persistencia. Pendientes dentro del endurecimiento de esta fase: reparación selectiva de huecos, presupuesto de peso por endpoint, caché persistente de históricos, integración de suscripción de trades, suite visual automatizada, historial muy extenso con almacenamiento por segmentos, sparklines y favoritos independientes de listas. La reducción de uso CPU mediante `series.update()` se aplica a cambios de la última vela; operaciones de historial usan `setData()`.

## Fase 2: entregada, con límites explícitos

Registro y cálculo de 13 indicadores, múltiples instancias editables, paneles, 14 herramientas de dibujo con persistencia y undo/redo, plantillas e importación/exportación validada. Ver README y docs/INDICATORS.md.

Pendientes de optimización: actualización incremental de las series visuales de indicadores (el cálculo ya es incremental), colores independientes por salida y persistencia del arrastre nativo de separadores. La revisión manual cubre los flujos centrales, no todas las combinaciones de herramientas/dispositivos. Pivotes, sesiones y swings se incorporan en el monitor de la Fase 4.

## Fase 3: primer subconjunto implementado, ampliación pendiente

Editor, original intacto, colección persistente, importación/exportación, lexer con posiciones, parser/AST, comprobación de tipos y argumentos, intérprete en Worker, límites, vista previa y salidas en la gráfica. Admite v5/v6 parciales, input, plot/hline/plotshape/plotchar, variables y var, histórico, operadores/ternarios, SMA/EMA/RSI/ATR/MACD/cruces. Ver docs/PINE_COMPATIBILITY.md para semántica, diferencias y pruebas.

Aún no implementados: funciones del usuario, bloques if/else, loops, arrays, MTF/request.security, bgcolor/fill, estrategia/backtesting real y funciones Pine de alertas. Pendientes: más de un script activo, integración de scripts en plantillas y ejecución incremental. No se anuncia la Fase 3 como compatibilidad completa ni como cumplimiento de todo el alcance Pine original.

## Fase 4: monitor local implementado, alcance limitado

Alertas de precio, variación entre cierres, indicadores, medias, dibujos y salidas del script activo; deduplicación, expiración, historial y evaluación sobre cierres. Swings, soporte/resistencia, rupturas, BOS/CHoCH, barridos, FVG, bloques algorítmicos y sesiones UTC. Panel de niveles diarios/semanales y pivotes. Ver docs/MONITOR.md.

Pendientes: evaluación simultánea de varios mercados, coordinación entre pestañas, notificaciones del sistema, alertas nativas de estructura, cálculo incremental de estructura y alertas, inclusión del monitor en plantillas, MTF histórico y métricas Futures. Las reglas de scripts requieren la misma fuente y parámetros activos. No se afirma cumplimiento completo del alcance original.

## Fase 5: opcional, no implementada

Backend Node.js, PostgreSQL, autenticación segura, sincronización y servicio de evaluación continua. Sólo entonces se podrá ofrecer alertas con la pestaña cerrada.
