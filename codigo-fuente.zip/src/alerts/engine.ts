import { timeIndex } from "../domain/chartTime";
import { nextOpen, type Candle } from "../domain/types";
import { IndicatorEngine } from "../indicators/engine";
import type { Drawing } from "../drawings/model";
import type { Script } from "../storage/scripts";
import type { Result } from "../pine/runtime";
import { type AlertRule, type Comparison, type AlertEvent } from "./model";
export type Evaluation =
  | { ready: true; match: boolean; value: number; reference: number | null }
  | { ready: false; reason: string; pending?: boolean };
export function compare(
  value: number,
  previous: number | null,
  reference: number,
  priorReference: number,
  comparison: Comparison,
) {
  switch (comparison) {
    case "above":
      return value > reference;
    case "below":
      return value < reference;
    case "cross_up":
      return (
        previous !== null && previous <= priorReference && value > reference
      );
    case "cross_down":
      return (
        previous !== null && previous >= priorReference && value < reference
      );
  }
}
export function drawingPrice(
  d: Drawing,
  time: number,
  candles?: Candle[],
): number | null {
  const [a, b] = d.points;
  if (d.tool === "horizontal") return a.price;
  if (!b || a.time === b.time) return null;
  const min = Math.min(a.time, b.time),
    max = Math.max(a.time, b.time);
  if (d.tool === "trend" && !d.extend && (time < min || time > max))
    return null;
  if (d.tool === "ray" && (b.time > a.time ? time < a.time : time > a.time))
    return null;
  const x = (t: number) => (candles ? timeIndex(t, candles) : t);
  const price =
    a.price +
    ((b.price - a.price) * (x(time) - x(a.time))) / (x(b.time) - x(a.time));
  return Number.isFinite(price) ? price : null;
}
export function evaluateRule(
  rule: AlertRule,
  candles: Candle[],
  script?: { active?: Script; result?: Result; busy?: boolean },
): Evaluation {
  const closed = candles.filter((c) => c.closed),
    last = closed.at(-1),
    previous = closed.at(-2),
    c = rule.condition;
  if (!last || !previous)
    return { ready: false, reason: "Se requieren dos velas cerradas." };
  if (nextOpen(previous.time, rule.interval) !== last.time)
    return {
      ready: false,
      reason: "Hueco antes de la última vela; evaluación omitida.",
    };
  let value: number | null = last.close,
    prior: number | null = previous.close,
    reference = 0,
    priorReference = 0;
  if (c.kind === "price" || c.kind === "percent") {
    reference = priorReference = c.threshold;
    if (c.kind === "percent") {
      const older = closed.at(-3);
      if (
        !older ||
        previous.close === 0 ||
        older.close === 0 ||
        nextOpen(older.time, rule.interval) !== previous.time
      )
        return {
          ready: false,
          reason: "Variación sin tres cierres consecutivos.",
        };
      value = (last.close / previous.close - 1) * 100;
      prior = (previous.close / older.close - 1) * 100;
    }
  } else if (c.kind === "indicator" || c.kind === "cross") {
    let start = closed.length - 1;
    while (
      start > 0 &&
      nextOpen(closed[start - 1].time, rule.interval) === closed[start].time
    )
      start--;
    const rows = new IndicatorEngine(c.config).update(closed.slice(start));
    const now = rows.at(-1),
      prev = rows.at(-2);
    if (c.kind === "cross" && (!now || now.values.some((v) => v === null)))
      return { ready: false, reason: "Cruce de medias en calentamiento." };
    if (c.kind === "cross")
      return {
        ready: true,
        match: now?.signal === (c.direction === "up" ? 1 : -1),
        value: last.close,
        reference: null,
      };
    value = now?.values[c.output] ?? null;
    prior = prev?.values[c.output] ?? null;
    reference = priorReference = c.threshold;
  } else if (c.kind === "drawing") {
    const now = drawingPrice(c.drawing, last.time, candles),
      prev = drawingPrice(c.drawing, previous.time, candles);
    if (now === null || prev === null)
      return {
        ready: false,
        reason: "La vela está fuera del dominio temporal del dibujo.",
      };
    reference = now;
    priorReference = prev;
  } else {
    if (
      !script?.active ||
      script.active.id !== c.script.id ||
      script.active.source !== c.script.source ||
      JSON.stringify(script.active.parameters) !==
        JSON.stringify(c.script.parameters)
    )
      return {
        ready: false,
        reason:
          "Activa la misma fuente y parámetros del script guardado en la alerta.",
      };
    if (script.busy)
      return {
        ready: false,
        reason: "Esperando resultado del Worker para el cierre.",
        pending: true,
      };
    const plot = script.result?.plots.find((p) => p.id === c.output),
      point = plot?.points.find((p) => p.time === last.time),
      prev = plot?.points.find((p) => p.time === previous.time);
    if (!plot || !point?.closed)
      return {
        ready: false,
        reason: "Salida del script no disponible para este cierre.",
      };
    if (c.mode === "present")
      return {
        ready: true,
        match: point.value !== null && point.color !== "#00000000",
        value: point.value ?? 0,
        reference: null,
      };
    value = point.value;
    prior = prev?.closed ? prev.value : null;
    reference = priorReference = c.threshold;
  }
  if (
    value === null ||
    !Number.isFinite(value) ||
    !Number.isFinite(reference) ||
    !Number.isFinite(priorReference) ||
    (prior !== null && !Number.isFinite(prior))
  )
    return {
      ready: false,
      reason: "Sin valor válido: indicador en calentamiento o salida na.",
    };
  if (
    (c.comparison === "cross_up" || c.comparison === "cross_down") &&
    prior === null
  )
    return {
      ready: false,
      reason: "Falta el valor anterior para evaluar el cruce.",
    };
  return {
    ready: true,
    match: compare(value, prior, reference, priorReference, c.comparison),
    value,
    reference,
  };
}
export type Cursor = { revision: number; bar: number };
export function advanceAlert(
  rule: AlertRule,
  candles: Candle[],
  cursor: Cursor | undefined,
  now: number,
  script?: Parameters<typeof evaluateRule>[2],
): { cursor?: Cursor; event?: AlertEvent; message: string } {
  const last = candles.filter((c) => c.closed).at(-1);
  if (!last) return { cursor, message: "Esperando cierre." };
  const next = { revision: rule.updatedAt, bar: last.time };
  if (rule.status !== "armed")
    return {
      cursor: next,
      message: rule.status === "paused" ? "Pausada" : "Disparada (una vez).",
    };
  if (now >= rule.expiresAt) return { cursor: next, message: "Expirada." };
  if (!cursor || cursor.revision !== rule.updatedAt)
    return {
      cursor: next,
      message: "Armada desde este cierre; no reproduce el historial.",
    };
  if (last.time <= cursor.bar)
    return { cursor, message: "Esperando el siguiente cierre." };
  if (nextOpen(cursor.bar, rule.interval) !== last.time)
    return {
      cursor: next,
      message:
        "Cierres no observados: referencia reiniciada, sin recuperar disparos.",
    };
  if (last.closeTime < rule.createdAt || last.closeTime >= rule.expiresAt)
    return { cursor: next, message: "Cierre fuera de vigencia." };
  const evaluation = evaluateRule(rule, candles, script);
  if (!evaluation.ready)
    return {
      cursor: evaluation.pending ? cursor : next,
      message: evaluation.reason,
    };
  if (!evaluation.match)
    return { cursor: next, message: "Último cierre: condición no cumplida." };
  return {
    cursor: next,
    message: "Condición cumplida al cierre.",
    event: {
      id: rule.id + ":" + last.time,
      ruleId: rule.id,
      name: rule.name,
      symbol: rule.symbol,
      interval: rule.interval,
      time: last.time,
      observedAt: now,
      value: evaluation.value,
      reference: evaluation.reference,
      message:
        "Condición cumplida en vela cerrada. Binance Spot · evaluación local.",
      read: false,
    },
  };
}
