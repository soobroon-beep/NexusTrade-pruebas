import { z } from "zod";
import { intervals } from "../domain/types";
import { indicatorSchema, registry } from "../indicators/registry";
import { drawingSchema } from "../drawings/model";
import { scriptSchema } from "../storage/scripts";
export const compareSchema = z.enum([
  "above",
  "below",
  "cross_up",
  "cross_down",
]);
export type Comparison = z.infer<typeof compareSchema>;
export const comparisons: Record<Comparison, string> = {
  above: "Mayor que",
  below: "Menor que",
  cross_up: "Cruza hacia arriba",
  cross_down: "Cruza hacia abajo",
};
const threshold = z.number().finite();
export const conditionSchema = z
  .discriminatedUnion("kind", [
    z.object({
      kind: z.literal("price"),
      comparison: compareSchema,
      threshold,
    }),
    z.object({
      kind: z.literal("percent"),
      comparison: compareSchema,
      threshold,
    }),
    z.object({
      kind: z.literal("indicator"),
      config: indicatorSchema,
      output: z.number().int().min(0).max(3),
      comparison: compareSchema,
      threshold,
    }),
    z.object({
      kind: z.literal("cross"),
      config: indicatorSchema,
      direction: z.enum(["up", "down"]),
    }),
    z.object({
      kind: z.literal("drawing"),
      drawing: drawingSchema,
      comparison: z.enum(["cross_up", "cross_down"]),
    }),
    z.object({
      kind: z.literal("script"),
      script: scriptSchema,
      output: z.number().int().positive(),
      mode: z.enum(["threshold", "present"]),
      comparison: compareSchema,
      threshold,
    }),
  ])
  .superRefine((c, ctx) => {
    let error = "";
    if (
      c.kind === "indicator" &&
      c.output >= registry[c.config.kind].outputs.length
    )
      error = "Salida de indicador inexistente.";
    if (c.kind === "cross" && c.config.kind !== "cross")
      error = "Selecciona Cruces de medias.";
    if (
      c.kind === "drawing" &&
      (!["horizontal", "trend", "ray"].includes(c.drawing.tool) ||
        (c.drawing.points.length === 2 &&
          c.drawing.points[0].time === c.drawing.points[1].time))
    )
      error = "Sólo horizontales, tendencias y rayos no verticales.";
    if (error) ctx.addIssue({ code: "custom", message: error });
  });
export type Condition = z.infer<typeof conditionSchema>;
export const ruleSchema = z
  .object({
    id: z.string().min(1),
    name: z.string().min(1).max(80),
    symbol: z.string().regex(/^[A-Z0-9]{2,30}$/),
    interval: z.enum(intervals),
    condition: conditionSchema,
    frequency: z.enum(["once", "bar"]),
    createdAt: z.number().finite().nonnegative(),
    updatedAt: z.number().finite().nonnegative(),
    expiresAt: z.number().finite().nonnegative(),
    status: z.enum(["armed", "paused", "triggered"]),
  })
  .refine(
    (r) => r.expiresAt > r.createdAt,
    "La expiración debe ser posterior a la creación.",
  );
export type AlertRule = z.infer<typeof ruleSchema>;
export const eventSchema = z.object({
  id: z.string(),
  ruleId: z.string(),
  name: z.string(),
  symbol: z.string(),
  interval: z.enum(intervals),
  time: z.number().finite(),
  observedAt: z.number().finite(),
  value: z.number().finite(),
  reference: z.number().finite().nullable(),
  message: z.string(),
  read: z.boolean(),
});
export type AlertEvent = z.infer<typeof eventSchema>;
export const conditionNames: Record<Condition["kind"], string> = {
  price: "Precio al cierre",
  percent: "Variación entre cierres",
  indicator: "Valor de indicador",
  cross: "Cruce de medias",
  drawing: "Cruce de dibujo",
  script: "Salida de script",
};
