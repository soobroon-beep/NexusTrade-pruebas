import { useEffect, useRef, useState } from "react";
import type { Candle, Interval } from "../domain/types";
import { useMonitor } from "../state/monitor";
import { advanceAlert, type Cursor, evaluateRule } from "./engine";
export function useAlerts(
  candles: Candle[],
  symbol: string,
  interval: Interval,
  live: boolean,
  script: Parameters<typeof evaluateRule>[2],
) {
  const { data, record } = useMonitor();
  const cursors = useRef(new Map<string, Cursor>());
  const [messages, setMessages] = useState<Record<string, string>>({}),
    [now, setNow] = useState(Date.now());
  useEffect(() => {
    const id = setInterval(() => setNow(Date.now()), 10000);
    return () => clearInterval(id);
  }, []);
  useEffect(() => {
    cursors.current.clear();
  }, [symbol, interval, live]);
  useEffect(() => {
    const messages: Record<string, string> = {};
    for (const rule of data.rules) {
      if (rule.symbol !== symbol || rule.interval !== interval) {
        messages[rule.id] =
          "En espera: selecciona " + rule.symbol + " · " + rule.interval;
        cursors.current.delete(rule.id);
        continue;
      }
      if (!live) {
        messages[rule.id] =
          "Evaluación suspendida: se requiere conexión en vivo y datos íntegros.";
        continue;
      }
      const result = advanceAlert(
        rule,
        candles,
        cursors.current.get(rule.id),
        Date.now(),
        script,
      );
      if (result.cursor) cursors.current.set(rule.id, result.cursor);
      messages[rule.id] = result.message;
      if (result.event) record(result.event);
    }
    setMessages((previous) =>
      JSON.stringify(previous) === JSON.stringify(messages)
        ? previous
        : messages,
    );
  }, [
    candles,
    symbol,
    interval,
    live,
    data.rules,
    record,
    script?.active,
    script?.result,
    script?.busy,
    now,
  ]);
  return { messages, now };
}
