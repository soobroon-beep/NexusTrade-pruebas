import { describe, it, expect } from "vitest";
import { advanceAlert, evaluateRule, drawingPrice } from "./engine";
import { ruleSchema, type AlertRule } from "./model";
import type { Candle } from "../domain/types";
import { newIndicator } from "../indicators/registry";
import type { Drawing } from "../drawings/model";
import { run } from "../pine/runtime";
import type { Script } from "../storage/scripts";
const bars = (prices: number[]): Candle[] =>
  prices.map((close, i) => ({
    time: i * 60,
    close,
    open: close,
    high: close + 1,
    low: close - 1,
    volume: 10,
    closed: true,
    closeTime: (i + 1) * 60000 - 1,
    source: "Binance Spot",
    receivedAt: (i + 1) * 60000,
  }));
const rule: AlertRule = {
  id: "a",
  name: "Precio",
  symbol: "BTCUSDT",
  interval: "1m",
  condition: { kind: "price", comparison: "cross_up", threshold: 2.5 },
  frequency: "bar",
  createdAt: 1,
  updatedAt: 1,
  expiresAt: 1_000_000,
  status: "armed",
};
describe("alertas al cierre", () => {
  it("no dispara retrospectivamente al arrancar; dispara en el cierre siguiente", () => {
    const initial = advanceAlert(rule, bars([1, 2]), undefined, 120000);
    expect(initial.event).toBeUndefined();
    const next = advanceAlert(rule, bars([1, 2, 3]), initial.cursor, 180000);
    expect(next.event).toMatchObject({ id: "a:120", value: 3, time: 120 });
    expect(
      advanceAlert(rule, bars([1, 2, 3]), next.cursor, 180001).event,
    ).toBeUndefined();
  });
  it("ignora la barra abierta hasta su cierre", () => {
    const candles = bars([1, 2, 3]);
    candles[2].closed = false;
    const r = advanceAlert(rule, candles, { revision: 1, bar: 60 }, 180000);
    expect(r.event).toBeUndefined();
    candles[2].closed = true;
    expect(advanceAlert(rule, candles, r.cursor, 180000).event).toBeDefined();
  });
  it("pausa, expiración, edición y cierre previo a creación no disparan", () => {
    const c = bars([1, 2, 3]),
      cursor = { revision: 1, bar: 60 };
    expect(
      advanceAlert({ ...rule, status: "paused" }, c, cursor, 180000).event,
    ).toBeUndefined();
    expect(
      advanceAlert({ ...rule, expiresAt: 150000 }, c, cursor, 180000).event,
    ).toBeUndefined();
    expect(
      advanceAlert({ ...rule, updatedAt: 2 }, c, cursor, 180000).event,
    ).toBeUndefined();
    expect(
      advanceAlert({ ...rule, createdAt: 200000 }, c, cursor, 180000).event,
    ).toBeUndefined();
  });
  it("distingue umbral sostenido de cruce", () => {
    expect(
      evaluateRule(
        {
          ...rule,
          condition: { kind: "price", comparison: "above", threshold: 2 },
        },
        bars([3, 4]),
      ),
    ).toMatchObject({ match: true });
    expect(
      evaluateRule(
        {
          ...rule,
          condition: { kind: "price", comparison: "cross_up", threshold: 2 },
        },
        bars([3, 4]),
      ),
    ).toMatchObject({ match: false });
  });
  it("calcula variación entre cierres y evita huecos y división cero", () => {
    expect(
      evaluateRule(
        {
          ...rule,
          condition: { kind: "percent", comparison: "above", threshold: 5 },
        },
        bars([90, 100, 110]),
      ),
    ).toMatchObject({ ready: true, match: true });
    const c = bars([1, 2, 3]);
    c[2].time = 240;
    expect(evaluateRule(rule, c).ready).toBe(false);
    expect(
      evaluateRule(
        {
          ...rule,
          condition: { kind: "percent", comparison: "above", threshold: 1 },
        },
        bars([1, 0, 2]),
      ).ready,
    ).toBe(false);
  });
  it("usa copia del indicador y calentamiento explícito", () => {
    const config = newIndicator("sma");
    config.params.period = 3;
    const r: AlertRule = {
      ...rule,
      condition: {
        kind: "indicator",
        config,
        output: 0,
        comparison: "above",
        threshold: 1,
      },
    };
    expect(evaluateRule(r, bars([1, 2])).ready).toBe(false);
    expect(evaluateRule(r, bars([1, 2, 3]))).toMatchObject({
      match: true,
      value: 2,
    });
  });
  it("cruces de medias sólo cuando el motor señala el evento", () => {
    const config = newIndicator("cross");
    config.params.fast = 2;
    config.params.slow = 3;
    expect(
      evaluateRule(
        { ...rule, condition: { kind: "cross", config, direction: "up" } },
        bars([3, 2, 1, 3, 4]),
      ),
    ).toMatchObject({ ready: true, match: true });
  });
  it("no calcula indicadores a través de un hueco", () => {
    const config = newIndicator("sma");
    config.params.period = 3;
    const c = bars([1, 2, 3, 4]);
    c[2].time = 240;
    c[3].time = 300;
    expect(
      evaluateRule(
        {
          ...rule,
          condition: {
            kind: "indicator",
            config,
            output: 0,
            comparison: "above",
            threshold: 0,
          },
        },
        c,
      ).ready,
    ).toBe(false);
  });
});
const drawing: Drawing = {
  id: "d",
  tool: "trend",
  points: [
    { time: 0, price: 1 },
    { time: 120, price: 3 },
  ],
  color: "#ffffff",
  width: 1,
  dash: false,
  extend: false,
  text: "",
  visible: true,
  locked: false,
};
it("respeta dominio del dibujo y umbral inclinado anterior/actual", () => {
  expect(drawingPrice(drawing, 60)).toBe(2);
  expect(drawingPrice(drawing, 180)).toBeNull();
  expect(drawingPrice({ ...drawing, extend: true }, 180)).toBe(4);
  expect(
    evaluateRule(
      {
        ...rule,
        condition: { kind: "drawing", drawing, comparison: "cross_up" },
      },
      bars([1, 1, 4]),
    ),
  ).toMatchObject({ match: true, reference: 3 });
});
it("alerta de script exige fuente, parámetros y cierre exactos; espera el Worker", () => {
  const source = '//@version=6\nindicator("X")\nplot(close)';
  const script: Script = {
    id: "s",
    name: "S",
    revision: 1,
    source,
    original: source,
    description: "",
    updatedAt: 1,
    parameters: {},
  };
  const result = run(source, bars([1, 2, 3])).result;
  const r: AlertRule = {
    ...rule,
    condition: {
      kind: "script",
      script,
      output: result.plots[0].id,
      mode: "threshold",
      comparison: "cross_up",
      threshold: 2.5,
    },
  };
  expect(
    evaluateRule(r, bars([1, 2, 3]), { active: script, result }),
  ).toMatchObject({ match: true });
  expect(
    evaluateRule(r, bars([1, 2, 3]), {
      active: { ...script, source: source + "\n" },
      result,
    }).ready,
  ).toBe(false);
  const pending = advanceAlert(
    r,
    bars([1, 2, 3]),
    { bar: 60, revision: 1 },
    180000,
    { active: script, result, busy: true },
  );
  expect(pending.cursor?.bar).toBe(60);
  expect(pending.event).toBeUndefined();
});
it("valida reglas, salidas y expiración", () => {
  expect(() => ruleSchema.parse({ ...rule, expiresAt: 0 })).toThrow();
  expect(() =>
    ruleSchema.parse({
      ...rule,
      condition: {
        kind: "indicator",
        config: newIndicator("sma"),
        output: 3,
        comparison: "above",
        threshold: 1,
      },
    }),
  ).toThrow();
  expect(() =>
    ruleSchema.parse({
      ...rule,
      condition: {
        kind: "drawing",
        comparison: "cross_up",
        drawing: { ...drawing, tool: "vertical", points: [drawing.points[0]] },
      },
    }),
  ).toThrow();
});
it("interpola las líneas en el mismo eje lógico que la gráfica, incluso con meses desiguales", () => {
  const c = bars([1, 2, 3]);
  c[1].time = 60;
  c[2].time = 180;
  const d = {
    ...drawing,
    points: [
      { time: 0, price: 1 },
      { time: 180, price: 3 },
    ],
  };
  expect(drawingPrice(d, 60, c)).toBe(2);
});

it("omite cierres no observados aunque el histórico recuperado sea continuo", () => {
  const result = advanceAlert(
    rule,
    bars([1, 2, 3, 4]),
    { revision: 1, bar: 0 },
    240000,
  );
  expect(result.event).toBeUndefined();
  expect(result.cursor?.bar).toBe(180);
  expect(result.message).toContain("no observados");
});
