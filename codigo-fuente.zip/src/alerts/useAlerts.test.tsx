// @vitest-environment jsdom
import { it, expect, afterEach } from "vitest";
import { renderHook, act, cleanup } from "@testing-library/react";
import { useAlerts } from "./useAlerts";
import { useMonitor } from "../state/monitor";
import { defaultMonitor } from "../storage/monitor";
import type { AlertRule } from "./model";
import type { Candle } from "../domain/types";
const base = Math.floor(Date.now() / 60000) * 60 - 180;
const bars = (n: number): Candle[] =>
  Array.from({ length: n }, (_, i) => ({
    time: base + i * 60,
    close: i + 1,
    open: i + 1,
    high: i + 2,
    low: i,
    closed: true,
    volume: 1,
    closeTime: (base + (i + 1) * 60) * 1000 - 1,
    source: "Binance Spot",
    receivedAt: Date.now(),
  }));
const rule: AlertRule = {
  id: "r",
  name: "Test",
  symbol: "BTCUSDT",
  interval: "1m",
  condition: { kind: "price", comparison: "above", threshold: 1 },
  frequency: "once",
  createdAt: 0,
  updatedAt: 1,
  expiresAt: Date.now() + 86400000,
  status: "armed",
};
afterEach(cleanup);
it("registra una vez al cierre, restaura la regla disparada y no repite", () => {
  useMonitor.getState().setData({ ...defaultMonitor, rules: [rule] });
  const { rerender } = renderHook(
    ({ candles }) => useAlerts(candles, "BTCUSDT", "1m", true, undefined),
    { initialProps: { candles: bars(2) } },
  );
  expect(useMonitor.getState().data.events).toHaveLength(0);
  rerender({ candles: bars(3) });
  expect(useMonitor.getState().data.events).toHaveLength(1);
  expect(useMonitor.getState().data.rules[0].status).toBe("triggered");
  rerender({ candles: bars(4) });
  expect(useMonitor.getState().data.events).toHaveLength(1);
  act(() => useMonitor.getState().record(useMonitor.getState().data.events[0]));
  expect(useMonitor.getState().data.events).toHaveLength(1);
});
it("cambiar mercado o desconectarse reinicia la referencia, sin recuperar alertas perdidas", () => {
  useMonitor
    .getState()
    .setData({ ...defaultMonitor, rules: [{ ...rule, frequency: "bar" }] });
  const { rerender } = renderHook(
    ({ symbol, live, candles }) =>
      useAlerts(candles, symbol, "1m", live, undefined),
    { initialProps: { symbol: "BTCUSDT", live: true, candles: bars(2) } },
  );
  rerender({ symbol: "ETHUSDT", live: true, candles: bars(3) });
  rerender({ symbol: "BTCUSDT", live: true, candles: bars(3) });
  expect(useMonitor.getState().data.events).toHaveLength(0);
  rerender({ symbol: "BTCUSDT", live: false, candles: bars(4) });
  rerender({ symbol: "BTCUSDT", live: true, candles: bars(4) });
  expect(useMonitor.getState().data.events).toHaveLength(0);
  rerender({ symbol: "BTCUSDT", live: true, candles: bars(5) });
  expect(useMonitor.getState().data.events).toHaveLength(1);
});
