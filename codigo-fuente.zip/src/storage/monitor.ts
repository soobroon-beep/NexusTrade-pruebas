import { z } from "zod";
import { ruleSchema, eventSchema } from "../alerts/model";
import { structureConfigSchema, defaultStructure } from "../structure/engine";
export const monitorSchema = z
  .object({
    version: z.literal(1),
    rules: z.array(ruleSchema).max(40),
    events: z.array(eventSchema).max(300),
    structure: structureConfigSchema,
    showLevels: z.boolean(),
  })
  .refine(
    (x) =>
      new Set(x.rules.map((r) => r.id)).size === x.rules.length &&
      new Set(x.events.map((e) => e.id)).size === x.events.length,
    "Identificadores duplicados.",
  );
export type Monitor = z.infer<typeof monitorSchema>;
export const defaultMonitor: Monitor = {
  version: 1,
  rules: [],
  events: [],
  structure: defaultStructure,
  showLevels: false,
};
export const monitorKey = "cripto-chart-terminal.monitor.v1";
export function loadMonitor(storage: Pick<Storage, "getItem">) {
  try {
    const raw = storage.getItem(monitorKey);
    return {
      data: raw ? monitorSchema.parse(JSON.parse(raw)) : defaultMonitor,
      warning: "",
    };
  } catch {
    return {
      data: defaultMonitor,
      warning:
        "No se pudo leer el monitor. El original se conserva hasta guardar cambios.",
    };
  }
}
export function saveMonitor(
  storage: Pick<Storage, "getItem" | "setItem">,
  data: Monitor,
) {
  monitorSchema.parse(data);
  const raw = storage.getItem(monitorKey);
  if (raw) storage.setItem(monitorKey + ".backup", raw);
  storage.setItem(monitorKey, JSON.stringify(data));
}
