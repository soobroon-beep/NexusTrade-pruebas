import { it, expect } from "vitest";
import {
  analysisSchema,
  analysisKey,
  emptyAnalysis,
  loadAnalysis,
  saveAnalysis,
  parseBundle,
  templateSchema,
} from "./analysis";
import { defaultWorkspace } from "./workspace";
import { newIndicator } from "../indicators/registry";
it("migra importaciones Fase 1 sin modificar el esquema anterior", () => {
  const parsed = parseBundle(defaultWorkspace);
  expect(parsed.version).toBe(2);
  expect(parsed.workspace).toEqual(defaultWorkspace);
  expect(parsed.analysis).toEqual(emptyAnalysis);
});
it("persiste y restaura indicadores con copia previa", () => {
  const data = new Map<string, string>();
  const storage = {
    getItem: (key: string) => data.get(key) ?? null,
    setItem: (key: string, value: string) => {
      data.set(key, value);
    },
  };
  const analysis = {
    ...emptyAnalysis,
    setup: { indicators: [newIndicator("rsi")], drawings: {} },
  };
  saveAnalysis(storage, analysis);
  saveAnalysis(storage, {
    ...analysis,
    setup: { ...analysis.setup, indicators: [] },
  });
  expect(loadAnalysis(storage).data.setup.indicators).toEqual([]);
  expect(
    JSON.parse(data.get(analysisKey + ".backup")!).setup.indicators,
  ).toHaveLength(1);
});
it("rechaza plantillas corruptas y duplicados sin tocar el original", () => {
  expect(templateSchema.safeParse({ id: "x" }).success).toBe(false);
  const indicator = newIndicator("sma");
  expect(
    analysisSchema.safeParse({
      ...emptyAnalysis,
      setup: { indicators: [indicator, indicator], drawings: {} },
    }).success,
  ).toBe(false);
  const getItem = () => "{broken";
  expect(loadAnalysis({ getItem }).warning).not.toBe("");
  expect(getItem()).toBe("{broken");
});
