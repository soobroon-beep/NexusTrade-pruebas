import { it, expect } from "vitest";
import {
  loadScripts,
  saveScripts,
  scriptsKey,
  scriptsSchema,
  type Scripts,
} from "./scripts";
const memory = () => {
  const m = new Map<string, string>();
  return {
    getItem: (k: string) => m.get(k) ?? null,
    setItem: (k: string, v: string) => {
      m.set(k, v);
    },
  };
};
const data: Scripts = {
  version: 1,
  active: "a",
  items: [
    {
      id: "a",
      name: "Test",
      revision: 1,
      description: "",
      source: "edited",
      original: "original text",
      updatedAt: 1,
      parameters: { n: 2 },
    },
  ],
};
it("conserva el original y restaura colección y selección tras recargar", () => {
  const s = memory();
  saveScripts(s, data);
  expect(loadScripts(s).data).toEqual(data);
  saveScripts(s, { ...data, active: null });
  expect(JSON.parse(s.getItem(scriptsKey + ".backup")!)).toEqual(data);
});
it("conserva datos corruptos y avisa", () => {
  const s = memory();
  s.setItem(scriptsKey, "bad");
  expect(loadScripts(s).warning).not.toBe("");
  expect(s.getItem(scriptsKey)).toBe("bad");
});
it("rechaza importaciones inválidas, versiones y referencias", () => {
  expect(() => scriptsSchema.parse({ ...data, version: 2 })).toThrow();
  expect(() => scriptsSchema.parse({ ...data, active: "missing" })).toThrow();
  expect(() =>
    scriptsSchema.parse({ ...data, items: [...data.items, ...data.items] }),
  ).toThrow();
});
