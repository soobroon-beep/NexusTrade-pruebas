import { describe, it, expect } from "vitest";
import {
  defaultWorkspace,
  loadWorkspace,
  saveWorkspace,
  key,
  workspaceSchema,
} from "./workspace";
function memory() {
  const data = new Map<string, string>();
  return {
    getItem: (k: string) => data.get(k) ?? null,
    setItem: (k: string, v: string) => {
      data.set(k, v);
    },
  };
}
describe("persistencia versionada", () => {
  it("restaura símbolos, temporalidad, tipo y listas tras una recarga", () => {
    const storage = memory();
    const workspace = {
      ...defaultWorkspace,
      symbol: "ETHUSDT",
      interval: "4h" as const,
      lists: [{ id: "main", name: "Prueba", symbols: ["ETHUSDT"] }],
    };
    saveWorkspace(storage, workspace);
    expect(loadWorkspace(storage).data).toEqual(workspace);
  });
  it("no sobrescribe datos dañados al leer", () => {
    const storage = memory();
    storage.setItem(key, "incorrecto");
    expect(loadWorkspace(storage).warning).not.toBe("");
    expect(storage.getItem(key)).toBe("incorrecto");
  });
  it("rechaza versiones futuras y listas activas inexistentes", () => {
    expect(
      workspaceSchema.safeParse({ ...defaultWorkspace, version: 2 }).success,
    ).toBe(false);
    expect(
      workspaceSchema.safeParse({ ...defaultWorkspace, activeList: "missing" })
        .success,
    ).toBe(false);
  });
  it("conserva una copia antes de escribir", () => {
    const storage = memory();
    saveWorkspace(storage, defaultWorkspace);
    saveWorkspace(storage, { ...defaultWorkspace, symbol: "SOLUSDT" });
    expect(JSON.parse(storage.getItem(key + ".backup")!).symbol).toBe(
      "BTCUSDT",
    );
  });
});
