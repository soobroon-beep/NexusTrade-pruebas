import { z } from "zod";
import { intervals } from "../domain/types";
export const workspaceSchema = z
  .object({
    version: z.literal(1),
    symbol: z.string().regex(/^[A-Z0-9]{2,30}$/),
    interval: z.enum(intervals),
    chartType: z.enum(["candles", "bars", "line", "area"]),
    volume: z.boolean(),
    activeList: z.string(),
    lists: z
      .array(
        z.object({
          id: z.string(),
          name: z.string().min(1).max(40),
          symbols: z.array(z.string().regex(/^[A-Z0-9]{2,30}$/)).max(20),
        }),
      )
      .min(1)
      .max(20),
    showWatchlist: z.boolean(),
    showDetails: z.boolean(),
  })
  .refine(
    (x) => x.lists.some((l) => l.id === x.activeList),
    "Lista activa no encontrada",
  )
  .refine(
    (x) =>
      new Set(x.lists.map((l) => l.id)).size === x.lists.length &&
      x.lists.every((l) => new Set(l.symbols).size === l.symbols.length),
    "No se admiten listas ni símbolos duplicados",
  );
export type Workspace = z.infer<typeof workspaceSchema>;
export const defaultWorkspace: Workspace = {
  version: 1,
  symbol: "BTCUSDT",
  interval: "1h",
  chartType: "candles",
  volume: true,
  activeList: "main",
  lists: [
    {
      id: "main",
      name: "Mi seguimiento",
      symbols: [
        "BTCUSDT",
        "ETHUSDT",
        "SOLUSDT",
        "BNBUSDT",
        "XRPUSDT",
        "DOGEUSDT",
      ],
    },
  ],
  showWatchlist: true,
  showDetails: true,
};
export const key = "cripto-chart-terminal.workspace.v1";
export function loadWorkspace(storage: Pick<Storage, "getItem">): {
  data: Workspace;
  warning: string;
} {
  try {
    const raw = storage.getItem(key);
    if (!raw) return { data: defaultWorkspace, warning: "" };
    const parsed = workspaceSchema.safeParse(JSON.parse(raw));
    if (parsed.success) return { data: parsed.data, warning: "" };
    return {
      data: defaultWorkspace,
      warning:
        "La configuración guardada no es compatible. Se conserva intacta hasta que guardes cambios.",
    };
  } catch {
    return {
      data: defaultWorkspace,
      warning:
        "No se pudo leer el almacenamiento local. Exporta tu espacio para conservarlo.",
    };
  }
}
export function saveWorkspace(
  storage: Pick<Storage, "setItem" | "getItem">,
  data: Workspace,
) {
  workspaceSchema.parse(data);
  const previous = storage.getItem(key);
  if (previous) storage.setItem(key + ".backup", previous);
  storage.setItem(key, JSON.stringify(data));
}
