import { z } from "zod";
export const scriptSchema = z.object({
  id: z.string().min(1),
  name: z.string().min(1).max(80),
  revision: z.number().int().positive(),
  description: z.string().max(1000),
  source: z.string().max(64000),
  original: z.string().max(64000),
  updatedAt: z.number().finite(),
  parameters: z.record(
    z.union([z.number().finite(), z.string().max(200), z.boolean(), z.null()]),
  ),
});
export type Script = z.infer<typeof scriptSchema>;
export const scriptsSchema = z
  .object({
    version: z.literal(1),
    items: z.array(scriptSchema).max(30),
    active: z.string().nullable(),
  })
  .refine(
    (d) =>
      new Set(d.items.map((x) => x.id)).size === d.items.length &&
      (!d.active || d.items.some((x) => x.id === d.active)),
    "Identidad de scripts inválida",
  );
export type Scripts = z.infer<typeof scriptsSchema>;
export const scriptsKey = "cripto-chart-terminal.scripts.v1";
export function loadScripts(storage: Pick<Storage, "getItem">): {
  data: Scripts;
  warning: string;
} {
  try {
    const raw = storage.getItem(scriptsKey);
    return {
      data: raw
        ? scriptsSchema.parse(JSON.parse(raw))
        : { version: 1, items: [], active: null },
      warning: "",
    };
  } catch {
    return {
      data: { version: 1, items: [], active: null },
      warning:
        "No se pudieron leer los scripts. Se conserva el original hasta guardar cambios.",
    };
  }
}
export function saveScripts(
  storage: Pick<Storage, "getItem" | "setItem">,
  data: Scripts,
) {
  scriptsSchema.parse(data);
  const old = storage.getItem(scriptsKey);
  if (old) storage.setItem(scriptsKey + ".backup", old);
  storage.setItem(scriptsKey, JSON.stringify(data));
}
