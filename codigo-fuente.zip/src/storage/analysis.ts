import { z } from "zod";
import { indicatorSchema } from "../indicators/registry";
import { drawingSchema } from "../drawings/model";
import { workspaceSchema, defaultWorkspace } from "./workspace";
export const setupSchema = z
  .object({
    indicators: z.array(indicatorSchema).max(16),
    drawings: z.record(z.array(drawingSchema).max(100)),
  })
  .refine(
    (x) =>
      new Set(x.indicators.map((i) => i.id)).size === x.indicators.length &&
      Object.values(x.drawings).every(
        (ds) => new Set(ds.map((d) => d.id)).size === ds.length,
      ),
    "Identificadores duplicados",
  );
export const templateSchema = z.object({
  id: z.string(),
  name: z.string().min(1).max(60),
  updatedAt: z.number(),
  workspace: workspaceSchema,
  setup: setupSchema,
});
export const analysisSchema = z
  .object({
    version: z.literal(1),
    setup: setupSchema,
    templates: z.array(templateSchema).max(20),
  })
  .refine(
    (x) => new Set(x.templates.map((t) => t.id)).size === x.templates.length,
    "Plantillas duplicadas",
  );
export type Analysis = z.infer<typeof analysisSchema>;
export type Setup = z.infer<typeof setupSchema>;
export const emptyAnalysis: Analysis = {
  version: 1,
  setup: { indicators: [], drawings: {} },
  templates: [],
};
export const analysisKey = "cripto-chart-terminal.analysis.v1";
export const bundleSchema = z.object({
  version: z.literal(2),
  workspace: workspaceSchema,
  analysis: analysisSchema,
});
export function parseBundle(input: unknown) {
  const parsed = bundleSchema.safeParse(input);
  if (parsed.success) return parsed.data;
  return {
    version: 2 as const,
    workspace: workspaceSchema.parse(input),
    analysis: emptyAnalysis,
  };
}
export function loadAnalysis(storage: Pick<Storage, "getItem">): {
  data: Analysis;
  warning: string;
} {
  try {
    const raw = storage.getItem(analysisKey);
    if (!raw) return { data: emptyAnalysis, warning: "" };
    return { data: analysisSchema.parse(JSON.parse(raw)), warning: "" };
  } catch {
    return {
      data: emptyAnalysis,
      warning:
        "No se pudo leer el análisis guardado. Se conserva el original hasta guardar cambios.",
    };
  }
}
export function saveAnalysis(
  storage: Pick<Storage, "getItem" | "setItem">,
  data: Analysis,
) {
  analysisSchema.parse(data);
  const raw = storage.getItem(analysisKey);
  if (raw) storage.setItem(analysisKey + ".backup", raw);
  storage.setItem(analysisKey, JSON.stringify(data));
}
export const defaultBundle = {
  version: 2 as const,
  workspace: defaultWorkspace,
  analysis: emptyAnalysis,
};
