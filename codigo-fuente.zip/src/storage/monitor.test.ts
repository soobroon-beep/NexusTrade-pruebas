import { it, expect } from "vitest";
import {
  defaultMonitor,
  loadMonitor,
  saveMonitor,
  monitorKey,
  monitorSchema,
} from "./monitor";
const memory = () => {
  const m = new Map<string, string>();
  return {
    getItem: (k: string) => m.get(k) ?? null,
    setItem: (k: string, v: string) => {
      m.set(k, v);
    },
  };
};
it("restaura configuración, mantiene copia y conserva corrupción sin sobrescribir", () => {
  const s = memory();
  saveMonitor(s, defaultMonitor);
  const changed = { ...defaultMonitor, showLevels: true };
  saveMonitor(s, changed);
  expect(loadMonitor(s).data.showLevels).toBe(true);
  expect(JSON.parse(s.getItem(monitorKey + ".backup")!)).toEqual(
    defaultMonitor,
  );
  s.setItem(monitorKey, "broken");
  expect(loadMonitor(s).warning).not.toBe("");
  expect(s.getItem(monitorKey)).toBe("broken");
});
it("rechaza esquema futuro y parámetros fuera de límites", () => {
  expect(() =>
    monitorSchema.parse({ ...defaultMonitor, version: 2 }),
  ).toThrow();
  expect(() =>
    monitorSchema.parse({
      ...defaultMonitor,
      structure: { ...defaultMonitor.structure, left: 0 },
    }),
  ).toThrow();
});
