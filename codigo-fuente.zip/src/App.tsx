import { MonitorWorkbench } from "./components/MonitorWorkbench";
import { useMonitor } from "./state/monitor";
import { useAlerts } from "./alerts/useAlerts";
import { analyzeStructure } from "./structure/engine";
import { ScriptWorkbench } from "./components/ScriptWorkbench";
import { useScript } from "./pine/useScript";
import { newId } from "./domain/id";
import { useEffect, useMemo, useRef, useState } from "react";
import { useQuery } from "@tanstack/react-query";
import {
  Activity,
  ArrowUp,
  ChevronDown,
  ChevronLeft,
  ChevronRight,
  Download,
  Expand,
  Layers,
  LayoutPanelLeft,
  PanelRight,
  Plus,
  RefreshCw,
  Search,
  Settings2,
  X,
  Wifi,
  WifiOff,
  ExternalLink,
  Check,
} from "lucide-react";
import { Chart } from "./components/Chart";
import { market } from "./market/binance";
import { useMarket } from "./market/useMarket";
import { useWorkspace } from "./state/workspace";
import { intervals, type Interval } from "./domain/types";
import { AnalysisWorkbench } from "./components/AnalysisWorkbench";
import { useAnalysis } from "./state/analysis";
import { parseBundle } from "./storage/analysis";
import { registry } from "./indicators/registry";
import type { DrawingTool } from "./drawings/model";
import { registerMarketTool, type ModelContext } from "./state/webmcp";
const number = (v: number | undefined, d = 2) =>
  v === undefined
    ? "—"
    : v.toLocaleString("en-US", {
        maximumFractionDigits: d,
        minimumFractionDigits: d,
      });
const compact = (v: number | undefined) =>
  v === undefined
    ? "—"
    : new Intl.NumberFormat("en-US", {
        notation: "compact",
        maximumFractionDigits: 2,
      }).format(v);
function download(name: string, content: string, type = "application/json") {
  const url = URL.createObjectURL(new Blob([content], { type }));
  const a = document.createElement("a");
  a.href = url;
  a.download = name;
  a.click();
  setTimeout(() => URL.revokeObjectURL(url), 1000);
}
export default function App() {
  const { workspace: w, update, warning } = useWorkspace();
  const { analysis, setAnalysis, setDrawings } = useAnalysis();
  const [drawingTool, setDrawingTool] = useState<DrawingTool | null>(null);
  const [selectedDrawing, setSelectedDrawing] = useState<string | null>(null);
  const marketKey = w.symbol + "-" + w.interval;
  useEffect(() => {
    setDrawingTool(null);
    setSelectedDrawing(null);
  }, [marketKey]);
  const list = w.lists.find((l) => l.id === w.activeList)!;
  const [modal, setModal] = useState<"search" | "settings" | "about" | null>(
    null,
  );
  const [search, setSearch] = useState("");
  const [tab, setTab] = useState<"data" | "connection" | "roadmap">("data");
  const [fit, setFit] = useState(0);
  const [bottom, setBottom] = useState(true);
  const [notice, setNotice] = useState("");
  const [sort, setSort] = useState<"manual" | "change" | "name">("manual");
  const [filter, setFilter] = useState("");
  const dialog = useRef<HTMLDialogElement>(null);
  const searchInput = useRef<HTMLInputElement>(null);
  const symbols = useQuery({
    queryKey: ["symbols"],
    queryFn: ({ signal }) => market.getSymbols(signal),
    staleTime: 3600000,
  });
  useEffect(() => {
    const context = (document as Document & { modelContext?: ModelContext })
      .modelContext;
    if (context && symbols.data)
      return registerMarketTool(context, symbols.data, update);
  }, [symbols.data, update]);
  const tickers = useQuery({
    queryKey: [
      "tickers",
      [...new Set([...list.symbols, w.symbol])].sort().join(","),
    ],
    queryFn: ({ signal }) =>
      market.getTickers([...new Set([w.symbol, ...list.symbols])], signal),
    refetchInterval: 30000,
    staleTime: 20000,
  });
  const stream = useMarket(w.symbol, w.interval);
  const script = useScript(stream.candles, marketKey);
  const candle = stream.candles.at(-1);
  const ticker = tickers.data?.find((t) => t.symbol === w.symbol);
  const meta = symbols.data?.find((s) => s.symbol === w.symbol);
  const base = meta?.baseAsset ?? w.symbol.replace(/USDT$/, "");
  const quote = meta?.quoteAsset ?? (w.symbol.endsWith("USDT") ? "USDT" : "—");
  const last = candle?.close ?? ticker?.lastPrice;
  const live = stream.connection === "live" && !stream.stale && !!candle;
  const { data: monitor } = useMonitor();
  const alerts = useAlerts(
    stream.candles,
    w.symbol,
    w.interval,
    live && !stream.error && !stream.gaps.length,
    script,
  );
  const structure = useMemo(
    () =>
      monitor.structure.enabled
        ? analyzeStructure(stream.candles, w.interval, monitor.structure)
        : undefined,
    [stream.candles, w.interval, monitor.structure],
  );
  const isBusy = stream.isFetchingNextPage;
  useEffect(() => {
    if (modal) {
      dialog.current?.showModal();
      if (modal === "search")
        setTimeout(() => searchInput.current?.focus(), 30);
    } else dialog.current?.close();
  }, [modal]);
  useEffect(() => {
    const key = (event: KeyboardEvent) => {
      if ((event.target as HTMLElement).matches("input,textarea,select"))
        return;
      if (event.key === "/") {
        event.preventDefault();
        setModal("search");
      }
      if (event.altKey && event.key === "w") {
        event.preventDefault();
        update({
          showWatchlist: !useWorkspace.getState().workspace.showWatchlist,
        });
      }
    };
    window.addEventListener("keydown", key);
    return () => window.removeEventListener("keydown", key);
  }, [update]);
  const editSymbols = (items: string[]) =>
    update({
      lists: w.lists.map((l) =>
        l.id === w.activeList ? { ...l, symbols: items } : l,
      ),
    });
  const add = (symbol: string) => {
    if (list.symbols.includes(symbol)) return;
    if (list.symbols.length >= 20) {
      setNotice("Cada lista admite hasta 20 símbolos.");
      return;
    }
    editSymbols([...list.symbols, symbol]);
  };
  const changeSymbol = (symbol: string) => {
    update({ symbol });
    setModal(null);
    setSearch("");
  };
  const rename = () => {
    const name = prompt("Nombre de la lista", list.name)?.trim();
    if (name && name.length <= 40)
      update({
        lists: w.lists.map((l) => (l.id === list.id ? { ...l, name } : l)),
      });
  };
  const newList = () => {
    if (w.lists.length >= 20) {
      setNotice("Se admiten hasta 20 listas.");
      return;
    }
    const name = prompt("Nombre de la nueva lista")?.trim();
    if (name && name.length <= 40) {
      const id = newId();
      update({
        activeList: id,
        lists: [...w.lists, { id, name, symbols: [] }],
      });
    }
  };
  const displayed = list.symbols
    .filter((s) => s.includes(filter.toUpperCase()))
    .sort((a, b) =>
      sort === "name"
        ? a.localeCompare(b)
        : sort === "change"
          ? (tickers.data?.find((t) => t.symbol === b)?.priceChangePercent ??
              -Infinity) -
            (tickers.data?.find((t) => t.symbol === a)?.priceChangePercent ??
              -Infinity)
          : 0,
    );
  const older = () => {
    if (stream.hasNextPage && !stream.isFetching) void stream.fetchNextPage();
  };
  return (
    <div className="terminal">
      <header className="app-header">
        <button
          className="brand"
          onClick={() => setModal("about")}
          title="Acerca del terminal"
        >
          <span className="brand-icon">
            <Activity size={23} />
          </span>
          <span>
            CRIPTO <strong>CHART TERMINAL</strong>
            <small>SPOT WORKSPACE</small>
          </span>
        </button>
        <div className="header-center">
          <span className="market-label">
            BINANCE <span>SPOT</span>
          </span>
          <span className="divider" />
          <button className="search-button" onClick={() => setModal("search")}>
            <Search size={16} /> Buscar un símbolo <kbd>/</kbd>
          </button>
        </div>
        <div className="header-actions">
          <span className={"connection " + (live ? "positive" : "muted")}>
            {live ? <Wifi size={14} /> : <WifiOff size={14} />}{" "}
            {live
              ? "En vivo"
              : stream.connection === "connecting"
                ? "Conectando"
                : "Sin flujo en vivo"}
          </span>
          <button
            className="icon-button"
            title="Ajustes del espacio"
            aria-label="Ajustes del espacio"
            onClick={() => setModal("settings")}
          >
            <Settings2 size={18} />
          </button>
          <span className="avatar">CT</span>
        </div>
      </header>
      <div className="workspace-bar">
        <div>
          <span className="workspace-dot" /> Mi espacio{" "}
          <span className="muted">/</span>{" "}
          <span className="muted">Análisis de mercado</span>
        </div>
        <div>
          <span className="local-label">Guardado local</span>
          <button
            className={"icon-button " + (w.showWatchlist ? "selected" : "")}
            title="Mostrar seguimiento · Alt+W"
            aria-label="Mostrar seguimiento"
            onClick={() => update({ showWatchlist: !w.showWatchlist })}
          >
            <LayoutPanelLeft size={17} />
          </button>
          <button
            className={"icon-button " + (w.showDetails ? "selected" : "")}
            title="Mostrar resumen"
            aria-label="Mostrar resumen"
            onClick={() => update({ showDetails: !w.showDetails })}
          >
            <PanelRight size={17} />
          </button>
        </div>
      </div>
      {(warning || notice) && (
        <div className="notice" role="status">
          {warning || notice}
          {!warning && (
            <button onClick={() => setNotice("")} aria-label="Cerrar aviso">
              <X size={15} />
            </button>
          )}
        </div>
      )}
      <main
        className={
          "workspace " +
          (!w.showWatchlist ? "no-watch " : "") +
          (!w.showDetails ? "no-details" : "")
        }
      >
        {w.showWatchlist && (
          <aside className="watchlist">
            <div className="panel-heading">
              <span>SEGUIMIENTO</span>
              <button
                className="icon-button"
                title="Añadir símbolo"
                aria-label="Añadir símbolo"
                onClick={() => setModal("search")}
              >
                <Plus size={18} />
              </button>
            </div>
            <div className="list-select">
              <select
                aria-label="Lista de seguimiento"
                value={w.activeList}
                onChange={(e) => update({ activeList: e.target.value })}
              >
                {w.lists.map((l) => (
                  <option key={l.id} value={l.id}>
                    {l.name}
                  </option>
                ))}
              </select>
              <button
                title="Nueva lista"
                aria-label="Nueva lista"
                onClick={newList}
              >
                <Plus size={16} />
              </button>
            </div>
            <div className="list-tools">
              <button onClick={rename}>Renombrar</button>
              <button
                disabled={w.lists.length < 2}
                onClick={() => {
                  if (confirm("¿Eliminar esta lista?"))
                    update({
                      lists: w.lists.filter((l) => l.id !== w.activeList),
                      activeList: w.lists.find((l) => l.id !== w.activeList)!
                        .id,
                    });
                }}
              >
                Eliminar lista
              </button>
            </div>
            <div className="filter">
              <Search size={14} />
              <input
                aria-label="Filtrar seguimiento"
                placeholder="Filtrar lista"
                value={filter}
                onChange={(e) => setFilter(e.target.value)}
              />
            </div>
            <div className="watch-table-head">
              <span>ACTIVO</span>
              <select
                aria-label="Orden del seguimiento"
                value={sort}
                onChange={(e) => setSort(e.target.value as typeof sort)}
              >
                <option value="manual">Mi orden</option>
                <option value="change">Cambio 24h</option>
                <option value="name">Símbolo</option>
              </select>
            </div>
            <div className="watch-rows">
              {displayed.map((symbol) => {
                const t = tickers.data?.find((t) => t.symbol === symbol);
                const sm = symbols.data?.find((s) => s.symbol === symbol);
                const asset = sm?.baseAsset ?? symbol.replace(/USDT$/, "");
                return (
                  <div
                    key={symbol}
                    className={
                      "watch-row " + (symbol === w.symbol ? "active" : "")
                    }
                  >
                    <button
                      className="watch-asset"
                      onClick={() => changeSymbol(symbol)}
                    >
                      <span className={"coin coin-" + asset}>
                        {asset.slice(0, 1)}
                      </span>
                      <span>
                        <b>{asset}</b>
                        <small>{sm?.quoteAsset ?? symbol}</small>
                      </span>
                    </button>
                    <button
                      className="watch-price"
                      onClick={() => changeSymbol(symbol)}
                    >
                      <b>
                        {number(t?.lastPrice, t && t.lastPrice < 1 ? 5 : 2)}
                      </b>
                      <small
                        className={
                          (t?.priceChangePercent ?? 0) >= 0
                            ? "positive"
                            : "negative"
                        }
                      >
                        {t
                          ? `${t.priceChangePercent >= 0 ? "+" : ""}${number(t.priceChangePercent)}%`
                          : "—"}
                      </small>
                    </button>
                    <div className="row-actions">
                      <button
                        aria-label={`Subir ${symbol}`}
                        disabled={
                          list.symbols.indexOf(symbol) === 0 ||
                          sort !== "manual"
                        }
                        onClick={() => {
                          const array = [...list.symbols];
                          const i = array.indexOf(symbol);
                          [array[i - 1], array[i]] = [array[i], array[i - 1]];
                          editSymbols(array);
                        }}
                      >
                        <ArrowUp size={13} />
                      </button>
                      <button
                        aria-label={`Quitar ${symbol}`}
                        onClick={() =>
                          editSymbols(list.symbols.filter((s) => s !== symbol))
                        }
                      >
                        <X size={13} />
                      </button>
                    </div>
                  </div>
                );
              })}
              {!displayed.length && (
                <p className="empty-small">Añade símbolos con el botón +.</p>
              )}
            </div>
            <button className="add-asset" onClick={() => setModal("search")}>
              <Plus size={15} /> Añadir activo
            </button>
            <div className="watch-footer">
              <span>Precios · actualización cada 30 s</span>
              <small>
                {tickers.isError
                  ? "No se pudieron consultar las cotizaciones"
                  : tickers.dataUpdatedAt
                    ? new Date(tickers.dataUpdatedAt).toLocaleTimeString(
                        "es-MX",
                      )
                    : "Consultando Binance…"}
              </small>
            </div>
          </aside>
        )}
        <section className="chart-section">
          <div className="asset-heading">
            <div className="asset-name">
              <span className={"coin large coin-" + base}>
                {base.slice(0, 1)}
              </span>
              <div>
                <button onClick={() => setModal("search")}>
                  {base} <span>/ {quote}</span>
                  <ChevronDown size={16} />
                </button>
                <small>Binance · Mercado Spot</small>
              </div>
            </div>
            <div className="headline-price">
              <b>{number(last, last !== undefined && last < 1 ? 5 : 2)}</b>
              <span
                className={
                  (ticker?.priceChangePercent ?? 0) >= 0
                    ? "positive"
                    : "negative"
                }
              >
                {ticker
                  ? `${ticker.priceChangePercent >= 0 ? "+" : ""}${number(ticker.priceChangePercent)}%`
                  : "—"}{" "}
                <small>24h</small>
              </span>
            </div>
            <div className="headline-stat">
              <small>MÁXIMO 24H</small>
              <b>{number(ticker?.highPrice)}</b>
            </div>
            <div className="headline-stat">
              <small>VOLUMEN 24H · {quote}</small>
              <b>{compact(ticker?.quoteVolume)}</b>
            </div>
          </div>
          <div className="chart-toolbar">
            <div className="timeframes">
              {(["5m", "15m", "1h", "4h", "1d"] as Interval[]).map((i) => (
                <button
                  key={i}
                  className={w.interval === i ? "active" : ""}
                  onClick={() => update({ interval: i })}
                >
                  {i === "1d" ? "1D" : i}
                </button>
              ))}
              <select
                aria-label="Todas las temporalidades"
                value={w.interval}
                onChange={(e) =>
                  update({ interval: e.target.value as Interval })
                }
              >
                {intervals.map((i) => (
                  <option key={i}>{i}</option>
                ))}
              </select>
            </div>
            <span className="divider" />
            <select
              aria-label="Tipo de gráfica"
              value={w.chartType}
              onChange={(e) =>
                update({ chartType: e.target.value as typeof w.chartType })
              }
            >
              <option value="candles">Velas</option>
              <option value="bars">Barras OHLC</option>
              <option value="line">Línea</option>
              <option value="area">Área</option>
            </select>
            <button
              className={w.volume ? "selected" : ""}
              onClick={() => update({ volume: !w.volume })}
            >
              <Layers size={15} /> Volumen
            </button>
            <div className="toolbar-end">
              <button
                className="icon-button"
                title="Ajustar todo el historial"
                aria-label="Ajustar historial"
                onClick={() => setFit((v) => v + 1)}
              >
                <Expand size={16} />
              </button>
              <button
                className="icon-button"
                disabled={stream.isFetching}
                title="Actualizar datos"
                aria-label="Actualizar datos"
                onClick={() => void stream.refetch()}
              >
                <RefreshCw
                  size={16}
                  className={stream.isFetching ? "spin" : ""}
                />
              </button>
            </div>
          </div>
          {(stream.error || stream.stale || stream.gaps.length > 0) && (
            <div className="data-warning" role="alert">
              {stream.error?.message ??
                (stream.gaps.length
                  ? `${stream.gaps.length} hueco(s) detectado(s). Recuperando historial; pueden persistir si Binance no lo ofrece.`
                  : "Datos sin actualización reciente. Mostrando la última información recibida.")}
              <button
                onClick={() => void stream.refetch()}
                disabled={stream.isFetching}
              >
                Reintentar
              </button>
            </div>
          )}
          <MonitorWorkbench
            context={{
              candles: stream.candles,
              symbol: w.symbol,
              interval: w.interval,
              indicators: analysis.setup.indicators,
              drawings: analysis.setup.drawings[marketKey] ?? [],
              script,
            }}
            structure={structure}
            messages={alerts.messages}
            now={alerts.now}
            onSelect={(symbol, interval) => update({ symbol, interval })}
          />
          <ScriptWorkbench
            candles={stream.candles}
            marketKey={marketKey}
            activeName={script.active?.name}
            busy={script.busy}
            error={script.error}
          />
          <AnalysisWorkbench
            marketKey={marketKey}
            tool={drawingTool}
            onTool={setDrawingTool}
            selected={selectedDrawing}
            onSelected={setSelectedDrawing}
          />
          <div
            className="chart-area"
            style={{
              minHeight:
                440 +
                (script.result && !script.result.overlay ? 180 : 0) +
                analysis.setup.indicators
                  .filter(
                    (i) => i.visible && registry[i.kind].location === "pane",
                  )
                  .reduce((sum, i) => sum + i.height, 0),
            }}
          >
            <Chart
              structure={structure}
              structureConfig={monitor.structure}
              scriptResult={script.result}
              indicators={analysis.setup.indicators}
              drawings={analysis.setup.drawings[marketKey] ?? []}
              tool={drawingTool}
              onTool={setDrawingTool}
              onDrawingsChange={(items) => setDrawings(marketKey, items)}
              selectedDrawing={selectedDrawing}
              onSelectedDrawing={setSelectedDrawing}
              candles={stream.candles}
              chartType={w.chartType}
              volume={w.volume}
              marketKey={w.symbol + "-" + w.interval}
              onOlder={older}
              canLoad={!!stream.hasNextPage && !stream.isFetching}
              fitToken={fit}
            />
            {!stream.candles.length && (
              <div className="chart-empty">
                <Activity size={40} />
                <h2>
                  {stream.isPending
                    ? "Conectando con el mercado"
                    : "Datos no disponibles"}
                </h2>
                <p>
                  {stream.isPending
                    ? "Solicitando velas reales a Binance Spot…"
                    : "No hay velas verificadas para mostrar. Revisa el aviso de conexión y vuelve a intentarlo."}
                </p>
              </div>
            )}
          </div>
          <div className="chart-status">
            <button
              disabled={!stream.hasNextPage || stream.isFetching}
              onClick={older}
            >
              <ChevronLeft size={14} />
              {isBusy ? "Cargando…" : "Cargar historial anterior"}
            </button>
            <span>
              {stream.candles.length.toLocaleString()} velas{" "}
              <span className="muted">· UTC · {w.interval}</span>
            </span>
          </div>
          <div className="bottom-panel">
            <div className="bottom-tabs">
              <button
                className={tab === "data" ? "active" : ""}
                onClick={() => {
                  setTab("data");
                  setBottom(true);
                }}
              >
                Datos OHLCV
              </button>
              <button
                className={tab === "connection" ? "active" : ""}
                onClick={() => {
                  setTab("connection");
                  setBottom(true);
                }}
              >
                Conexión
              </button>
              <button
                className={tab === "roadmap" ? "active" : ""}
                onClick={() => {
                  setTab("roadmap");
                  setBottom(true);
                }}
              >
                Estado del proyecto
              </button>
              <button
                className="collapse"
                aria-label={
                  bottom ? "Ocultar panel inferior" : "Mostrar panel inferior"
                }
                onClick={() => setBottom(!bottom)}
              >
                {bottom ? <ChevronDown size={16} /> : <ChevronUpIcon />}
              </button>
            </div>
            {bottom && (
              <div className="bottom-content">
                {tab === "data" ? (
                  <>
                    <div className="table-caption">
                      <span>Últimas 20 velas · volumen en {base}</span>
                      <button
                        disabled={!stream.candles.length}
                        onClick={() =>
                          download(
                            w.symbol + "-" + w.interval + ".csv",
                            "time_utc,open,high,low,close,volume,closed,source\n" +
                              stream.candles
                                .map((c) =>
                                  [
                                    new Date(c.time * 1000).toISOString(),
                                    c.open,
                                    c.high,
                                    c.low,
                                    c.close,
                                    c.volume,
                                    c.closed,
                                    c.source,
                                  ].join(","),
                                )
                                .join("\n"),
                            "text/csv",
                          )
                        }
                      >
                        <Download size={13} /> Exportar CSV
                      </button>
                    </div>
                    <div className="data-scroll">
                      <table>
                        <thead>
                          <tr>
                            {[
                              "Fecha · UTC",
                              "Apertura",
                              "Máximo",
                              "Mínimo",
                              "Cierre",
                              "Volumen",
                              "Estado",
                            ].map((h) => (
                              <th key={h}>{h}</th>
                            ))}
                          </tr>
                        </thead>
                        <tbody>
                          {stream.candles
                            .slice(-20)
                            .reverse()
                            .map((c) => (
                              <tr key={c.time}>
                                <td>
                                  {new Date(c.time * 1000)
                                    .toISOString()
                                    .slice(5, 16)
                                    .replace("T", " ")}
                                </td>
                                <td>{number(c.open)}</td>
                                <td>{number(c.high)}</td>
                                <td>{number(c.low)}</td>
                                <td
                                  className={
                                    c.close >= c.open ? "positive" : "negative"
                                  }
                                >
                                  {number(c.close)}
                                </td>
                                <td>{compact(c.volume)}</td>
                                <td>{c.closed ? "Cerrada" : "En formación"}</td>
                              </tr>
                            ))}
                        </tbody>
                      </table>
                      {!stream.candles.length && (
                        <p className="empty-small">
                          Las velas aparecerán cuando responda el proveedor.
                        </p>
                      )}
                    </div>
                  </>
                ) : tab === "connection" ? (
                  <div className="connection-details">
                    <p>
                      <b>Fuente:</b> Binance Spot · datos públicos reales. Sin
                      datos simulados.
                    </p>
                    <p>
                      <b>WebSocket:</b> {stream.connection} ·{" "}
                      {stream.updated
                        ? "Última recepción: " +
                          new Date(stream.updated).toLocaleString("es-MX")
                        : "Sin recepción confirmada"}
                      .
                    </p>
                    <p>
                      <b>Recuperación:</b> reconexión exponencial hasta 30 s y
                      consulta REST cada 30 s mientras no hay flujo.{" "}
                      {stream.gaps.length} huecos detectados.
                    </p>
                    <p>
                      Los precios del seguimiento se consultan cada 30 s. La
                      vela actual puede cambiar hasta su cierre.
                    </p>
                  </div>
                ) : (
                  <div className="connection-details">
                    <p>
                      <b className="positive">Fase 1 · Implementada:</b> mercado
                      Spot, gráficos, volumen, historial y listas locales.
                    </p>
                    <p>
                      <b>Fase 2:</b> indicadores, paneles, dibujos editables y
                      plantillas locales. <b>Pendiente:</b> compatibilidad Pine
                      ampliada y servicios de servidor.
                    </p>
                    <p>
                      <b>Pine Script:</b> subconjunto v5/v6 disponible en el
                      editor. Revisa el informe de compatibilidad antes de
                      añadir un script.
                    </p>
                    <p>
                      Alertas locales al cierre disponibles. Sin ejecución de
                      operaciones, cuentas ni alertas con la pestaña cerrada.
                    </p>
                  </div>
                )}
              </div>
            )}
          </div>
        </section>
        {w.showDetails && (
          <aside className="details">
            <div className="panel-heading">
              <span>RESUMEN DEL ACTIVO</span>
              <button
                className="icon-button"
                aria-label="Ocultar resumen"
                onClick={() => update({ showDetails: false })}
              >
                <ChevronRight size={17} />
              </button>
            </div>
            <div className="detail-hero">
              <span className={"coin extra coin-" + base}>
                {base.slice(0, 1)}
              </span>
              <h2>
                {base}
                <span> / {quote}</span>
              </h2>
              <span className="spot-badge">SPOT</span>
              <p className="detail-price">
                {number(last, last !== undefined && last < 1 ? 5 : 2)}
                <small>{quote}</small>
              </p>
              <span
                className={
                  (ticker?.priceChangePercent ?? 0) >= 0
                    ? "positive"
                    : "negative"
                }
              >
                {ticker
                  ? `${number(ticker.priceChangePercent)}% en las últimas 24h`
                  : "Cambio 24h no disponible"}
              </span>
            </div>
            <div className="detail-block">
              <h3>Estadísticas de mercado</h3>
              <dl>
                <dt>Máximo 24h</dt>
                <dd>{number(ticker?.highPrice)}</dd>
                <dt>Mínimo 24h</dt>
                <dd>{number(ticker?.lowPrice)}</dd>
                <dt>Volumen · {base}</dt>
                <dd>{compact(ticker?.volume)}</dd>
                <dt>Volumen · {quote}</dt>
                <dd>{compact(ticker?.quoteVolume)}</dd>
              </dl>
            </div>
            <div className="detail-block">
              <h3>Rango de 24 horas</h3>
              <div className="range-bar">
                <span
                  style={{
                    left: `${ticker && last !== undefined && ticker.highPrice > ticker.lowPrice ? Math.max(0, Math.min(100, ((last - ticker.lowPrice) / (ticker.highPrice - ticker.lowPrice)) * 100)) : 0}%`,
                  }}
                />
              </div>
              <div className="range-labels">
                <span>{number(ticker?.lowPrice)}</span>
                <span>{number(ticker?.highPrice)}</span>
              </div>
            </div>
            <div className="detail-block source-block">
              <h3>
                <Wifi size={14} /> Origen de los datos
              </h3>
              <p>Binance Spot</p>
              <small>
                {ticker
                  ? "Estadísticas: " +
                    new Date(ticker.closeTime).toLocaleTimeString("es-MX")
                  : "Estadísticas no disponibles"}
                <br />
                {stream.updated
                  ? "Velas: " +
                    new Date(stream.updated).toLocaleTimeString("es-MX")
                  : "Velas no disponibles"}
              </small>
            </div>
            <div className="detail-note">
              Análisis local, sin registro.
              <br />
              No se envían órdenes al exchange.
            </div>
          </aside>
        )}
      </main>
      <footer className="app-footer">
        <span>
          <span className={live ? "status-dot" : "status-dot idle"} />
          {live
            ? "BINANCE SPOT · EN VIVO"
            : "BINANCE SPOT · CONEXIÓN PENDIENTE"}
        </span>
        <span>
          Fase 4{" "}
          <span className="footer-hidden">
            · Sin sincronización entre dispositivos
          </span>
        </span>
        <a href="https://www.tradingview.com/" target="_blank" rel="noreferrer">
          Gráficos por TradingView <ExternalLink size={11} />
        </a>
      </footer>
      <dialog
        aria-labelledby="dialog-title"
        ref={dialog}
        onCancel={() => setModal(null)}
        onClick={(e) => {
          if (e.target === dialog.current) setModal(null);
        }}
      >
        <div className="dialog-header">
          <h2 id="dialog-title">
            {modal === "search"
              ? "Buscar un activo"
              : modal === "settings"
                ? "Ajustes del espacio"
                : "CRIPTO CHART TERMINAL"}
          </h2>
          <button
            className="icon-button"
            aria-label="Cerrar ventana"
            onClick={() => setModal(null)}
          >
            <X size={20} />
          </button>
        </div>
        {modal === "search" ? (
          <>
            <div className="symbol-search">
              <Search size={20} />
              <input
                ref={searchInput}
                value={search}
                onChange={(e) => setSearch(e.target.value)}
                placeholder="BTC, ETH, SOL…"
                aria-label="Buscar símbolos de Binance"
              />
            </div>
            <p className="dialog-caption">
              Binance Spot · {symbols.data?.length ?? 0} pares disponibles
            </p>
            <div className="symbol-results">
              {symbols.isError ? (
                <p>
                  No se pudo descubrir el catálogo.{" "}
                  <button onClick={() => void symbols.refetch()}>
                    Reintentar
                  </button>
                </p>
              ) : symbols.isPending ? (
                <p>Cargando catálogo del proveedor…</p>
              ) : (
                symbols.data
                  ?.filter((s) =>
                    s.symbol.includes(
                      search.toUpperCase().replace(/[ /]/g, ""),
                    ),
                  )
                  .slice(0, 60)
                  .map((s) => (
                    <div key={s.symbol}>
                      <button onClick={() => changeSymbol(s.symbol)}>
                        <b>{s.baseAsset}</b>
                        <span>{s.quoteAsset}</span>
                        <small>{s.symbol}</small>
                      </button>
                      <button
                        className="icon-button"
                        title="Añadir al seguimiento"
                        aria-label={`Añadir ${s.symbol}`}
                        disabled={list.symbols.includes(s.symbol)}
                        onClick={() => add(s.symbol)}
                      >
                        {list.symbols.includes(s.symbol) ? (
                          <Check size={17} />
                        ) : (
                          <Plus size={17} />
                        )}
                      </button>
                    </div>
                  ))
              )}
            </div>
          </>
        ) : modal === "settings" ? (
          <div className="settings-content">
            <p>
              Tu espacio se guarda en este navegador. Exporta una copia para
              trasladarlo a otro dispositivo.
            </p>
            <button
              className="primary-button"
              onClick={() =>
                download(
                  "cripto-chart-workspace.json",
                  JSON.stringify(
                    { version: 2, workspace: w, analysis },
                    null,
                    2,
                  ),
                )
              }
            >
              <Download size={16} /> Exportar espacio
            </button>
            <label className="import-button">
              Importar espacio
              <input
                type="file"
                accept=".json,application/json"
                onChange={async (e) => {
                  const file = e.target.files?.[0];
                  if (!file) return;
                  try {
                    if (file.size > 5_000_000)
                      throw new Error("El archivo supera 5 MB.");
                    const parsed = parseBundle(JSON.parse(await file.text()));
                    setAnalysis(parsed.analysis);
                    update(parsed.workspace);
                    setNotice("Espacio importado.");
                    setModal(null);
                  } catch {
                    setNotice(
                      "Archivo inválido. El espacio actual se conserva.",
                    );
                    setModal(null);
                  }
                  e.target.value = "";
                }}
              />
            </label>
            <hr />
            <label>
              <input
                type="checkbox"
                checked={w.volume}
                onChange={(e) => update({ volume: e.target.checked })}
              />{" "}
              Mostrar volumen
            </label>
            <label>
              <input
                type="checkbox"
                checked={w.showWatchlist}
                onChange={(e) => update({ showWatchlist: e.target.checked })}
              />{" "}
              Mostrar seguimiento
            </label>
            <label>
              <input
                type="checkbox"
                checked={w.showDetails}
                onChange={(e) => update({ showDetails: e.target.checked })}
              />{" "}
              Mostrar resumen
            </label>
            <p className="muted">
              Atajos: / buscar · Alt+W seguimiento · Esc cerrar.
            </p>
          </div>
        ) : (
          <div className="settings-content">
            <p>
              Terminal independiente para analizar criptomonedas. Fases 1, 2 y
              primer subconjunto de la Fase 3 y módulos locales de la Fase 4:
              datos de Binance Spot, indicadores, dibujos y plantillas.
            </p>
            <p>
              Compatibilidad Pine Script parcial, detallada en el editor. No
              está afiliado con Binance ni TradingView.
            </p>
            <p>
              TradingView Lightweight Charts™
              <br />
              Copyright (c) 2026 TradingView, Inc.
              <br />
              Licencia Apache-2.0.
            </p>
            <p>
              Consulta README.md y ROADMAP.md en el código fuente para conocer
              arquitectura, pruebas y pendientes.
            </p>
          </div>
        )}
      </dialog>
    </div>
  );
}
function ChevronUpIcon() {
  return <ArrowUp size={16} />;
}
