import { describe, it, expect, vi, afterEach } from "vitest";
import { BinanceAdapter } from "./binance";
class Socket {
  static sockets: Socket[] = [];
  onopen: (() => void) | null = null;
  onmessage: ((e: { data: string }) => void) | null = null;
  onerror: (() => void) | null = null;
  onclose: (() => void) | null = null;
  constructor(public url: string) {
    Socket.sockets.push(this);
  }
  close() {
    this.onclose?.();
  }
}
afterEach(() => {
  vi.useRealTimers();
  vi.unstubAllGlobals();
  Socket.sockets = [];
});
describe("WebSocket Binance", () => {
  it("reconecta con espera y recupera REST sin eventos duplicados", async () => {
    vi.useFakeTimers();
    vi.stubGlobal("WebSocket", Socket);
    vi.stubGlobal("navigator", { onLine: true });
    const data = vi.fn(),
      status = vi.fn(),
      recover = vi.fn();
    const stop = new BinanceAdapter().subscribeCandles(
      "BTCUSDT",
      "1m",
      data,
      status,
      recover,
    );
    let ws = Socket.sockets[0];
    ws.onopen?.();
    const event = {
      E: 123,
      k: {
        t: 0,
        T: 59999,
        s: "BTCUSDT",
        i: "1m",
        o: "10",
        h: "12",
        l: "9",
        c: "11",
        v: "2",
        x: true,
      },
    };
    ws.onmessage?.({ data: JSON.stringify(event) });
    ws.onmessage?.({ data: JSON.stringify(event) });
    expect(data).toHaveBeenCalledTimes(1);
    ws.close();
    await vi.advanceTimersByTimeAsync(1400);
    expect(Socket.sockets).toHaveLength(2);
    ws = Socket.sockets[1];
    ws.onopen?.();
    expect(recover).toHaveBeenCalledOnce();
    stop();
    await vi.advanceTimersByTimeAsync(60000);
    expect(Socket.sockets).toHaveLength(2);
  });
  it("ignora eventos de otro símbolo", () => {
    vi.useFakeTimers();
    vi.stubGlobal("WebSocket", Socket);
    const data = vi.fn();
    const stop = new BinanceAdapter().subscribeCandles(
      "ETHUSDT",
      "1h",
      data,
      vi.fn(),
      vi.fn(),
    );
    Socket.sockets[0].onmessage?.({
      data: JSON.stringify({
        E: 1,
        k: {
          t: 0,
          T: 59999,
          s: "BTCUSDT",
          i: "1m",
          o: 10,
          h: 12,
          l: 9,
          c: 11,
          v: 2,
          x: false,
        },
      }),
    });
    expect(data).not.toHaveBeenCalled();
    stop();
  });
});
