import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import { useInfiniteQuery, useQueryClient } from "@tanstack/react-query";
import {
  findGaps,
  mergeCandles,
  type Candle,
  type Connection,
  type Interval,
} from "../domain/types";
import { market, MarketError } from "./binance";
export function useMarket(symbol: string, interval: Interval) {
  const queryClient = useQueryClient();
  const [live, setLive] = useState<{ key: string; bars: Candle[] }>({
    key: "",
    bars: [],
  });
  const [connection, setConnection] = useState<Connection>("connecting");
  const [updated, setUpdated] = useState(0);
  const [clock, setClock] = useState(Date.now());
  const recovery = useRef(0);
  const query = useInfiniteQuery({
    queryKey: ["candles", symbol, interval],
    queryFn: ({ pageParam, signal }) =>
      market.getCandles(symbol, interval, pageParam, signal),
    initialPageParam: undefined as number | undefined,
    getNextPageParam: (last) =>
      last.length === 500 ? last[0].time * 1000 - 1 : undefined,
    staleTime: 15000,
    retry: (count, error) =>
      !(
        error instanceof MarketError && [418, 429, 451].includes(error.status)
      ) && count < 1,
  });
  const recover = useCallback(() => {
    if (Date.now() - recovery.current < 15000) return;
    recovery.current = Date.now();
    void queryClient.invalidateQueries({
      queryKey: ["candles", symbol, interval],
    });
  }, [symbol, interval, queryClient]);
  useEffect(() => {
    setLive({ key: symbol + interval, bars: [] });
    setUpdated(0);
    recovery.current = 0;
    setConnection("connecting");
    return market.subscribeCandles(
      symbol,
      interval,
      (c) => {
        setLive((previous) => ({
          key: symbol + interval,
          bars: mergeCandles(
            previous.key === symbol + interval ? previous.bars : [],
            [c],
          ).slice(-1000),
        }));
        setUpdated(Date.now());
      },
      setConnection,
      recover,
    );
  }, [symbol, interval, recover]);
  useEffect(() => {
    const t = setInterval(() => setClock(Date.now()), 5000);
    return () => clearInterval(t);
  }, []);
  const candles = useMemo(
    () =>
      mergeCandles(
        query.data?.pages.flat() ?? [],
        live.key === symbol + interval ? live.bars : [],
      ),
    [query.data, live, symbol, interval],
  );
  const gaps = useMemo(() => findGaps(candles, interval), [candles, interval]);
  useEffect(() => {
    if (gaps.length) recover();
  }, [gaps.length, recover]);
  // An explicit REST fallback while the socket is unavailable; never label polling as a live stream.
  useEffect(() => {
    if (connection === "live") return;
    const t = setInterval(recover, 30000);
    return () => clearInterval(t);
  }, [connection, recover]);
  const timestamp = Math.max(updated, query.dataUpdatedAt);
  return {
    ...query,
    candles,
    gaps,
    connection,
    updated: timestamp,
    stale: timestamp > 0 && clock - timestamp > 30000,
  };
}
