import { z } from "zod";
import {
  type Candle,
  type MarketAdapter,
  type Interval,
  type Connection,
} from "../domain/types";
const numeric = z.coerce.number().finite().nonnegative();
const row = z
  .tuple([z.number(), numeric, numeric, numeric, numeric, numeric, z.number()])
  .rest(z.unknown());
export function parseCandle(raw: unknown, now = Date.now()): Candle {
  const [time, open, high, low, close, volume, closeTime] = row.parse(raw);
  if (
    low > Math.min(open, close) ||
    high < Math.max(open, close) ||
    low > high ||
    closeTime < time
  )
    throw new Error("Vela OHLCV inválida");
  return {
    time: time / 1000,
    open,
    high,
    low,
    close,
    volume,
    closeTime,
    closed: closeTime < now,
    source: "Binance Spot",
    receivedAt: now,
  };
}
const symbolsSchema = z.object({
  symbols: z.array(
    z.object({
      symbol: z.string(),
      baseAsset: z.string(),
      quoteAsset: z.string(),
      status: z.string(),
      isSpotTradingAllowed: z.boolean().optional(),
    }),
  ),
});
const tickerSchema = z.array(
  z.object({
    symbol: z.string(),
    lastPrice: numeric,
    priceChangePercent: z.coerce.number().finite(),
    volume: numeric,
    quoteVolume: numeric,
    highPrice: numeric,
    lowPrice: numeric,
    closeTime: z.number(),
  }),
);
const eventSchema = z.object({
  E: z.number(),
  k: z.object({
    t: z.number(),
    T: z.number(),
    s: z.string(),
    i: z.string(),
    o: numeric,
    h: numeric,
    l: numeric,
    c: numeric,
    v: numeric,
    x: z.boolean(),
  }),
});
export class MarketError extends Error {
  constructor(
    message: string,
    public status = 0,
  ) {
    super(message);
  }
}
// Shared serialized queue: at most two requests per second; 429/418 stop all work until Retry-After.
let queue = Promise.resolve();
let nextRequest = 0;
function schedule<T>(task: () => Promise<T>, signal?: AbortSignal): Promise<T> {
  const job = queue
    .catch(() => {})
    .then(async () => {
      signal?.throwIfAborted();
      await new Promise((r) =>
        setTimeout(r, Math.max(0, nextRequest - Date.now())),
      );
      signal?.throwIfAborted();
      nextRequest = Date.now() + 500;
      return task();
    });
  queue = job.then(
    () => {},
    () => {},
  );
  return job;
}
export class BinanceAdapter implements MarketAdapter {
  async request(path: string, signal?: AbortSignal): Promise<unknown> {
    return schedule(async () => {
      let error: unknown;
      for (const base of [
        "https://data-api.binance.vision",
        "https://api.binance.com",
      ]) {
        try {
          const response = await fetch(base + "/api/v3/" + path, {
            signal: signal
              ? AbortSignal.any([signal, AbortSignal.timeout(12000)])
              : AbortSignal.timeout(12000),
          });
          if (!response.ok) {
            if (response.status === 429 || response.status === 418) {
              nextRequest =
                Date.now() +
                Math.max(
                  60000,
                  Number(response.headers.get("Retry-After") ?? 60) * 1000,
                );
              throw new MarketError(
                "Límite de Binance alcanzado. Espera antes de reintentar.",
                response.status,
              );
            }
            throw new MarketError(
              `Binance no disponible (HTTP ${response.status}). Puede haber una restricción de red o región.`,
              response.status,
            );
          }
          return await response.json();
        } catch (e) {
          signal?.throwIfAborted();
          error = e;
          if (e instanceof MarketError && [429, 418, 451].includes(e.status))
            throw e;
        }
      }
      throw error instanceof MarketError
        ? error
        : new MarketError(
            "No se pudo conectar con Binance. Revisa tu conexión o las restricciones del proveedor.",
          );
    }, signal);
  }
  async getSymbols(signal?: AbortSignal) {
    const data = symbolsSchema.parse(
      await this.request("exchangeInfo", signal),
    );
    return data.symbols
      .filter((s) => s.status === "TRADING" && s.isSpotTradingAllowed !== false)
      .map(({ symbol, baseAsset, quoteAsset }) => ({
        symbol,
        baseAsset,
        quoteAsset,
      }));
  }
  async getCandles(
    symbol: string,
    interval: Interval,
    endTime?: number,
    signal?: AbortSignal,
  ) {
    const query = new URLSearchParams({ symbol, interval, limit: "500" });
    if (endTime !== undefined) query.set("endTime", String(endTime));
    const data = z
      .array(z.unknown())
      .parse(await this.request("klines?" + query, signal));
    const now = Date.now();
    return data.map((c) => parseCandle(c, now));
  }
  async getTickers(symbols: string[], signal?: AbortSignal) {
    if (!symbols.length) return [];
    return tickerSchema.parse(
      await this.request(
        "ticker/24hr?" +
          new URLSearchParams({
            symbols: JSON.stringify([...new Set(symbols)].slice(0, 21)),
          }),
        signal,
      ),
    );
  }
  subscribeCandles(
    symbol: string,
    interval: Interval,
    onCandle: (c: Candle) => void,
    onStatus: (s: Connection) => void,
    onRecover: () => void,
  ) {
    let disposed = false;
    let ws: WebSocket | undefined;
    let timer: ReturnType<typeof setTimeout> | undefined;
    let attempts = 0;
    let lastEvent = 0;
    let lastSeen = Date.now();
    let opened = false;
    const connect = () => {
      if (disposed) return;
      onStatus(attempts ? "reconnecting" : "connecting");
      ws = new WebSocket(
        `wss://data-stream.binance.vision/ws/${symbol.toLowerCase()}@kline_${interval}`,
      );
      ws.onopen = () => {
        if (disposed) return;
        lastSeen = Date.now();
        onStatus("live");
        if (opened) onRecover();
        opened = true;
      };
      ws.onmessage = (event) => {
        if (disposed) return;
        try {
          const data = eventSchema.parse(JSON.parse(event.data));
          lastSeen = Date.now();
          if (
            data.E <= lastEvent ||
            data.k.s !== symbol ||
            data.k.i !== interval
          )
            return;
          lastEvent = data.E;
          attempts = 0;
          const k = data.k;
          const c = parseCandle([k.t, k.o, k.h, k.l, k.c, k.v, k.T]);
          c.closed = k.x;
          onCandle(c);
        } catch {
          onStatus("reconnecting");
          ws?.close();
        }
      };
      ws.onerror = () => ws?.close();
      ws.onclose = () => {
        if (disposed) return;
        onStatus(navigator.onLine ? "reconnecting" : "offline");
        timer = setTimeout(
          connect,
          Math.min(30000, 1000 * 2 ** Math.min(attempts++, 5)) +
            Math.random() * 300,
        );
      };
    };
    connect();
    const watchdog = setInterval(() => {
      if (Date.now() - lastSeen > 20000) {
        onStatus("reconnecting");
        ws?.close();
        lastSeen = Date.now();
      }
    }, 5000);
    return () => {
      disposed = true;
      clearTimeout(timer);
      clearInterval(watchdog);
      ws?.close();
    };
  }
}
export const market = new BinanceAdapter();
