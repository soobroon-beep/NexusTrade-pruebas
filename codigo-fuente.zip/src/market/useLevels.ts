import { useQuery } from "@tanstack/react-query";
import { market } from "./binance";
import type { Candle } from "../domain/types";
export function priorLevels(candles: Candle[]) {
  const closed = candles.filter((c) => c.closed),
    bar = closed.at(-1);
  if (!bar) return undefined;
  const p = (bar.high + bar.low + bar.close) / 3;
  return {
    bar,
    p,
    r1: 2 * p - bar.low,
    s1: 2 * p - bar.high,
    r2: p + bar.high - bar.low,
    s2: p - bar.high + bar.low,
  };
}
export function useLevels(symbol: string, enabled: boolean) {
  const daily = useQuery({
    queryKey: ["levels", symbol, "1d"],
    queryFn: ({ signal }) => market.getCandles(symbol, "1d", undefined, signal),
    enabled,
    staleTime: 60000,
    refetchInterval: enabled ? 60000 : false,
    retry: 1,
  });
  const weekly = useQuery({
    queryKey: ["levels", symbol, "1w"],
    queryFn: ({ signal }) => market.getCandles(symbol, "1w", undefined, signal),
    enabled,
    staleTime: 60000,
    refetchInterval: enabled ? 60000 : false,
    retry: 1,
  });
  return { daily, weekly };
}
