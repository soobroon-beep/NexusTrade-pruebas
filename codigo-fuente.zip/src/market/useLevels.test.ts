import { it, expect } from "vitest";
import { priorLevels } from "./useLevels";
import type { Candle } from "../domain/types";
it("pivotes excluyen el periodo abierto y usan HLC del último cerrado", () => {
  const c: Candle = {
    time: 0,
    open: 10,
    high: 15,
    low: 9,
    close: 12,
    volume: 1,
    closed: true,
    closeTime: 59999,
    receivedAt: 0,
    source: "Binance Spot",
  };
  expect(
    priorLevels([c, { ...c, time: 60, high: 99, closed: false }]),
  ).toMatchObject({ p: 12, r1: 15, s1: 9, r2: 18, s2: 6 });
  expect(priorLevels([{ ...c, closed: false }])).toBeUndefined();
});
