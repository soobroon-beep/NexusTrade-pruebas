// @vitest-environment jsdom
import { describe, it, expect, vi, afterEach } from "vitest";
import { renderHook, waitFor, cleanup, act } from "@testing-library/react";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import type { ReactNode } from "react";
import { useMarket } from "./useMarket";
import { market, parseCandle } from "./binance";
import type { Interval, Candle } from "../domain/types";
afterEach(() => {
  cleanup();
  vi.restoreAllMocks();
});
describe("cambio de contexto de mercado", () => {
  it("no mezcla velas de símbolos o temporalidades y libera suscripciones", async () => {
    const candle = parseCandle([0, 10, 12, 9, 11, 2, 59999]);
    const unsubscribe = vi.fn();
    let send: (c: Candle) => void = () => {};
    vi.spyOn(market, "getCandles").mockImplementation(async (symbol) => [
      { ...candle, close: symbol === "BTCUSDT" ? 11 : 10 },
    ]);
    vi.spyOn(market, "subscribeCandles").mockImplementation(
      (_s, _i, onCandle) => {
        send = onCandle;
        return unsubscribe;
      },
    );
    const client = new QueryClient({
      defaultOptions: { queries: { retry: false } },
    });
    const wrapper = ({ children }: { children: ReactNode }) => (
      <QueryClientProvider client={client}>{children}</QueryClientProvider>
    );
    const { result, rerender, unmount } = renderHook(
      ({ symbol, interval }: { symbol: string; interval: Interval }) =>
        useMarket(symbol, interval),
      { wrapper, initialProps: { symbol: "BTCUSDT", interval: "1h" } },
    );
    await waitFor(() => expect(result.current.candles[0]?.close).toBe(11));
    act(() => send({ ...candle, time: 60, closed: false }));
    expect(result.current.candles).toHaveLength(2);
    rerender({ symbol: "ETHUSDT", interval: "4h" });
    await waitFor(() => expect(result.current.candles[0]?.close).toBe(10));
    expect(result.current.candles).toHaveLength(1);
    expect(market.getCandles).toHaveBeenCalledWith(
      "ETHUSDT",
      "4h",
      undefined,
      expect.any(AbortSignal),
    );
    expect(unsubscribe).toHaveBeenCalled();
    unmount();
    client.clear();
  });
});
