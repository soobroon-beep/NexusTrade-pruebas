import { z } from "zod";
import { nextOpen, type Candle, type Interval } from "../domain/types";
export const structureConfigSchema = z
  .object({
    enabled: z.boolean(),
    swings: z.boolean(),
    breaks: z.boolean(),
    sweeps: z.boolean(),
    fvg: z.boolean(),
    blocks: z.boolean(),
    session: z.boolean(),
    left: z.number().int().min(1).max(20),
    right: z.number().int().min(1).max(20),
    minGapPercent: z.number().min(0).max(10),
    blockLookback: z.number().int().min(1).max(100),
    sessionStart: z.number().int().min(0).max(23),
    sessionEnd: z.number().int().min(0).max(23),
  })
  .refine(
    (c) => c.sessionStart !== c.sessionEnd,
    "La sesión debe tener horas distintas.",
  );
export type StructureConfig = z.infer<typeof structureConfigSchema>;
export const defaultStructure: StructureConfig = {
  enabled: false,
  swings: true,
  breaks: true,
  sweeps: false,
  fvg: true,
  blocks: false,
  session: false,
  left: 3,
  right: 3,
  minGapPercent: 0.05,
  blockLookback: 20,
  sessionStart: 8,
  sessionEnd: 16,
};
export type StructureEvent = {
  id: string;
  type: "SH" | "SL" | "BOS" | "CHoCH" | "Ruptura" | "Barrido";
  direction: 1 | -1;
  time: number;
  price: number;
  origin: number;
  description: string;
};
export type Zone = {
  id: string;
  type: "FVG" | "OB" | "Sesión";
  direction: 1 | -1;
  time: number;
  origin: number;
  end: number;
  low: number;
  high: number;
  status: "abierta" | "tocada" | "cubierta" | "interrumpida" | "rango parcial";
};
export type StructureResult = {
  events: StructureEvent[];
  zones: Zone[];
  support?: number;
  resistance?: number;
  bias: 1 | -1 | 0;
  bars: number;
  truncated: boolean;
  gaps: number;
};
export function analyzeStructure(
  all: Candle[],
  interval: Interval,
  config: StructureConfig,
): StructureResult {
  structureConfigSchema.parse(config);
  const source = all.filter((c) => c.closed),
    bars = source.slice(-2000),
    events: StructureEvent[] = [],
    zones: Zone[] = [];
  let high:
      | { price: number; time: number; broken: boolean; swept: boolean }
      | undefined,
    low: typeof high,
    bias: 1 | -1 | 0 = 0,
    start = 0,
    gaps = 0;
  const pushZone = (
    type: "FVG" | "OB",
    direction: 1 | -1,
    i: number,
    origin: number,
    lo: number,
    hi: number,
  ) => {
    if (hi > lo)
      zones.push({
        id: `${type}:${direction}:${bars[i].time}`,
        type,
        direction,
        time: bars[i].time,
        origin,
        end: bars[i].time,
        low: lo,
        high: hi,
        status: "abierta",
      });
    if (zones.length > 100) zones.shift();
  };
  for (let i = 0; i < bars.length; i++) {
    const c = bars[i];
    if (i && nextOpen(bars[i - 1].time, interval) !== c.time) {
      gaps++;
      start = i;
      high = low = undefined;
      bias = 0;
      for (const z of zones)
        if (z.status === "abierta" || z.status === "tocada") {
          z.status = "interrumpida";
          z.end = bars[i - 1].time;
        }
    }
    for (const z of zones) {
      if (z.status !== "abierta" && z.status !== "tocada") continue;
      z.end = c.time;
      if (z.time === c.time) continue;
      const touch = z.direction === 1 ? c.low <= z.high : c.high >= z.low,
        covered = z.direction === 1 ? c.low <= z.low : c.high >= z.high;
      if (covered) z.status = "cubierta";
      else if (touch) z.status = "tocada";
    }
    for (const [pivot, direction] of [
      [high, 1],
      [low, -1],
    ] as const) {
      if (!pivot || pivot.broken) continue;
      const broken =
        direction === 1 ? c.close > pivot.price : c.close < pivot.price;
      if (broken) {
        const type =
          bias === 0 ? "Ruptura" : bias === direction ? "BOS" : "CHoCH";
        events.push({
          id: `${type}:${direction}:${c.time}`,
          type,
          direction,
          time: c.time,
          origin: pivot.time,
          price: pivot.price,
          description: `Cierre ${direction === 1 ? "sobre" : "bajo"} swing confirmado; orientación previa ${bias}.`,
        });
        pivot.broken = true;
        bias = direction;
        if (config.blocks) {
          for (
            let j = i - 1;
            j >= Math.max(start, i - config.blockLookback);
            j--
          ) {
            const b = bars[j];
            if (direction === 1 ? b.close < b.open : b.close > b.open) {
              pushZone("OB", direction, i, b.time, b.low, b.high);
              break;
            }
          }
        }
      } else if (
        !pivot.swept &&
        (direction === 1
          ? c.high > pivot.price && c.close <= pivot.price
          : c.low < pivot.price && c.close >= pivot.price)
      ) {
        events.push({
          id: `Barrido:${direction}:${c.time}`,
          type: "Barrido",
          direction: direction === 1 ? -1 : 1,
          time: c.time,
          price: pivot.price,
          origin: pivot.time,
          description:
            "Mecha cruza el swing y el cierre vuelve al mismo lado; primera ocurrencia por swing.",
        });
        pivot.swept = true;
      }
    }
    if (i - start >= 2 && config.fvg) {
      const a = bars[i - 2];
      if (
        a.high < c.low &&
        ((c.low - a.high) / Math.max(Math.abs(c.close), 1e-12)) * 100 >=
          config.minGapPercent
      )
        pushZone("FVG", 1, i, a.time, a.high, c.low);
      if (
        a.low > c.high &&
        ((a.low - c.high) / Math.max(Math.abs(c.close), 1e-12)) * 100 >=
          config.minGapPercent
      )
        pushZone("FVG", -1, i, a.time, c.high, a.low);
    }
    const p = i - config.right;
    if (p - config.left >= start) {
      const b = bars[p],
        window = bars
          .slice(p - config.left, i + 1)
          .filter((_, j) => j !== config.left);
      if (window.every((x) => x.high < b.high)) {
        high = { price: b.high, time: b.time, broken: false, swept: false };
        events.push({
          id: `SH:${b.time}`,
          type: "SH",
          direction: -1,
          time: c.time,
          origin: b.time,
          price: b.high,
          description: `Máximo confirmado ${config.right} barras después; sin empates.`,
        });
      }
      if (window.every((x) => x.low > b.low)) {
        low = { price: b.low, time: b.time, broken: false, swept: false };
        events.push({
          id: `SL:${b.time}`,
          type: "SL",
          direction: 1,
          time: c.time,
          origin: b.time,
          price: b.low,
          description: `Mínimo confirmado ${config.right} barras después; sin empates.`,
        });
      }
    }
  }
  if (config.session) {
    const sessions = new Map<number, Zone>();
    for (const c of bars) {
      const day = Math.floor(c.time / 86400) * 86400;
      let t = day + config.sessionStart * 3600;
      if (t > c.time) t -= 86400;
      const end =
        t + ((config.sessionEnd - config.sessionStart + 24) % 24) * 3600;
      if (c.time < t || c.closeTime >= end * 1000) continue;
      const z = sessions.get(t);
      if (z) {
        z.low = Math.min(z.low, c.low);
        z.high = Math.max(z.high, c.high);
        z.end = c.time;
      } else
        sessions.set(t, {
          id: `session:${t}`,
          type: "Sesión",
          direction: 1,
          time: c.time,
          origin: t,
          end: c.time,
          low: c.low,
          high: c.high,
          status: "rango parcial",
        });
    }
    zones.push(...[...sessions.values()].slice(-10));
  }
  return {
    events: events.slice(-300),
    zones: zones.slice(-100),
    support: low && !low.broken ? low.price : undefined,
    resistance: high && !high.broken ? high.price : undefined,
    bias,
    bars: bars.length,
    truncated: source.length > 2000,
    gaps,
  };
}
