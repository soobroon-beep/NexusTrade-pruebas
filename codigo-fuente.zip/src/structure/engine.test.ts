import { it, expect } from "vitest";
import { analyzeStructure, defaultStructure } from "./engine";
import type { Candle } from "../domain/types";
const make = (rows: number[][]): Candle[] =>
  rows.map(([open, high, low, close], i) => ({
    time: i * 60,
    open,
    high,
    low,
    close,
    volume: 1,
    closed: true,
    closeTime: (i + 1) * 60000 - 1,
    source: "Binance Spot",
    receivedAt: 0,
  }));
const bars = make([
  [1, 2, 0, 1],
  [3, 5, 2, 4],
  [2, 3, 1, 2],
  [4, 6, 3, 5.5],
  [3, 4, 2, 3],
  [1, 2, 0, 0.5],
  [1, 3, 1, 2],
  [0, 1, -1, -0.5],
]);
const config = {
  ...defaultStructure,
  enabled: true,
  left: 1,
  right: 1,
  blocks: true,
};
it("confirma swing después de barras derechas y no en su fecha de origen", () => {
  expect(analyzeStructure(bars.slice(0, 2), "1m", config).events).toHaveLength(
    0,
  );
  expect(
    analyzeStructure(bars.slice(0, 3), "1m", config).events[0],
  ).toMatchObject({ type: "SH", origin: 60, time: 120, price: 5 });
});
it("clasifica ruptura inicial, CHoCH y continuación BOS reproduciblemente", () => {
  const r = analyzeStructure(bars, "1m", config);
  expect(
    r.events
      .filter((e) => ["Ruptura", "CHoCH", "BOS"].includes(e.type))
      .map((e) => [e.type, e.direction]),
  ).toEqual([
    ["Ruptura", 1],
    ["CHoCH", -1],
    ["BOS", -1],
  ]);
  expect(r.zones.some((z) => z.type === "OB")).toBe(true);
});
it("no incluye la vela abierta ni cambia eventos previos con barras futuras", () => {
  const initial = analyzeStructure(bars.slice(0, 5), "1m", config).events;
  expect(
    analyzeStructure(bars, "1m", config).events.filter((e) => e.time <= 240),
  ).toEqual(initial);
  expect(
    analyzeStructure(
      [...bars.slice(0, 2), { ...bars[2], closed: false }],
      "1m",
      config,
    ).events,
  ).toHaveLength(0);
});
it("descarta empates y reinicia estructura tras huecos", () => {
  const equal = make([
    [1, 3, 0, 2],
    [1, 3, 0, 2],
    [1, 3, 0, 2],
  ]);
  expect(analyzeStructure(equal, "1m", config).events).toHaveLength(0);
  const g = bars.map((b, i) => (i >= 3 ? { ...b, time: b.time + 600 } : b));
  const r = analyzeStructure(g, "1m", config);
  expect(r.gaps).toBe(1);
  expect(r.events.some((e) => e.type === "Ruptura" && e.time === 780)).toBe(
    false,
  );
});
it("FVG se conoce en tercera vela y conserva transición tocada/cubierta", () => {
  const c = make([
    [1, 2, 0, 1],
    [3, 4, 2, 3],
    [4, 5, 3, 4],
    [4, 5, 2.5, 4],
    [2, 4, 1.5, 3],
  ]);
  expect(
    analyzeStructure(c.slice(0, 2), "1m", config).zones.filter(
      (z) => z.type === "FVG",
    ),
  ).toHaveLength(0);
  const a = analyzeStructure(c.slice(0, 3), "1m", config).zones.find(
    (z) => z.type === "FVG",
  )!;
  expect(a).toMatchObject({
    time: 120,
    origin: 0,
    low: 2,
    high: 3,
    status: "abierta",
  });
  expect(
    analyzeStructure(c.slice(0, 4), "1m", config).zones.find(
      (z) => z.id === a.id,
    )?.status,
  ).toBe("tocada");
  expect(
    analyzeStructure(c, "1m", config).zones.find((z) => z.id === a.id)?.status,
  ).toBe("cubierta");
});
it("barrido usa mecha y no cuenta como ruptura de cierre", () => {
  const c = make([
    [1, 2, 0, 1],
    [3, 5, 2, 4],
    [2, 3, 1, 2],
    [4, 6, 3, 4],
  ]);
  const r = analyzeStructure(c, "1m", config);
  expect(r.events.some((e) => e.type === "Barrido")).toBe(true);
  expect(r.events.some((e) => e.type === "Ruptura")).toBe(false);
});
it("sesión que cruza medianoche incluye sólo barras enteras de la ventana", () => {
  const c = bars
    .slice(0, 4)
    .map((b, i) => ({
      ...b,
      time: 21 * 3600 + i * 3600,
      closeTime: (22 * 3600 + i * 3600) * 1000 - 1,
    }));
  const r = analyzeStructure(c, "1h", {
    ...config,
    session: true,
    sessionStart: 22,
    sessionEnd: 1,
  });
  const session = r.zones.find((z) => z.type === "Sesión")!;
  expect(session.time).toBe(22 * 3600);
  expect(session.end).toBe(24 * 3600);
  expect(session.status).toBe("rango parcial");
});
