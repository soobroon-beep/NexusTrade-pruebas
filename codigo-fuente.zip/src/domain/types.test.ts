import { describe, it, expect } from "vitest";
import { mergeCandles, findGaps, nextOpen } from "./types";
import { parseCandle } from "../market/binance";
const c = (t: number, closed = true) => ({
  ...parseCandle([t * 1000, 10, 12, 9, 11, 2, t * 1000 + 59999], 200000),
  closed,
});
describe("series OHLCV", () => {
  it("normaliza milisegundos y cierre", () => {
    const value = parseCandle(
      [60000, "10", "12", "9", "11", "2", 119999],
      100000,
    );
    expect(value.time).toBe(60);
    expect(value.closed).toBe(false);
    expect(value.source).toBe("Binance Spot");
  });
  it("rechaza incoherencia y números no finitos", () => {
    expect(() => parseCandle([0, 10, 9, 8, 11, 2, 59999])).toThrow();
    expect(() => parseCandle([0, 10, 12, 9, "NaN", 2, 59999])).toThrow();
  });
  it("ordena, deduplica y no reabre una vela cerrada", () => {
    const old = c(60);
    const next = { ...c(60, false), receivedAt: 300000, close: 10 };
    expect(mergeCandles([old, c(0)], [next]).map((c) => c.time)).toEqual([
      0, 60,
    ]);
    expect(mergeCandles([old], [next])[0].closed).toBe(true);
  });
  it("ignora actualizaciones obsoletas", () => {
    expect(
      mergeCandles(
        [{ ...c(0, false), receivedAt: 20, close: 12 }],
        [{ ...c(0, false), receivedAt: 10 }],
      )[0].close,
    ).toBe(12);
  });
  it("detecta huecos exactos", () => {
    expect(findGaps([c(0), c(60), c(180)], "1m")).toEqual([120]);
    expect(findGaps([c(0), c(60)], "1m")).toEqual([]);
  });
  it("respeta meses y años UTC", () => {
    expect(nextOpen(Date.UTC(2024, 1, 1) / 1000, "1M")).toBe(
      Date.UTC(2024, 2, 1) / 1000,
    );
    expect(nextOpen(Date.UTC(2024, 11, 1) / 1000, "1M")).toBe(
      Date.UTC(2025, 0, 1) / 1000,
    );
  });
});
