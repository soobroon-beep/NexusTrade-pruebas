import type { Candle } from "./types";
export function timeIndex(time: number, bars: Candle[]): number {
  let lo = 0,
    hi = bars.length - 1;
  if (hi < 0) return 0;
  while (lo <= hi) {
    const mid = (lo + hi) >> 1;
    if (bars[mid].time === time) return mid;
    if (bars[mid].time < time) lo = mid + 1;
    else hi = mid - 1;
  }
  const a = Math.max(0, Math.min(bars.length - 2, hi));
  const delta = (bars[a + 1]?.time ?? bars[a].time + 60) - bars[a].time;
  return a + (time - bars[a].time) / delta;
}
