export const intervals = [
  "1m",
  "3m",
  "5m",
  "15m",
  "30m",
  "1h",
  "2h",
  "4h",
  "6h",
  "8h",
  "12h",
  "1d",
  "3d",
  "1w",
  "1M",
] as const;
export type Interval = (typeof intervals)[number];
export type Candle = {
  time: number;
  open: number;
  high: number;
  low: number;
  close: number;
  volume: number;
  closeTime: number;
  closed: boolean;
  source: "Binance Spot";
  receivedAt: number;
};
export type MarketSymbol = {
  symbol: string;
  baseAsset: string;
  quoteAsset: string;
};
export type Ticker = {
  symbol: string;
  lastPrice: number;
  priceChangePercent: number;
  volume: number;
  quoteVolume: number;
  highPrice: number;
  lowPrice: number;
  closeTime: number;
};
export type Connection = "connecting" | "live" | "reconnecting" | "offline";
export interface MarketAdapter {
  getSymbols(signal?: AbortSignal): Promise<MarketSymbol[]>;
  getCandles(
    symbol: string,
    interval: Interval,
    endTime?: number,
    signal?: AbortSignal,
  ): Promise<Candle[]>;
  getTickers(symbols: string[], signal?: AbortSignal): Promise<Ticker[]>;
  subscribeCandles(
    symbol: string,
    interval: Interval,
    onCandle: (c: Candle) => void,
    onStatus: (s: Connection) => void,
    onRecover: () => void,
  ): () => void;
}
export function mergeCandles(previous: Candle[], incoming: Candle[]): Candle[] {
  const map = new Map(previous.map((c) => [c.time, c]));
  for (const c of incoming) {
    const old = map.get(c.time);
    if (!old || ((!old.closed || c.closed) && c.receivedAt >= old.receivedAt))
      map.set(c.time, c);
  }
  return [...map.values()].sort((a, b) => a.time - b.time);
}
export function nextOpen(time: number, interval: Interval): number {
  if (interval === "1M") {
    const d = new Date(time * 1000);
    return Date.UTC(d.getUTCFullYear(), d.getUTCMonth() + 1, 1) / 1000;
  }
  const unit = interval.slice(-1),
    n = parseInt(interval);
  return time + n * ({ m: 60, h: 3600, d: 86400, w: 604800 }[unit] ?? 60);
}
export function findGaps(candles: Candle[], interval: Interval): number[] {
  return candles
    .slice(1)
    .flatMap((c, i) =>
      c.time > nextOpen(candles[i].time, interval)
        ? [nextOpen(candles[i].time, interval)]
        : [],
    );
}
