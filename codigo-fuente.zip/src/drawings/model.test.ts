import { it, expect } from "vitest";
import {
  drawingSchema,
  fibLevels,
  moveDrawing,
  pointCount,
  positionMetrics,
  pushHistory,
  type Drawing,
} from "./model";
import { timeIndex } from "../components/DrawingLayer";
import type { Candle } from "../domain/types";
const d: Drawing = {
  id: "test",
  tool: "long",
  points: [
    { time: 60, price: 100 },
    { time: 120, price: 90 },
    { time: 180, price: 120 },
  ],
  color: "#abcdef",
  width: 2,
  dash: false,
  extend: false,
  text: "",
  visible: true,
  locked: false,
};
it("valida anclas y desplaza en tiempo/precio sin mutar", () => {
  expect(drawingSchema.safeParse(d).success).toBe(true);
  expect(
    drawingSchema.safeParse({ ...d, points: d.points.slice(0, 2) }).success,
  ).toBe(false);
  expect(pointCount("channel")).toBe(3);
  expect(moveDrawing(d, 60, 10).points[0]).toEqual({ time: 120, price: 110 });
  expect(d.points[0].price).toBe(100);
});
it("calcula Fibonacci y ratio de riesgo reproducibles", () => {
  expect(fibLevels(100, 200).find((x) => x.ratio === 0.618)?.price).toBeCloseTo(
    161.8,
  );
  expect(positionMetrics(d).ratio).toBe(2);
  expect(positionMetrics({ ...d, tool: "short" }).ratio).toBeNull();
});
it("conserva anclas al anteponer historial y permite interpolación", () => {
  const c = [{ time: 60 }, { time: 120 }, { time: 180 }] as Candle[];
  expect(timeIndex(120, c)).toBe(1);
  expect(timeIndex(120, [{ time: 0 } as Candle, ...c])).toBe(2);
  expect(timeIndex(90, c)).toBe(0.5);
});
it("historial acotado e invalida redo tras un nuevo cambio", () => {
  const history = pushHistory(
    { past: Array.from({ length: 50 }, () => [d]), future: [[d]] },
    [d],
  );
  expect(history.past).toHaveLength(50);
  expect(history.future).toHaveLength(0);
});
