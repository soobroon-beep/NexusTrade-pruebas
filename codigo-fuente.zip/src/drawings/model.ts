import { z } from "zod";
export const toolNames = {
  trend: "Tendencia",
  ray: "Rayo",
  horizontal: "Horizontal",
  vertical: "Vertical",
  rectangle: "Rectángulo",
  channel: "Canal paralelo",
  arrow: "Flecha",
  text: "Texto",
  measure: "Medición",
  fib: "Fibonacci",
  extension: "Extensión Fibonacci",
  extrema: "Máximo / mínimo",
  long: "Posición long",
  short: "Posición short",
} as const;
export type DrawingTool = keyof typeof toolNames;
export const pointSchema = z.object({
  time: z.number().finite().min(0).max(253402300799),
  price: z.number().finite(),
});
export const drawingSchema = z
  .object({
    id: z.string().min(1),
    tool: z.enum([
      "trend",
      "ray",
      "horizontal",
      "vertical",
      "rectangle",
      "channel",
      "arrow",
      "text",
      "measure",
      "fib",
      "extension",
      "extrema",
      "long",
      "short",
    ]),
    points: z.array(pointSchema).min(1).max(3),
    color: z.string().regex(/^#[0-9a-fA-F]{6}$/),
    width: z.number().int().min(1).max(4),
    dash: z.boolean(),
    extend: z.boolean(),
    text: z.string().max(100),
    visible: z.boolean(),
    locked: z.boolean(),
  })
  .refine(
    (d) => d.points.length === pointCount(d.tool),
    "Cantidad de anclas incorrecta",
  );
export type Point = z.infer<typeof pointSchema>;
export type Drawing = z.infer<typeof drawingSchema>;
export function pointCount(tool: DrawingTool) {
  return ["horizontal", "vertical", "text"].includes(tool)
    ? 1
    : ["channel", "extension", "long", "short"].includes(tool)
      ? 3
      : 2;
}
export function moveDrawing(d: Drawing, dt: number, dp: number): Drawing {
  return {
    ...d,
    points: d.points.map((p) => ({
      time: Math.max(0, p.time + dt),
      price: p.price + dp,
    })),
  };
}
export function fibLevels(a: number, b: number, extension = false) {
  return (
    extension
      ? [0, 0.618, 1, 1.618, 2.618]
      : [0, 0.236, 0.382, 0.5, 0.618, 0.786, 1]
  ).map((r) => ({ ratio: r, price: a + (b - a) * r }));
}
export function positionMetrics(d: Drawing) {
  const [entry, stop, target] = d.points;
  const sign = d.tool === "long" ? 1 : -1;
  const risk = (entry.price - stop.price) * sign,
    reward = (target.price - entry.price) * sign;
  return { risk, reward, ratio: risk > 0 && reward > 0 ? reward / risk : null };
}
export type History = { past: Drawing[][]; future: Drawing[][] };
export function pushHistory(history: History, current: Drawing[]): History {
  return { past: [...history.past, current].slice(-50), future: [] };
}
