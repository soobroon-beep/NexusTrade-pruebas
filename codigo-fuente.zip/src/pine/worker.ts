import { compile } from "./compiler";
import { execute } from "./runtime";
import { PineError } from "./language";
import type { Request, Response } from "./protocol";
// Only the AST interpreter sees imported text. No dynamic code evaluation or host capability table.
self.onmessage = (event: MessageEvent<Request>) => {
  const { id, source, candles, parameters } = event.data;
  let response: Response;
  try {
    const c = compile(source);
    response = {
      id,
      ok: true,
      report: {
        title: c.title,
        overlay: c.overlay,
        version: c.program.version,
        inputs: c.inputs,
        plots: c.plots,
        warnings: c.warnings,
      },
      result: candles ? execute(c, candles, parameters) : undefined,
    };
  } catch (error) {
    response = {
      id,
      ok: false,
      error: {
        message:
          error instanceof Error ? error.message : "Error del intérprete",
        line: error instanceof PineError ? error.line : 1,
        column: error instanceof PineError ? error.column : 1,
      },
    };
  }
  self.postMessage(response);
};
