import type { Candle } from "../domain/types";
import {
  compile,
  argsOf,
  constants,
  type Compiled,
  type PlotDefinition,
} from "./compiler";
import { LIMITS, PineError, type Expr, type Value } from "./language";
export type PlotOutput = PlotDefinition & {
  points: {
    time: number;
    value: number | null;
    color: string;
    closed: boolean;
  }[];
};
export type Result = {
  title: string;
  overlay: boolean;
  plots: PlotOutput[];
  bars: number;
  operations: number;
  lastClosed: boolean;
  warnings: string[];
};
type RuntimeValue = Value | Value[];
export function execute(
  compiled: Compiled,
  candles: Candle[],
  parameters: Record<string, Value> = {},
  operationLimit = LIMITS.operations,
): Result {
  const { program } = compiled;
  if (
    candles.length > LIMITS.bars ||
    (program.nodes + program.statements.length) * candles.length > LIMITS.cells
  )
    throw new PineError(
      "Límite de barras/memoria excedido (10.000 barras, 2 millones de celdas). Reduce el histórico o el script.",
    );
  let operations = 0,
    bar = 0;
  const tick = (n = 1) => {
    operations += n;
    if (operations > operationLimit)
      throw new PineError("Límite de operaciones excedido.");
  };
  const values = new Map<string, RuntimeValue>(),
    history = new Map<string, RuntimeValue[]>(),
    cache = new Map<number, RuntimeValue[]>(),
    state = new Map<
      string,
      { v?: number; samples: number[]; period: number }
    >();
  const inputs = new Map(
    compiled.inputs.map((input) => {
      const v = Object.hasOwn(parameters, input.id)
        ? parameters[input.id]
        : input.value;
      if (
        typeof v !== typeof input.value ||
        (typeof v === "number" &&
          (!Number.isFinite(v) ||
            (input.kind === "int" && !Number.isInteger(v)) ||
            (input.min !== undefined && v < input.min) ||
            (input.max !== undefined && v > input.max))) ||
        (typeof v === "string" && v.length > 200)
      )
        throw new PineError(`Parámetro inválido: ${input.title}`);
      return [Number(input.id), v];
    }),
  );
  for (const key of Object.keys(parameters))
    if (!compiled.inputs.some((i) => i.id === key))
      throw new PineError("Parámetro desconocido. Vuelve a validar el script.");
  const plots = compiled.plots.map((p) => ({ ...p, points: [] }) as PlotOutput);
  const fail = (e: Expr, msg: string): never => {
    throw new PineError(msg, e.token.line, e.token.column);
  };
  const num = (x: RuntimeValue, e: Expr): number | null => {
    if (x === null) return null;
    if (typeof x !== "number" || !Number.isFinite(x))
      return fail(e, "Se esperaba un número finito.");
    return x;
  };
  const period = (x: RuntimeValue, e: Expr) => {
    const p = num(x, e);
    if (p === null || !Number.isInteger(p) || p < 1 || p > 500)
      fail(e, "Los periodos deben ser enteros entre 1 y 500.");
    return p as number;
  };
  const smooth = (
    key: string,
    x: number | null,
    n: number,
    mode: "sma" | "ema" | "rma",
  ) => {
    let s = state.get(key);
    if (!s) {
      s = { samples: [], period: n };
      state.set(key, s);
    }
    if (s.period !== n)
      throw new PineError("Los periodos dinámicos no están soportados.");
    if (x === null) return s.v ?? null;
    if (mode === "ema")
      s.v = s.v === undefined ? x : s.v + (2 / (n + 1)) * (x - s.v);
    else if (mode === "rma" && s.v !== undefined) s.v += (x - s.v) / n;
    else {
      s.samples.push(x);
      if (s.samples.length > n) s.samples.shift();
      if (s.samples.length === n) {
        tick(n);
        s.v = s.samples.reduce((a, b) => a + b, 0) / n;
      }
    }
    return s.v ?? null;
  };
  const previous = (e: Expr) => cache.get(e.id)?.[bar - 1] ?? null;
  const evaluate = (e: Expr): RuntimeValue => {
    tick();
    const cached = cache.get(e.id);
    if (cached && Object.hasOwn(cached, bar)) return cached[bar];
    let v: RuntimeValue = null;
    if (e.kind === "literal") v = e.value;
    else if (e.kind === "name")
      v = Object.hasOwn(constants, e.name)
        ? constants[e.name]
        : (values.get(e.name) ?? null);
    else if (e.kind === "history")
      v =
        e.offset === 0
          ? (values.get(e.name) ?? null)
          : (history.get(e.name)?.[bar - e.offset] ??
            (program.version === 6 && compiled.booleanNames.includes(e.name)
              ? false
              : null));
    else if (e.kind === "unary") {
      const x = evaluate(e.right);
      v =
        e.op === "not"
          ? x === null && program.version === 5
            ? null
            : !x
          : x === null
            ? null
            : (e.op === "-" ? -1 : 1) * num(x, e)!;
    } else if (e.kind === "conditional")
      v = evaluate(e.condition) === true ? evaluate(e.yes) : evaluate(e.no);
    else if (e.kind === "binary") {
      const a = evaluate(e.left);
      if (e.op === "and" || e.op === "or") {
        if (
          program.version === 6 &&
          ((e.op === "and" && a !== true) || (e.op === "or" && a === true))
        )
          v = e.op === "or";
        else {
          const b = evaluate(e.right);
          v =
            e.op === "and"
              ? a === false || b === false
                ? false
                : a === null || b === null
                  ? program.version === 6
                    ? false
                    : null
                  : true
              : a === true || b === true
                ? true
                : a === null || b === null
                  ? program.version === 6
                    ? false
                    : null
                  : false;
        }
      } else if (a === null) {
        v =
          ["==", "!=", "<", ">", "<=", ">="].includes(e.op) &&
          program.version === 6
            ? false
            : null;
        evaluate(e.right);
      } else {
        const b = evaluate(e.right);
        if (b === null)
          v =
            ["==", "!=", "<", ">", "<=", ">="].includes(e.op) &&
            program.version === 6
              ? false
              : null;
        else if (e.op === "==") v = a === b;
        else if (e.op === "!=") v = a !== b;
        else {
          const x = num(a, e)!,
            y = num(b, e)!;
          switch (e.op) {
            case "+":
              v = x + y;
              break;
            case "-":
              v = x - y;
              break;
            case "*":
              v = x * y;
              break;
            case "/":
              v = y === 0 ? null : x / y;
              break;
            case "%":
              v = y === 0 ? null : x % y;
              break;
            case "<":
              v = x < y;
              break;
            case ">":
              v = x > y;
              break;
            case "<=":
              v = x <= y;
              break;
            case ">=":
              v = x >= y;
          }
        }
      }
    } else {
      const args = argsOf(e),
        a: Record<string, RuntimeValue> = Object.create(null);
      for (const [k, x] of Object.entries(args)) a[k] = evaluate(x);
      if (e.name.startsWith("input.")) v = inputs.get(e.id)!;
      else if (e.name === "na") v = a.x === null;
      else if (e.name === "nz")
        v = a.source === null ? (a.replacement ?? 0) : a.source;
      else if (["plot", "hline", "plotshape", "plotchar"].includes(e.name)) {
        const output = plots.find((p) => p.id === e.id)!;
        const color = a.color === undefined ? "#57d6b2" : a.color;
        if (
          color !== null &&
          (typeof color !== "string" ||
            !/^#[0-9a-fA-F]{6}([0-9a-fA-F]{2})?$/.test(color))
        )
          fail(
            e,
            "El color debe ser una constante color.* o hexadecimal #RRGGBB/#RRGGBBAA.",
          );
        let value: number | null;
        if (e.name === "plotshape" || e.name === "plotchar")
          value =
            a.series === true
              ? output.location === "aboveBar"
                ? candles[bar].high
                : candles[bar].low
              : null;
        else value = num(a[e.name === "hline" ? "price" : "series"], e);
        output.points.push({
          time: candles[bar].time,
          value,
          color: (color ?? "#00000000") as string,
          closed: candles[bar].closed,
        });
      } else if (e.name.startsWith("ta.")) {
        const key = String(e.id),
          c = candles[bar];
        if (e.name === "ta.crossover" || e.name === "ta.crossunder") {
          const x = num(a.source1, e),
            y = num(a.source2, e),
            p = num(previous(args.source1), e),
            q = num(previous(args.source2), e);
          v =
            x !== null &&
            y !== null &&
            p !== null &&
            q !== null &&
            (e.name === "ta.crossover" ? x > y && p <= q : x < y && p >= q);
        } else if (e.name === "ta.atr") {
          const prev = candles[bar - 1]?.close,
            tr =
              prev === undefined
                ? c.high - c.low
                : Math.max(
                    c.high - c.low,
                    Math.abs(c.high - prev),
                    Math.abs(c.low - prev),
                  );
          v = smooth(key, tr, period(a.length, e), "rma");
        } else if (e.name === "ta.macd") {
          const x = num(a.source, e),
            fast = period(a.fastlen, e),
            slow = period(a.slowlen, e);
          if (fast >= slow) fail(e, "MACD requiere fastlen < slowlen.");
          const f = smooth(key + "f", x, fast, "ema"),
            s = smooth(key + "s", x, slow, "ema"),
            m = f === null || s === null ? null : f - s,
            signal = smooth(key + "sig", m, period(a.siglen, e), "ema");
          v = [m, signal, m === null || signal === null ? null : m - signal];
        } else if (e.name === "ta.rsi") {
          const x = num(a.source, e),
            prev = state.get(key + "last")?.v ?? null,
            n = period(a.length, e),
            diff = x === null || prev === null ? null : x - prev;
          if (x !== null)
            state.set(key + "last", { v: x, samples: [], period: n });
          const up = smooth(
              key + "u",
              diff === null ? null : Math.max(diff, 0),
              n,
              "rma",
            ),
            down = smooth(
              key + "d",
              diff === null ? null : Math.max(-diff, 0),
              n,
              "rma",
            );
          v =
            up === null || down === null
              ? null
              : down === 0
                ? up === 0
                  ? 50
                  : 100
                : 100 - 100 / (1 + up / down);
        } else
          v = smooth(
            key,
            num(a.source, e),
            period(a.length, e),
            e.name === "ta.sma" ? "sma" : "ema",
          );
      }
    }
    if (typeof v === "number" && !Number.isFinite(v))
      fail(e, "Resultado numérico fuera de rango.");
    if (!cache.has(e.id)) cache.set(e.id, []);
    cache.get(e.id)![bar] = v;
    return v;
  };
  for (bar = 0; bar < candles.length; bar++) {
    const c = candles[bar];
    if (
      !Number.isFinite(c.time) ||
      [c.open, c.high, c.low, c.close, c.volume].some(
        (x) => !Number.isFinite(x),
      ) ||
      (bar > 0 && c.time <= candles[bar - 1].time)
    )
      throw new PineError("Velas inválidas o desordenadas.");
    for (const k of ["open", "high", "low", "close", "volume"] as const)
      values.set(k, c[k]);
    values.set("time", c.time * 1000);
    values.set("bar_index", bar);
    values.set("barstate.isconfirmed", c.closed);
    values.set("hl2", (c.high + c.low) / 2);
    values.set("hlc3", (c.high + c.low + c.close) / 3);
    values.set("ohlc4", (c.open + c.high + c.low + c.close) / 4);
    for (const s of program.statements) {
      tick();
      if (s.persistent && bar > 0) continue;
      const v = evaluate(s.expr);
      if (s.names)
        s.names.forEach((n, i) => values.set(n, Array.isArray(v) ? v[i] : v));
    }
    for (const [name, value] of values) {
      if (!history.has(name)) history.set(name, []);
      history.get(name)![bar] = value;
    }
  }
  return {
    title: compiled.title,
    overlay: compiled.overlay,
    plots,
    bars: candles.length,
    operations,
    lastClosed: candles.at(-1)?.closed ?? true,
    warnings: compiled.warnings,
  };
}
export function run(
  source: string,
  candles: Candle[],
  parameters: Record<string, Value> = {},
) {
  const compiled = compile(source);
  return { compiled, result: execute(compiled, candles, parameters) };
}
