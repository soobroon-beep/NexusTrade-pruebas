export const examples = [
  {
    name: "Media y cruce",
    source: `//@version=6
indicator("Media y cruce", overlay=true)
n = input.int(20, "Periodo", minval=1, maxval=500)
media = ta.sma(close, n)
cruce = ta.crossover(close, media)
plot(media, "SMA", color=color.aqua, linewidth=2)
plotshape(cruce and barstate.isconfirmed, "Cruce cerrado", style=shape.triangleup, location=location.belowbar, color=color.lime, text="Cruce")`,
  },
  {
    name: "RSI",
    source: `//@version=5
indicator("RSI propio", overlay=false)
n = input.int(14, "Periodo", minval=1, maxval=500)
r = ta.rsi(close, n)
plot(r, "RSI", color=color.purple)
hline(70, "Sobrecompra", color=color.red)
hline(30, "Sobreventa", color=color.green)`,
  },
  {
    name: "MACD",
    source: `//@version=6
indicator("MACD propio", overlay=false)
[m, s, h] = ta.macd(close, 12, 26, 9)
plot(m, "MACD", color=color.aqua)
plot(s, "Señal", color=color.orange)
plot(h, "Histograma", color=h >= 0 ? color.green : color.red, style=plot.style_histogram)`,
  },
  {
    name: "Histórico y persistencia",
    source: `//@version=6
indicator("Cambio acumulado", overlay=false)
var total = 0.0
total := total + nz(close - close[1])
plot(total, "Cambio desde primera barra", color=color.yellow)`,
  },
  {
    name: "No soportado: MTF",
    source: `//@version=6
indicator("MTF no disponible", overlay=true)
x = request.security("BINANCE:BTCUSDT", "240", close)
plot(x)`,
  },
  {
    name: "Error de sintaxis",
    source: `//@version=6
indicator("Error intencional")
plot(ta.sma(close, 20)`,
  },
];
