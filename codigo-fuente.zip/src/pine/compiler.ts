import {
  parse,
  PineError,
  type Expr,
  type Program,
  type Value,
} from "./language";
export const constants: Record<string, Value> = {
  "color.aqua": "#00bcd4",
  "color.blue": "#2196f3",
  "color.green": "#4caf50",
  "color.lime": "#00e676",
  "color.red": "#f23645",
  "color.orange": "#ff9800",
  "color.yellow": "#ffeb3b",
  "color.purple": "#9c27b0",
  "color.white": "#ffffff",
  "color.gray": "#787b86",
  "color.black": "#000000",
  "color.teal": "#00897b",
  "plot.style_line": "line",
  "plot.style_linebr": "linebr",
  "plot.style_histogram": "histogram",
  "shape.triangleup": "arrowUp",
  "shape.triangledown": "arrowDown",
  "shape.circle": "circle",
  "shape.square": "square",
  "location.abovebar": "aboveBar",
  "location.belowbar": "belowBar",
};
const signatures: Record<string, string[]> = {
  indicator: ["title", "shorttitle", "overlay"],
  strategy: ["title", "shorttitle", "overlay"],
  plot: ["series", "title", "color", "linewidth", "style"],
  hline: ["price", "title", "color", "linestyle", "linewidth"],
  plotshape: ["series", "title", "style", "location", "color", "text"],
  plotchar: ["series", "title", "char", "location", "color"],
  "input.int": ["defval", "title", "minval", "maxval", "step"],
  "input.float": ["defval", "title", "minval", "maxval", "step"],
  "input.bool": ["defval", "title"],
  "input.string": ["defval", "title"],
  "ta.sma": ["source", "length"],
  "ta.ema": ["source", "length"],
  "ta.rsi": ["source", "length"],
  "ta.atr": ["length"],
  "ta.macd": ["source", "fastlen", "slowlen", "siglen"],
  "ta.crossover": ["source1", "source2"],
  "ta.crossunder": ["source1", "source2"],
  na: ["x"],
  nz: ["source", "replacement"],
};
export const completions = Object.keys(signatures);
export type Input = {
  id: string;
  title: string;
  kind: "int" | "float" | "bool" | "string";
  value: Exclude<Value, null>;
  min?: number;
  max?: number;
  step?: number;
};
export type PlotDefinition = {
  id: number;
  kind: "plot" | "hline" | "plotshape" | "plotchar";
  title: string;
  style: string;
  width: number;
  location: "aboveBar" | "belowBar";
  text: string;
};
export type Compiled = {
  program: Program;
  booleanNames: string[];
  title: string;
  overlay: boolean;
  inputs: Input[];
  plots: PlotDefinition[];
  warnings: string[];
};
export function argsOf(e: Expr): Record<string, Expr> {
  if (e.kind !== "call") return {};
  const keys = signatures[e.name];
  if (!keys)
    throw new PineError(
      `Función no soportada: ${e.name}. Consulta la matriz de compatibilidad.`,
      e.token.line,
      e.token.column,
    );
  const result: Record<string, Expr> = Object.create(null);
  e.args.forEach((a, i) => {
    const key = a.name ?? keys[i];
    if (!key || !keys.includes(key) || Object.hasOwn(result, key))
      throw new PineError(
        `Argumento no soportado o duplicado en ${e.name}: ${key ?? i + 1}`,
        e.token.line,
        e.token.column,
      );
    result[key] = a.value;
  });
  return result;
}
export function staticValue(e?: Expr): Value | undefined {
  if (!e) return undefined;
  if (e.kind === "literal") return e.value;
  if (e.kind === "name" && Object.hasOwn(constants, e.name))
    return constants[e.name];
  if (e.kind === "unary" && ["+", "-"].includes(e.op)) {
    const x = staticValue(e.right);
    if (typeof x === "number") return e.op === "-" ? -x : x;
  }
  throw new PineError(
    "Este parámetro requiere un literal constante.",
    e.token.line,
    e.token.column,
  );
}
type Type = "number" | "boolean" | "string" | "na" | "tuple" | "void";
export function compile(source: string): Compiled {
  const program = parse(source);
  const inputs: Input[] = [],
    plots: PlotDefinition[] = [];
  let title = "",
    overlay = false,
    declarations = 0;
  const variables = new Map<string, Type>(
    [
      "open",
      "high",
      "low",
      "close",
      "volume",
      "time",
      "bar_index",
      "hl2",
      "hlc3",
      "ohlc4",
    ].map((n) => [n, "number"]),
  );
  variables.set("barstate.isconfirmed", "boolean");
  const err = (e: Expr, msg: string): never => {
    throw new PineError(msg, e.token.line, e.token.column);
  };
  const need = (type: Type, allowed: Type[], e: Expr) => {
    if (!allowed.includes(type))
      err(
        e,
        `Tipo ${type} no permitido aquí; se requiere ${allowed.join(" / ")}.`,
      );
  };
  const walk = (e: Expr, conditional = false, top = false): Type => {
    if (e.kind === "literal")
      return e.value === null ? "na" : (typeof e.value as Type);
    if (e.kind === "name") {
      if (Object.hasOwn(constants, e.name))
        return typeof constants[e.name] as Type;
      const t = variables.get(e.name);
      if (!t) err(e, `Variable o constante no soportada: ${e.name}`);
      return t!;
    }
    if (e.kind === "history") {
      const t = variables.get(e.name);
      if (!t) err(e, `Variable desconocida: ${e.name}`);
      return t!;
    }
    if (e.kind === "unary") {
      const t = walk(e.right, conditional);
      need(t, e.op === "not" ? ["boolean", "na"] : ["number", "na"], e);
      return e.op === "not" ? "boolean" : "number";
    }
    if (e.kind === "binary") {
      const logical = ["and", "or"].includes(e.op);
      const a = walk(e.left, conditional),
        b = walk(e.right, conditional || logical);
      if (logical) {
        need(a, ["boolean", "na"], e);
        need(b, ["boolean", "na"], e);
        return "boolean";
      }
      if (["==", "!="].includes(e.op)) {
        need(a, ["number", "boolean", "string", "na"], e);
        need(b, ["number", "boolean", "string", "na"], e);
        if (a !== b && a !== "na" && b !== "na")
          err(e, "Comparación de tipos diferentes.");
        return "boolean";
      }
      need(a, ["number", "na"], e);
      need(b, ["number", "na"], e);
      return ["<", ">", "<=", ">="].includes(e.op) ? "boolean" : "number";
    }
    if (e.kind === "conditional") {
      need(walk(e.condition, conditional), ["boolean", "na"], e);
      const a = walk(e.yes, true),
        b = walk(e.no, true);
      if (a !== b && a !== "na" && b !== "na")
        err(e, "Las ramas deben tener el mismo tipo.");
      return a === "na" ? b : a;
    }
    const a = argsOf(e);
    for (const key of [
      "title",
      "shorttitle",
      "overlay",
      "linewidth",
      "style",
      "location",
      "text",
      "char",
    ]) {
      if (a[key] && staticValue(a[key]) === null)
        err(e, `El parámetro ${key} no admite na.`);
    }
    const types: Record<string, Type> = Object.create(null);
    if (
      conditional &&
      (e.name.startsWith("ta.") || e.name.startsWith("input."))
    )
      err(
        e,
        "Calcula ta.* e input.* fuera de condiciones y variables var para garantizar su historial.",
      );
    for (const [key, value] of Object.entries(a))
      types[key] = walk(value, conditional);
    const required = (keys: string[]) =>
      keys.forEach((k) => {
        if (!a[k]) err(e, `Falta ${k} en ${e.name}.`);
      });
    if (e.name === "indicator" || e.name === "strategy") {
      if (!top || program.statements[0]?.expr !== e || ++declarations > 1)
        err(
          e,
          "La primera instrucción debe ser una única declaración indicator() o strategy().",
        );
      required(["title"]);
      const t = staticValue(a.title),
        o = staticValue(a.overlay) ?? false;
      if (typeof t !== "string" || typeof o !== "boolean")
        err(e, "title debe ser texto y overlay booleano.");
      if (a.shorttitle && typeof staticValue(a.shorttitle) !== "string")
        err(e, "shorttitle debe ser texto.");
      title = t as string;
      overlay = o as boolean;
      return "void";
    }
    if (e.name.startsWith("input.")) {
      required(["defval"]);
      const kind = e.name.slice(6) as Input["kind"];
      const value = staticValue(a.defval),
        label = staticValue(a.title) ?? `Parámetro ${inputs.length + 1}`;
      const expected =
        kind === "int" || kind === "float"
          ? "number"
          : kind === "bool"
            ? "boolean"
            : "string";
      if (
        typeof value !== expected ||
        value === null ||
        (kind === "int" && !Number.isInteger(value)) ||
        typeof label !== "string"
      )
        err(e, "Valor o título de input inválido.");
      const min = staticValue(a.minval),
        max = staticValue(a.maxval),
        step = staticValue(a.step);
      for (const x of [min, max, step])
        if (
          x !== undefined &&
          (typeof x !== "number" || (kind === "int" && !Number.isInteger(x)))
        )
          err(e, "Límites de input inválidos.");
      if (
        (typeof min === "number" && typeof max === "number" && min > max) ||
        (typeof step === "number" && step <= 0) ||
        (typeof value === "number" &&
          ((typeof min === "number" && value < min) ||
            (typeof max === "number" && value > max)))
      )
        err(e, "Rango de input incoherente.");
      inputs.push({
        id: String(e.id),
        title: label as string,
        kind,
        value: value as Input["value"],
        min: min as number | undefined,
        max: max as number | undefined,
        step: step as number | undefined,
      });
      return expected;
    }
    if (["plot", "hline", "plotshape", "plotchar"].includes(e.name)) {
      if (!top)
        err(e, "Las salidas deben ser instrucciones globales independientes.");
      required([e.name === "hline" ? "price" : "series"]);
      need(
        types[e.name === "hline" ? "price" : "series"],
        e.name === "plotshape" || e.name === "plotchar"
          ? ["boolean", "na"]
          : ["number", "na"],
        e,
      );
      if (a.color) need(types.color, ["string", "na"], e);
      const label = staticValue(a.title) ?? `Salida ${plots.length + 1}`,
        style =
          staticValue(a.style) ?? (e.name === "plotshape" ? "circle" : "line"),
        width = staticValue(a.linewidth) ?? 2,
        location = staticValue(a.location) ?? "aboveBar",
        text = staticValue(a.text) ?? staticValue(a.char) ?? "";
      if (a.linestyle) err(e, "hline.linestyle aún no está implementado.");
      if (e.name === "hline") staticValue(a.price);
      if (
        typeof label !== "string" ||
        typeof text !== "string" ||
        typeof width !== "number" ||
        !Number.isInteger(width) ||
        width < 1 ||
        width > 4 ||
        !["aboveBar", "belowBar"].includes(String(location)) ||
        !(
          e.name === "plotshape"
            ? ["circle", "square", "arrowUp", "arrowDown"]
            : ["line", "histogram"]
        ).includes(String(style))
      )
        err(e, "Estilo, título o ubicación no soportado.");
      if ((label as string).length > 100 || (text as string).length > 80)
        err(e, "Título o texto demasiado largo (100/80 caracteres).");
      if (e.name === "plotchar" && [...(text as string)].length > 1)
        err(e, "plotchar requiere un carácter.");
      plots.push({
        id: e.id,
        kind: e.name as PlotDefinition["kind"],
        title: label as string,
        style: String(style),
        width: width as number,
        location: location as PlotDefinition["location"],
        text: String(text),
      });
      if (plots.length > 16) err(e, "Máximo 16 salidas.");
      return "void";
    }
    if (e.name === "na") {
      required(["x"]);
      need(types.x, ["number", "boolean", "string", "na"], e);
      return "boolean";
    }
    if (e.name === "nz") {
      required(["source"]);
      need(types.source, ["number", "na"], e);
      if (a.replacement) need(types.replacement, ["number", "na"], e);
      return "number";
    }
    required(signatures[e.name]);
    for (const type of Object.values(types)) need(type, ["number", "na"], e);
    return e.name === "ta.macd"
      ? "tuple"
      : e.name === "ta.crossover" || e.name === "ta.crossunder"
        ? "boolean"
        : "number";
  };
  for (const s of program.statements) {
    if (s.names) {
      for (const name of s.names) {
        if (
          name.includes(".") ||
          Object.hasOwn(constants, name) ||
          [
            "open",
            "high",
            "low",
            "close",
            "volume",
            "time",
            "bar_index",
            "hl2",
            "hlc3",
            "ohlc4",
            "true",
            "false",
            "na",
          ].includes(name)
        )
          err(s.expr, "Nombre de variable reservado.");
        if (s.reassign ? !variables.has(name) : variables.has(name))
          err(
            s.expr,
            s.reassign
              ? "Reasignación de variable desconocida."
              : "Variable duplicada.",
          );
      }
    }
    const type = walk(s.expr, s.persistent, !s.names);
    if (s.names) {
      if (type === "void")
        err(s.expr, "No se pueden asignar salidas gráficas ni declaraciones.");
      if (
        s.names.length > 1 !== (type === "tuple") ||
        (type === "tuple" && s.names.length !== 3)
      )
        err(s.expr, "ta.macd requiere una tupla de tres variables.");
      if (s.reassign && s.persistent)
        err(s.expr, "var no puede combinarse con :=.");
      for (const n of s.names) {
        const t = type === "tuple" ? "number" : type;
        if (
          s.reassign &&
          variables.get(n) !== t &&
          t !== "na" &&
          variables.get(n) !== "na"
        )
          err(s.expr, "La reasignación cambia el tipo.");
        variables.set(n, t);
      }
    } else if (type !== "void")
      err(s.expr, "Se esperaba declaración, asignación o salida gráfica.");
  }
  if (!declarations) throw new PineError("Falta indicator() o strategy().");
  return {
    program,
    booleanNames: [...variables]
      .filter(([, type]) => type === "boolean")
      .map(([name]) => name),
    title,
    overlay,
    inputs,
    plots,
    warnings: [
      "Subconjunto propio; no equivalencia completa con Pine Script. Números en coma flotante: división siempre real, también en v5.",
      "Cálculo sobre barras cargadas; barra abierta provisional. EMA inicia en el primer valor válido; RMA usa semilla SMA.",
      ...(program.statements[0].expr.kind === "call" &&
      program.statements[0].expr.name === "strategy"
        ? [
            "strategy() se admite sólo como análisis visual: sin órdenes, posiciones ni backtesting.",
          ]
        : []),
    ],
  };
}
