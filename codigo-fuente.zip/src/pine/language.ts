export type Token = {
  kind: "id" | "number" | "string" | "symbol" | "newline" | "eof";
  text: string;
  line: number;
  column: number;
  start: number;
  end: number;
};
export class PineError extends Error {
  constructor(
    message: string,
    public line = 1,
    public column = 1,
  ) {
    super(message);
  }
}
export const LIMITS = {
  bytes: 64000,
  tokens: 8000,
  nodes: 800,
  depth: 48,
  bars: 10000,
  cells: 2000000,
  operations: 2000000,
  plots: 16,
};
export function lex(source: string): Token[] {
  if (new TextEncoder().encode(source).length > LIMITS.bytes)
    throw new PineError("El script supera 64 KB.");
  const out: Token[] = [];
  let i = 0,
    line = 1,
    column = 1;
  const advance = () => {
    const c = source[i++];
    if (c === "\n") {
      line++;
      column = 1;
    } else column++;
    return c;
  };
  while (i < source.length) {
    const c = source[i];
    if (c === " " || c === "\t" || c === "\r") {
      advance();
      continue;
    }
    if (c === "/" && source[i + 1] === "/") {
      while (i < source.length && source[i] !== "\n") advance();
      continue;
    }
    const start = i,
      l = line,
      col = column;
    let kind: Token["kind"] = "symbol",
      text = "";
    if (c === "\n") {
      kind = "newline";
      text = advance();
    } else if (c === '"' || c === "'") {
      kind = "string";
      const quote = advance();
      let closed = false;
      while (i < source.length) {
        const x = advance();
        if (x === quote) {
          closed = true;
          break;
        }
        if (x === "\n") throw new PineError("Cadena sin cerrar.", l, col);
        if (x === "\\") {
          const e = advance();
          if (!["n", "t", "\\", '"', "'"].includes(e))
            throw new PineError("Escape de cadena no soportado.", l, col);
          text += e === "n" ? "\n" : e === "t" ? "\t" : e;
        } else text += x;
      }
      if (!closed) throw new PineError("Cadena sin cerrar.", l, col);
    } else if (
      /[0-9]/.test(c) ||
      (c === "." && /[0-9]/.test(source[i + 1] ?? ""))
    ) {
      kind = "number";
      while (i < source.length && /[0-9.]/.test(source[i])) text += advance();
      if (!Number.isFinite(Number(text)))
        throw new PineError("Número inválido.", l, col);
    } else if (/[a-zA-Z_]/.test(c)) {
      kind = "id";
      while (i < source.length && /[a-zA-Z0-9_.]/.test(source[i]))
        text += advance();
    } else if ("+-*/%<>=!?:(),[]".includes(c)) {
      text = advance();
      if ([":=", "==", "!=", "<=", ">=", "=>"].includes(text + source[i]))
        text += advance();
    } else throw new PineError(`Carácter no soportado: ${c}`, l, col);
    out.push({ kind, text, line: l, column: col, start, end: i });
    if (out.length > LIMITS.tokens)
      throw new PineError("Demasiados tokens.", l, col);
  }
  out.push({ kind: "eof", text: "", line, column, start: i, end: i });
  return out;
}
export type Value = number | boolean | string | null;
export type Expr = { id: number; token: Token } & (
  | { kind: "literal"; value: Value }
  | { kind: "name"; name: string }
  | { kind: "unary"; op: string; right: Expr }
  | { kind: "binary"; op: string; left: Expr; right: Expr }
  | { kind: "conditional"; condition: Expr; yes: Expr; no: Expr }
  | { kind: "history"; name: string; offset: number }
  | { kind: "call"; name: string; args: { name?: string; value: Expr }[] }
);
export type Statement = {
  names?: string[];
  persistent: boolean;
  reassign: boolean;
  expr: Expr;
};
export type Program = {
  version: 5 | 6;
  statements: Statement[];
  nodes: number;
};
const precedence: Record<string, number> = {
  or: 1,
  and: 2,
  "==": 3,
  "!=": 3,
  "<": 4,
  ">": 4,
  "<=": 4,
  ">=": 4,
  "+": 5,
  "-": 5,
  "*": 6,
  "/": 6,
  "%": 6,
};
export function parse(source: string): Program {
  const declarations = source
    .split("\n")
    .filter((l) => l.trim().startsWith("//@version="));
  if (
    declarations.length !== 1 ||
    !["//@version=5", "//@version=6"].includes(declarations[0].trim())
  )
    throw new PineError("Declara exactamente //@version=5 o //@version=6.");
  const version = Number(declarations[0].trim().slice(-1)) as 5 | 6;
  const tokens = lex(source);
  let pos = 0,
    nodes = 0,
    depth = 0;
  const at = () => tokens[pos];
  const error = (msg: string, t = at()): never => {
    throw new PineError(msg, t.line, t.column);
  };
  const eat = (text: string) => {
    if (at().text === text) {
      pos++;
      return true;
    }
    return false;
  };
  const expect = (text: string) => {
    if (!eat(text)) error(`Se esperaba «${text}».`);
  };
  const make = (data: Omit<Expr, "id">): Expr => {
    if (++nodes > LIMITS.nodes) error("Demasiadas expresiones.");
    return { ...data, id: nodes } as Expr;
  };
  const expression = (min = 0): Expr => {
    if (++depth > LIMITS.depth) error("Expresión demasiado profunda.");
    const t = at();
    pos++;
    let left!: Expr;
    if (
      t.kind === "number" ||
      t.kind === "string" ||
      (["true", "false", "na"].includes(t.text) && at().text !== "(")
    )
      left = make({
        kind: "literal",
        token: t,
        value:
          t.kind === "number"
            ? Number(t.text)
            : t.kind === "string"
              ? t.text
              : t.text === "na"
                ? null
                : t.text === "true",
      } as Expr);
    else if (["-", "+", "not"].includes(t.text))
      left = make({
        kind: "unary",
        token: t,
        op: t.text,
        right: expression(7),
      } as Expr);
    else if (t.text === "(") {
      left = expression();
      expect(")");
    } else if (t.kind === "id") {
      if (eat("(")) {
        const args: { name?: string; value: Expr }[] = [];
        let named = false;
        if (!eat(")")) {
          do {
            let name: string | undefined;
            if (at().kind === "id" && tokens[pos + 1]?.text === "=") {
              name = at().text;
              pos += 2;
              named = true;
            } else if (named)
              error("Un argumento posicional no puede seguir a uno nombrado.");
            if (name && args.some((a) => a.name === name))
              error("Argumento duplicado.");
            args.push({ name, value: expression() });
          } while (eat(","));
          expect(")");
        }
        left = make({ kind: "call", token: t, name: t.text, args } as Expr);
      } else left = make({ kind: "name", token: t, name: t.text } as Expr);
    } else error("Expresión no soportada o incompleta.", t);
    if (eat("[")) {
      if (left.kind !== "name")
        error("En este subconjunto, [] sólo se admite sobre variables.");
      const offset = at();
      pos++;
      if (
        offset.kind !== "number" ||
        !Number.isInteger(Number(offset.text)) ||
        Number(offset.text) > 5000
      )
        error(
          "El histórico requiere un entero literal entre 0 y 5000.",
          offset,
        );
      expect("]");
      left = make({
        kind: "history",
        token: t,
        name: (left as Expr & { name: string }).name,
        offset: Number(offset.text),
      } as Expr);
    }
    while (
      Object.hasOwn(precedence, at().text) &&
      precedence[at().text] >= min
    ) {
      const op = at();
      pos++;
      left = make({
        kind: "binary",
        token: op,
        op: op.text,
        left,
        right: expression(precedence[op.text] + 1),
      } as Expr);
    }
    if (min === 0 && eat("?")) {
      const yes = expression();
      expect(":");
      left = make({
        kind: "conditional",
        token: t,
        condition: left,
        yes,
        no: expression(),
      } as Expr);
    }
    depth--;
    return left;
  };
  const statements: Statement[] = [];
  while (at().kind !== "eof") {
    if (at().kind === "newline") {
      pos++;
      continue;
    }
    if (at().column !== 1)
      error(
        "Bloques indentados y continuaciones no soportados. Usa expresiones globales y ?: .",
      );
    let persistent = eat("var");
    const reassignCandidate = at();
    let names: string[] | undefined,
      reassign = false;
    if (["float", "int", "bool", "string"].includes(at().text))
      error("Las declaraciones con tipo explícito aún no están soportadas.");
    if (eat("[")) {
      names = [];
      do {
        if (at().kind !== "id" || at().text.includes("."))
          error("Nombre de variable inválido.");
        names.push(at().text);
        pos++;
      } while (eat(","));
      expect("]");
      expect("=");
    } else if (
      at().kind === "id" &&
      ["=", ":="].includes(tokens[pos + 1]?.text)
    ) {
      names = [at().text];
      pos++;
      reassign = eat(":=");
      if (!reassign) expect("=");
    } else if (persistent || reassignCandidate !== at())
      error("Se esperaba una declaración de variable.");
    const expr = expression();
    if (at().kind !== "newline" && at().kind !== "eof")
      error(
        "Construcción no soportada. No se admiten funciones, bloques ni bucles.",
      );
    statements.push({ names, persistent, reassign, expr });
    persistent = false;
  }
  return { version, statements, nodes };
}
