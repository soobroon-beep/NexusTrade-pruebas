import { afterEach, beforeEach, describe, it, expect, vi } from "vitest";
import { requestWorker } from "./client";
class FakeWorker {
  static instances: FakeWorker[] = [];
  onmessage: ((e: { data: unknown }) => void) | null = null;
  onerror: (() => void) | null = null;
  terminate = vi.fn();
  postMessage = vi.fn();
  constructor() {
    FakeWorker.instances.push(this);
  }
}
beforeEach(() => {
  vi.useFakeTimers();
  FakeWorker.instances = [];
  vi.stubGlobal("Worker", FakeWorker);
});
afterEach(() => {
  vi.useRealTimers();
  vi.unstubAllGlobals();
});
describe("aislamiento y ciclo del Worker", () => {
  it("termina al recibir resultado, ignora identificador distinto", async () => {
    const p = requestWorker({ id: 7, source: "" });
    const w = FakeWorker.instances[0];
    w.onmessage?.({ data: { id: 6, ok: false } });
    expect(w.terminate).not.toHaveBeenCalled();
    w.onmessage?.({
      data: { id: 7, ok: false, error: { message: "X", line: 1, column: 1 } },
    });
    expect((await p).ok).toBe(false);
    expect(w.terminate).toHaveBeenCalledOnce();
  });
  it("cancela por timeout con terminación real de la instancia", async () => {
    const p = requestWorker({ id: 1, source: "" });
    const rejection = expect(p).rejects.toThrow("3 segundos");
    await vi.advanceTimersByTimeAsync(3000);
    await rejection;
    expect(FakeWorker.instances[0].terminate).toHaveBeenCalledOnce();
  });
  it("libera recursos al cambiar mercado o desmontar", async () => {
    const c = new AbortController();
    const p = requestWorker({ id: 1, source: "" }, c.signal);
    const rejection = expect(p).rejects.toMatchObject({ name: "AbortError" });
    c.abort();
    await rejection;
    expect(FakeWorker.instances[0].terminate).toHaveBeenCalledOnce();
    expect(vi.getTimerCount()).toBe(0);
  });
  it("no inicia un trabajo cancelado", async () => {
    const c = new AbortController();
    c.abort();
    await expect(
      requestWorker({ id: 1, source: "" }, c.signal),
    ).rejects.toThrow();
    expect(FakeWorker.instances).toHaveLength(0);
  });
  it("informa fallo del Worker y lo termina", async () => {
    const p = requestWorker({ id: 1, source: "" });
    const rejection = expect(p).rejects.toThrow("Worker");
    FakeWorker.instances[0].onerror?.();
    await rejection;
    expect(FakeWorker.instances[0].terminate).toHaveBeenCalledOnce();
  });
});
