import { useEffect, useState } from "react";
import type { Candle } from "../domain/types";
import { useScripts } from "../state/scripts";
import { requestWorker } from "./client";
import type { Result } from "./runtime";
export function useScript(candles: Candle[], marketKey: string) {
  const data = useScripts((s) => s.data);
  const active = data.items.find((s) => s.id === data.active);
  const key =
    marketKey +
    "|" +
    (active
      ? JSON.stringify([active.id, active.source, active.parameters])
      : "");
  const [state, setState] = useState<{
    key: string;
    result?: Result;
    error?: string;
    busy: boolean;
  }>({ key: "", busy: false });
  useEffect(() => {
    const controller = new AbortController();
    if (!active || !candles.length) {
      setState({ key, busy: false });
      return;
    }
    setState((previous) => ({
      key,
      busy: true,
      result: previous.key === key ? previous.result : undefined,
    }));
    const timer = setTimeout(() => {
      void requestWorker(
        {
          id: 1,
          source: active.source,
          parameters: active.parameters,
          candles,
        },
        controller.signal,
      )
        .then((r) => {
          if (controller.signal.aborted) return;
          setState(
            r.ok
              ? { key, result: r.result, busy: false }
              : {
                  key,
                  error: `L${r.error.line}:${r.error.column} — ${r.error.message}`,
                  busy: false,
                },
          );
        })
        .catch((e) => {
          if (!controller.signal.aborted)
            setState({ key, error: e.message, busy: false });
        });
    }, 250);
    return () => {
      clearTimeout(timer);
      controller.abort();
    };
  }, [candles, key, active]);
  return {
    result: state.key === key ? state.result : undefined,
    error: state.key === key ? state.error : undefined,
    busy: state.key === key && state.busy,
    active,
  };
}
