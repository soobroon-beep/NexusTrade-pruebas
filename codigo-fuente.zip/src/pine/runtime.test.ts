import { describe, it, expect } from "vitest";
import { compile } from "./compiler";
import { execute, run } from "./runtime";
import { lex, parse, PineError } from "./language";
import { examples } from "./examples";
import type { Candle } from "../domain/types";
const candles = (values: number[]): Candle[] =>
  values.map((close, i) => ({
    time: 1700000000 + i * 60,
    open: close,
    high: close + 1,
    low: close - 1,
    close,
    volume: 10,
    closed: true,
    closeTime: (1700000000 + i * 60) * 1000 + 59999,
    source: "Binance Spot",
    receivedAt: 0,
  }));
const bars = candles([1, 2, 3, 2, 4, 5]);
const script = (body: string, v = 6) =>
  `//@version=${v}\nindicator("Test", overlay=true)\n${body}`;
const output = (body: string, cs = bars) =>
  run(script(body), cs).result.plots[0].points.map((x) => x.value);
describe("lexer y parser reales", () => {
  it("mantiene posiciones y no interpreta comentarios ni cadenas como llamadas", () => {
    const t = lex('x = "request.security()" // close[2]\nplot(x)');
    expect(t.find((x) => x.text === "plot")).toMatchObject({
      line: 2,
      column: 1,
    });
    expect(t.filter((x) => x.kind === "string")).toHaveLength(1);
  });
  it("construye AST con precedencia y ternario", () => {
    expect(output("plot(1 + 2 * 3 == 7 ? 8 : 9)")[0]).toBe(8);
    expect(parse(script("x = close[1]\nplot(x)")).statements[1].expr.kind).toBe(
      "history",
    );
  });
  it("diagnostica línea y columna", () => {
    try {
      compile(script("plot(close"));
    } catch (e) {
      expect(e).toBeInstanceOf(PineError);
      expect(e).toMatchObject({ line: 3, column: 11 });
    }
  });
  it.each([
    'request.security("BTC", "D", close)',
    'fetch("https://example.com")',
    'eval("1")',
    'Function("return 1")',
    "window.localStorage",
    "document.cookie",
    "close[-1]",
    "close[1.5]",
    "ta.fake(close)",
    "plot(close, offset=1)",
    "fill(1,2)",
    "bgcolor(color.red)",
  ])("rechaza %s", (body) => {
    expect(() => compile(script(body))).toThrow();
  });
  it.each([
    "if close > open\n    plot(close)",
    "f(x) => x + 1",
    "for i = 0 to 9\n    x = i",
    "x = close\nx = open",
    "x := 1",
    "[a,b] = ta.macd(close,12,26,9)",
    "plot(ta.ema(close,2), display=1)",
    "plot(close > 0 ? ta.ema(close,2) : 0)",
    "var x = ta.sma(close, 2)",
    "float x = 1",
  ])("rechaza construcciones ambiguas: %s", (body) =>
    expect(() => compile(script(body))).toThrow(),
  );
  it("requiere declaración única y versión explícita", () => {
    expect(() => compile('indicator("x")')).toThrow();
    expect(() => compile('//@version=4\nindicator("x")')).toThrow();
    expect(() => compile(script('indicator("otra")'))).toThrow();
  });
  it("strategy nunca habilita trading", () => {
    expect(
      compile('//@version=6\nstrategy("Análisis")\nplot(close)').warnings.join(
        " ",
      ),
    ).toContain("sin órdenes");
    expect(() =>
      compile('//@version=6\nstrategy("x")\nstrategy.entry("long", 1)'),
    ).toThrow();
  });
});
describe("series y evaluación barra por barra", () => {
  it("SMA y calentamiento", () =>
    expect(output("plot(ta.sma(close,3))")).toEqual([
      null,
      null,
      2,
      7 / 3,
      3,
      11 / 3,
    ]));
  it("EMA usa semilla primer valor, no semilla n barras", () =>
    expect(output("plot(ta.ema(close,3))")).toEqual([
      1, 1.5, 2.25, 2.125, 3.0625, 4.03125,
    ]));
  it("ATR Wilder y RSI", () => {
    expect(output("plot(ta.atr(3))")).toEqual([
      null,
      null,
      2,
      2,
      7 / 3,
      20 / 9,
    ]);
    const r = output("plot(ta.rsi(close,3))");
    expect(r.slice(0, 3)).toEqual([null, null, null]);
    expect(r[3]).toBeCloseTo(66.6666667);
    expect(r[4]).toBeCloseTo(83.3333333);
  });
  it("MACD tupla, señal e histograma", () => {
    const r = run(
      script("[m,s,h] = ta.macd(close,2,3,2)\nplot(m)\nplot(s)\nplot(h)"),
      bars,
    ).result;
    expect(r.plots[0].points[1].value).toBeCloseTo(1 / 6);
    expect(r.plots[1].points[1].value).toBeCloseTo(1 / 9);
    expect(r.plots[2].points[1].value).toBeCloseTo(1 / 18);
  });
  it("histórico, time en ms y bar_index", () => {
    expect(output("plot(close[1])")).toEqual([null, 1, 2, 3, 2, 4]);
    expect(output("plot(time)")[0]).toBe(1700000000000);
    expect(output("plot(bar_index)")).toEqual([0, 1, 2, 3, 4, 5]);
  });
  it("var persiste entre barras y := actualiza una vez", () =>
    expect(output("var x = 0\nx := x + close\nplot(x)")).toEqual([
      1, 3, 6, 8, 12, 17,
    ]));
  it("cruces son eventos, no estado continuo", () => {
    expect(output("up = ta.crossover(close, 2.5)\nplot(up ? 1 : 0)")).toEqual([
      0, 0, 1, 0, 1, 0,
    ]);
    expect(
      output("down = ta.crossunder(close, 2.5)\nplot(down ? 1 : 0)"),
    ).toEqual([0, 0, 0, 1, 0, 0]);
  });
  it("na y nz sin convertir faltantes en ceros silenciosos", () => {
    expect(output("x = close[1]\nplot(na(x) ? 9 : nz(x))")).toEqual([
      9, 1, 2, 3, 2, 4,
    ]);
    expect(output("plot(close / 0)")).toEqual(Array(6).fill(null));
  });
  it("v5 propaga na booleano; v6 comparación na falsa", () => {
    const body = "x = close[1] > 0\nplot(na(x) ? 1 : 0)";
    expect(run(script(body, 5), bars).result.plots[0].points[0].value).toBe(1);
    expect(output(body)[0]).toBe(0);
  });
  it("no hay lookahead: un prefijo coincide con ejecución completa", () => {
    const source = script("x = ta.ema(close,3)\nplot(x)");
    expect(run(source, bars.slice(0, 4)).result.plots[0].points).toEqual(
      run(source, bars).result.plots[0].points.slice(0, 4),
    );
  });
  it("una barra abierta se reconstruye sin acumular ticks", () => {
    const source = script("var x = 0\nx := x + close\nplot(x)");
    const live = [...bars.slice(0, -1), { ...bars.at(-1)!, closed: false }];
    expect(run(source, live).result.lastClosed).toBe(false);
    const changed = [
      ...live.slice(0, -1),
      { ...live.at(-1)!, close: 8, high: 9 },
    ];
    run(source, live);
    expect(run(source, changed).result.plots[0].points.at(-1)?.value).toBe(20);
    expect(run(source, changed).result.plots[0].points.at(-1)?.closed).toBe(
      false,
    );
  });
  it("inputs y valores fuera de rango", () => {
    const c = compile(
      script('n = input.int(3,"N",minval=1,maxval=10)\nplot(ta.sma(close,n))'),
    );
    expect(
      execute(c, bars, { [c.inputs[0].id]: 2 }).plots[0].points[1].value,
    ).toBe(1.5);
    expect(() => execute(c, bars, { [c.inputs[0].id]: 0 })).toThrow();
    expect(() => execute(c, bars, { "999": 2 })).toThrow();
  });
  it("formas, colores y cierres", () => {
    const r = run(
      script(
        "plotshape(close > 3 and barstate.isconfirmed, style=shape.triangleup, color=color.red, location=location.belowbar)",
      ),
      bars,
    ).result;
    expect(r.plots[0].points.map((x) => x.value)).toEqual([
      null,
      null,
      null,
      null,
      3,
      4,
    ]);
    expect(r.plots[0].points[4].color).toBe("#f23645");
  });
  it("rechaza colores arbitrarios y periodos dinámicos", () => {
    expect(() => run(script('plot(close,color="url(evil)")'), bars)).toThrow();
    expect(() => run(script("plot(ta.sma(close,bar_index+1))"), bars)).toThrow(
      "dinámicos",
    );
  });
  it("aplica límites de operaciones, barras, tamaño y profundidad", () => {
    expect(() => execute(compile(script("plot(close)")), bars, {}, 1)).toThrow(
      "operaciones",
    );
    expect(() =>
      execute(compile(script("plot(close)")), Array(10001).fill(bars[0])),
    ).toThrow("barras");
    expect(() => compile("x".repeat(64001))).toThrow();
    expect(() =>
      compile(script("plot(" + "(".repeat(60) + "1" + ")".repeat(60) + ")")),
    ).toThrow("profunda");
  });
  it.each(examples.slice(0, 4))("ejemplo soportado: $name", (e) =>
    expect(run(e.source, bars).result.plots.length).toBeGreaterThan(0),
  );
  it.each(examples.slice(4))("ejemplo rechazado: $name", (e) =>
    expect(() => compile(e.source)).toThrow(),
  );
});

it("el histórico booleano ausente es false en v6 y na en v5", () => {
  const body = "x = close > 0\nplot(na(x[1]) ? 1 : 0)";
  expect(output(body)[0]).toBe(0);
  expect(run(script(body, 5), bars).result.plots[0].points[0].value).toBe(1);
});
it("no sustituye opciones na por valores por defecto", () => {
  expect(() =>
    compile('//@version=6\nindicator("X", overlay=na)\nplot(close)'),
  ).toThrow();
  expect(() => compile(script("plot(close, linewidth=na)"))).toThrow();
});
