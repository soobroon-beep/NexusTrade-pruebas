import type { Candle } from "../domain/types";
import type { Compiled } from "./compiler";
import type { Value } from "./language";
import type { Result } from "./runtime";
export type Report = Pick<
  Compiled,
  "title" | "overlay" | "inputs" | "plots" | "warnings"
> & { version: 5 | 6 };
export type Request = {
  id: number;
  source: string;
  candles?: Candle[];
  parameters?: Record<string, Value>;
};
export type Response =
  | { id: number; ok: true; report: Report; result?: Result }
  | {
      id: number;
      ok: false;
      error: { message: string; line: number; column: number };
    };
