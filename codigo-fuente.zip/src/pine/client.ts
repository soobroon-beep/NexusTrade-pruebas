import type { Request, Response } from "./protocol";
export function requestWorker(
  request: Request,
  signal?: AbortSignal,
): Promise<Response> {
  return new Promise((resolve, reject) => {
    if (signal?.aborted) {
      reject(new DOMException("Cancelado", "AbortError"));
      return;
    }
    const worker = new Worker(new URL("./worker.ts", import.meta.url), {
      type: "module",
    });
    const stop = () => {
      clearTimeout(timer);
      worker.terminate();
      signal?.removeEventListener("abort", abort);
    };
    const abort = () => {
      stop();
      reject(new DOMException("Cancelado", "AbortError"));
    };
    const timer = setTimeout(() => {
      stop();
      reject(
        new Error(
          "Ejecución cancelada: excedió 3 segundos. Reduce el script o el histórico.",
        ),
      );
    }, 3000);
    signal?.addEventListener("abort", abort, { once: true });
    worker.onmessage = (event: MessageEvent<Response>) => {
      if (event.data.id === request.id) {
        stop();
        resolve(event.data);
      }
    };
    worker.onerror = () => {
      stop();
      reject(new Error("No se pudo iniciar o ejecutar el Worker aislado."));
    };
    worker.postMessage(request);
  });
}
