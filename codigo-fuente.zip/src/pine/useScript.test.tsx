// @vitest-environment jsdom
import { it, expect, vi, afterEach } from "vitest";
import { act, renderHook, cleanup } from "@testing-library/react";
import { useScript } from "./useScript";
import { useScripts } from "../state/scripts";
import { requestWorker } from "./client";
import type { Response } from "./protocol";
import type { Candle } from "../domain/types";
vi.mock("./client", () => ({ requestWorker: vi.fn() }));
afterEach(() => {
  cleanup();
  vi.useRealTimers();
  vi.clearAllMocks();
});
it("cancela el mercado anterior y no acepta un resultado tardío, luego retira el script", async () => {
  vi.useFakeTimers();
  const pending: { signal?: AbortSignal; resolve: (r: Response) => void }[] =
    [];
  vi.mocked(requestWorker).mockImplementation(
    (_r, signal) => new Promise((resolve) => pending.push({ signal, resolve })),
  );
  useScripts
    .getState()
    .setData({
      version: 1,
      active: "a",
      items: [
        {
          id: "a",
          name: "A",
          source: '//@version=6\nindicator("A")\nplot(close)',
          original: "original",
          revision: 1,
          updatedAt: 1,
          parameters: {},
          description: "",
        },
      ],
    });
  const candles: Candle[] = [
    {
      time: 60,
      close: 1,
      open: 1,
      high: 2,
      low: 0,
      volume: 1,
      closeTime: 119999,
      closed: true,
      source: "Binance Spot",
      receivedAt: 0,
    },
  ];
  const { result, rerender } = renderHook(
    ({ market }) => useScript(candles, market),
    { initialProps: { market: "BTCUSDT-1h" } },
  );
  await act(async () => {
    await vi.advanceTimersByTimeAsync(250);
  });
  rerender({ market: "ETHUSDT-4h" });
  expect(pending[0].signal?.aborted).toBe(true);
  expect(result.current.result).toBeUndefined();
  await act(async () => {
    pending[0].resolve({
      id: 1,
      ok: false,
      error: { message: "OLD", line: 1, column: 1 },
    });
    await vi.advanceTimersByTimeAsync(250);
  });
  expect(result.current.error).toBeUndefined();
  await act(async () => {
    pending[1].resolve({
      id: 1,
      ok: false,
      error: { message: "CURRENT", line: 3, column: 1 },
    });
  });
  expect(result.current.error).toContain("CURRENT");
  act(() =>
    useScripts
      .getState()
      .setData({ ...useScripts.getState().data, active: null }),
  );
  expect(result.current.error).toBeUndefined();
  expect(result.current.active).toBeUndefined();
});
