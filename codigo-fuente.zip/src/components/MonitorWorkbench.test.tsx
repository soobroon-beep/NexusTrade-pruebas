// @vitest-environment jsdom
import { beforeEach, afterEach, it, expect, vi } from "vitest";
import { render, fireEvent, screen, cleanup } from "@testing-library/react";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { MonitorWorkbench } from "./MonitorWorkbench";
import { useMonitor } from "../state/monitor";
import { defaultMonitor } from "../storage/monitor";
import type { Candle } from "../domain/types";
const candle: Candle = {
  time: 0,
  open: 1,
  high: 3,
  low: 0,
  close: 2,
  volume: 1,
  closeTime: 59999,
  closed: true,
  source: "Binance Spot",
  receivedAt: 0,
};
beforeEach(() => {
  useMonitor.getState().setData(defaultMonitor);
  HTMLDialogElement.prototype.showModal = function () {
    this.setAttribute("open", "");
  };
  HTMLDialogElement.prototype.close = function () {
    this.removeAttribute("open");
  };
});
afterEach(cleanup);
it("comprobar no dispara; crear, editar y pausar conserva umbral y UTC", () => {
  const client = new QueryClient({
    defaultOptions: { queries: { retry: false } },
  });
  render(
    <QueryClientProvider client={client}>
      <MonitorWorkbench
        context={{
          candles: [candle, { ...candle, time: 60, closeTime: 119999 }],
          symbol: "BTCUSDT",
          interval: "1m",
          indicators: [],
          drawings: [],
          script: {},
        }}
        messages={{}}
        now={Date.now()}
        onSelect={vi.fn()}
      />
    </QueryClientProvider>,
  );
  fireEvent.click(screen.getByText("♧ Alertas"));
  fireEvent.click(screen.getByText("Nueva alerta"));
  fireEvent.change(screen.getByLabelText("Nombre"), {
    target: { value: "Alerta local" },
  });
  fireEvent.change(screen.getByLabelText("Umbral"), { target: { value: "1" } });
  const expiration = new Date(Date.now() + 86400000).toISOString().slice(0, 16);
  fireEvent.change(screen.getByLabelText("Expiración · UTC"), {
    target: { value: expiration },
  });
  fireEvent.click(screen.getByText("Comprobar último cierre"));
  expect(useMonitor.getState().data.events).toHaveLength(0);
  expect(screen.getByRole("status").textContent).toContain(
    "No genera una alerta",
  );
  fireEvent.click(screen.getByText("Guardar y armar"));
  expect(useMonitor.getState().data.rules[0]).toMatchObject({
    name: "Alerta local",
    expiresAt: new Date(expiration + "Z").getTime(),
    status: "armed",
  });
  fireEvent.click(screen.getByText("Editar"));
  fireEvent.change(screen.getByLabelText("Nombre"), {
    target: { value: "Editada" },
  });
  fireEvent.click(screen.getByText("Guardar y armar"));
  expect(useMonitor.getState().data.rules).toHaveLength(1);
  expect(useMonitor.getState().data.rules[0].name).toBe("Editada");
  fireEvent.click(screen.getByText("Pausar"));
  expect(useMonitor.getState().data.rules[0].status).toBe("paused");
  client.clear();
});
