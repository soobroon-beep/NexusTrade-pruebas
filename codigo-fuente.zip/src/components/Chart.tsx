import { StructureLayer } from "./StructureLayer";
import type { StructureConfig, StructureResult } from "../structure/engine";
import type { Result } from "../pine/runtime";
import { useEffect, useRef, useState } from "react";
import {
  createChart,
  CandlestickSeries,
  BarSeries,
  LineSeries,
  AreaSeries,
  HistogramSeries,
  ColorType,
  createSeriesMarkers,
  type ISeriesMarkersPluginApi,
  type LineWidth,
  type IChartApi,
  type ISeriesApi,
  type UTCTimestamp,
  type Time,
} from "lightweight-charts";
import type { Candle } from "../domain/types";
import type { Workspace } from "../storage/workspace";
import { registry, type IndicatorConfig } from "../indicators/registry";
import { IndicatorEngine } from "../indicators/engine";
import { DrawingLayer, type PriceSeries } from "./DrawingLayer";
import type { Drawing, DrawingTool } from "../drawings/model";
export function Chart({
  structure,
  structureConfig,
  scriptResult,
  candles,
  chartType,
  volume,
  marketKey,
  onOlder,
  canLoad,
  fitToken,
  indicators,
  drawings,
  tool,
  onTool,
  onDrawingsChange,
  selectedDrawing,
  onSelectedDrawing,
}: {
  structure?: StructureResult;
  structureConfig: StructureConfig;
  scriptResult?: Result;
  candles: Candle[];
  chartType: Workspace["chartType"];
  volume: boolean;
  marketKey: string;
  onOlder: () => void;
  canLoad: boolean;
  fitToken: number;
  indicators: IndicatorConfig[];
  drawings: Drawing[];
  tool: DrawingTool | null;
  onTool: (tool: DrawingTool | null) => void;
  onDrawingsChange: (items: Drawing[]) => void;
  selectedDrawing: string | null;
  onSelectedDrawing: (id: string | null) => void;
}) {
  const scriptSeries = useRef<ISeriesApi<"Line" | "Histogram">[]>([]);
  const scriptMarkers = useRef<ISeriesMarkersPluginApi<Time>[]>([]);
  const container = useRef<HTMLDivElement>(null);
  const chart = useRef<IChartApi | undefined>(undefined);
  const price = useRef<
    ISeriesApi<"Candlestick" | "Bar" | "Line" | "Area"> | undefined
  >(undefined);
  const volumeSeries = useRef<ISeriesApi<"Histogram"> | undefined>(undefined);
  const indicatorRuntime = useRef<
    {
      config: IndicatorConfig;
      engine: IndicatorEngine;
      series: ISeriesApi<"Line" | "Histogram">[];
      markers?: ISeriesMarkersPluginApi<Time>;
    }[]
  >([]);
  const [drawingApi, setDrawingApi] = useState<{
    api: IChartApi;
    series: PriceSeries;
  } | null>(null);
  const data = useRef(candles);
  const older = useRef(onOlder);
  const can = useRef(canLoad);
  const interacted = useRef(false);
  const lastKey = useRef("");
  const previousStart = useRef(0);
  const previousData = useRef<Candle[]>([]);
  const [hover, setHover] = useState<Candle>();
  data.current = candles;
  older.current = onOlder;
  can.current = canLoad;
  useEffect(() => {
    if (!container.current) return;
    const el = container.current;
    const api = createChart(el, {
      layout: {
        background: { type: ColorType.Solid, color: "#0c121b" },
        textColor: "#8b99ad",
        attributionLogo: true,
        fontFamily: "ui-monospace, SFMono-Regular, monospace",
        fontSize: 12,
      },
      grid: {
        vertLines: { color: "#18212d" },
        horzLines: { color: "#18212d" },
      },
      rightPriceScale: {
        borderColor: "#25303e",
        scaleMargins: { top: 0.12, bottom: 0.1 },
      },
      timeScale: {
        borderColor: "#25303e",
        timeVisible: true,
        secondsVisible: false,
        rightOffset: 6,
      },
      crosshair: { mode: 0 },
      localization: { locale: "es-MX" },
    });
    chart.current = api;
    api.subscribeCrosshairMove((p) => {
      setHover(data.current.find((c) => c.time === p.time));
    });
    api.timeScale().subscribeVisibleLogicalRangeChange((range) => {
      if (range && range.from < 10 && can.current && interacted.current) {
        interacted.current = false;
        older.current();
      }
    });
    const arm = () => {
      interacted.current = true;
    };
    el.addEventListener("wheel", arm, { passive: true });
    el.addEventListener("pointerdown", arm);
    const resize = new ResizeObserver(([entry]) =>
      api.applyOptions({
        width: entry.contentRect.width,
        height: entry.contentRect.height,
      }),
    );
    resize.observe(el);
    return () => {
      resize.disconnect();
      el.removeEventListener("wheel", arm);
      el.removeEventListener("pointerdown", arm);
      api.remove();
      indicatorRuntime.current = [];
      scriptSeries.current = [];
      scriptMarkers.current = [];
      chart.current = undefined;
      price.current = undefined;
      volumeSeries.current = undefined;
      lastKey.current = "";
    };
  }, []);
  useEffect(() => {
    const api = chart.current;
    if (!api) return;
    for (const marker of scriptMarkers.current) marker.detach();
    scriptMarkers.current = [];
    for (const series of scriptSeries.current) api.removeSeries(series);
    scriptSeries.current = [];
    previousData.current = [];
    for (const runtime of indicatorRuntime.current) {
      runtime.markers?.detach();
      for (const series of runtime.series) api.removeSeries(series);
    }
    indicatorRuntime.current = [];
    if (price.current) api.removeSeries(price.current);
    if (volumeSeries.current) {
      api.removeSeries(volumeSeries.current);
      volumeSeries.current = undefined;
    }
    const candlesStyle = {
      upColor: "#46d5ae",
      downColor: "#f07583",
      borderVisible: false,
      wickUpColor: "#46d5ae",
      wickDownColor: "#f07583",
    };
    price.current =
      chartType === "candles"
        ? api.addSeries(CandlestickSeries, candlesStyle)
        : chartType === "bars"
          ? api.addSeries(BarSeries, {
              upColor: "#46d5ae",
              downColor: "#f07583",
            })
          : chartType === "area"
            ? api.addSeries(AreaSeries, {
                lineColor: "#57d6b2",
                topColor: "#46d5ae35",
                bottomColor: "#46d5ae00",
              })
            : api.addSeries(LineSeries, { color: "#57d6b2", lineWidth: 2 });
    if (volume) {
      volumeSeries.current = api.addSeries(
        HistogramSeries,
        {
          priceFormat: { type: "volume" },
          priceLineVisible: false,
          lastValueVisible: false,
        },
        1,
      );
      api.panes()[1]?.setHeight(110);
    }
    let pane = volume ? 2 : 1;
    for (const config of indicators.filter((i) => i.visible)) {
      const definition = registry[config.kind];
      const index = definition.location === "overlay" ? 0 : pane++;
      const output = definition.outputs.map((o, i) => {
        const color = i === 0 ? config.color : i === 1 ? "#e8b66e" : "#b79cee";
        const common = {
          title: definition.name + " " + o.name,
          priceLineVisible: false,
          color,
          priceFormat:
            definition.location === "pane"
              ? { type: "price" as const, precision: 2, minMove: 0.01 }
              : undefined,
        };
        return o.style === "histogram"
          ? api.addSeries(HistogramSeries, common, index)
          : api.addSeries(
              LineSeries,
              { ...common, lineWidth: config.width as LineWidth },
              index,
            );
      });
      if (definition.location === "pane")
        api.panes()[index]?.setHeight(config.height);
      if (config.kind === "rsi" || config.kind === "stochastic") {
        for (const value of config.kind === "rsi" ? [30, 70] : [20, 80])
          output[0].createPriceLine({
            price: value,
            color: "#63748d",
            lineWidth: 1,
            lineStyle: 2,
            axisLabelVisible: true,
            title: "",
          });
      }
      indicatorRuntime.current.push({
        config,
        engine: new IndicatorEngine(config),
        series: output,
        markers:
          config.kind === "cross"
            ? createSeriesMarkers(price.current, [])
            : undefined,
      });
    }
    setDrawingApi({ api, series: price.current });
  }, [chartType, volume, indicators]);
  useEffect(() => {
    const api = chart.current;
    const series = price.current;
    if (!api || !series) return;
    const lastPrice = candles.at(-1)?.close;
    const precision =
      lastPrice === undefined ? 2 : lastPrice < 1 ? 8 : lastPrice < 100 ? 4 : 2;
    series.applyOptions({
      priceFormat: { type: "price", precision, minMove: 10 ** -precision },
    });
    const range = api.timeScale().getVisibleLogicalRange();
    const oldStart = previousStart.current;
    const added = candles.findIndex((c) => c.time === oldStart);
    const pricePoint = (c: Candle) => ({
      time: c.time as UTCTimestamp,
      open: c.open,
      high: c.high,
      low: c.low,
      close: c.close,
      value: c.close,
    });
    const volumePoint = (c: Candle) => ({
      time: c.time as UTCTimestamp,
      value: c.volume,
      color: c.close >= c.open ? "#46d5ae70" : "#f0758370",
    });
    const previous = previousData.current;
    const tailOnly =
      previous.length > 0 &&
      candles.length >= previous.length &&
      candles.length <= previous.length + 1 &&
      previous.slice(0, -1).every((c, i) => c === candles[i]) &&
      previous.at(-1)?.time === candles[previous.length - 1]?.time &&
      lastKey.current === marketKey;
    if (tailOnly) {
      for (const c of candles.slice(previous.length - 1)) {
        series.update(pricePoint(c));
        volumeSeries.current?.update(volumePoint(c));
      }
    } else {
      series.setData(candles.map(pricePoint));
      volumeSeries.current?.setData(candles.map(volumePoint));
    }
    previousData.current = candles;
    if (
      candles.length &&
      (lastKey.current !== marketKey ||
        (previous.length < 30 && candles.length >= 30))
    ) {
      api.timeScale().setVisibleLogicalRange({
        from: Math.max(0, candles.length - 120),
        to: candles.length + 6,
      });
      lastKey.current = marketKey;
      setHover(undefined);
    } else if (range && added > 0)
      api.timeScale().setVisibleLogicalRange({
        from: range.from + added,
        to: range.to + added,
      });
    previousStart.current = candles[0]?.time ?? 0;
  }, [candles, chartType, volume, marketKey, indicators]);
  useEffect(() => {
    for (const runtime of indicatorRuntime.current) {
      const rows = runtime.engine.update(candles);
      runtime.series.forEach((series, index) =>
        series.setData(
          rows.map((r, i) =>
            r.values[index] === null
              ? { time: r.time as UTCTimestamp }
              : {
                  time: r.time as UTCTimestamp,
                  value: r.values[index]!,
                  color:
                    runtime.config.kind === "supertrend"
                      ? r.direction === 1
                        ? runtime.config.color
                        : "#f07583"
                      : registry[runtime.config.kind].outputs[index].style ===
                          "histogram"
                        ? runtime.config.kind === "volume"
                          ? candles[i].close >= candles[i].open
                            ? runtime.config.color
                            : "#f07583"
                          : r.values[index]! >= 0
                            ? runtime.config.color
                            : "#f07583"
                        : undefined,
                },
          ),
        ),
      );
      runtime.markers?.setMarkers(
        rows
          .filter((r) => r.signal)
          .map((r) => ({
            time: r.time as UTCTimestamp,
            position: r.signal === 1 ? "belowBar" : "aboveBar",
            shape: r.signal === 1 ? "arrowUp" : "arrowDown",
            color: r.signal === 1 ? runtime.config.color : "#f07583",
            text: r.closed ? "Cruce" : "Cruce provisional",
          })),
      );
    }
  }, [candles, chartType, volume, indicators, marketKey]);
  useEffect(() => {
    const api = chart.current;
    if (!api || !price.current) return;
    for (const marker of scriptMarkers.current) marker.detach();
    scriptMarkers.current = [];
    for (const series of scriptSeries.current) api.removeSeries(series);
    scriptSeries.current = [];
    if (!scriptResult) return;
    const pane = scriptResult.overlay ? 0 : api.panes().length;
    for (const output of scriptResult.plots) {
      const markers = output.kind === "plotshape" || output.kind === "plotchar";
      const common = {
        title: scriptResult.title + " · " + output.title,
        color: "#57d6b2",
        priceLineVisible: false,
        lastValueVisible: !markers,
        priceFormat: {
          type: "price" as const,
          precision: scriptResult.overlay ? 8 : 4,
          minMove: scriptResult.overlay ? 0.00000001 : 0.0001,
        },
      };
      const series =
        output.style === "histogram" && !markers
          ? api.addSeries(HistogramSeries, common, pane)
          : api.addSeries(
              LineSeries,
              {
                ...common,
                lineWidth: output.width as LineWidth,
                lineVisible: !markers,
                crosshairMarkerVisible: !markers,
              },
              pane,
            );
      scriptSeries.current.push(series);
      series.setData(
        output.points.map((p) =>
          p.value === null
            ? { time: p.time as UTCTimestamp }
            : { time: p.time as UTCTimestamp, value: p.value, color: p.color },
        ),
      );
      if (markers)
        scriptMarkers.current.push(
          createSeriesMarkers(
            series,
            output.points
              .filter((p) => p.value !== null)
              .map((p) => ({
                time: p.time as UTCTimestamp,
                position: output.location,
                shape:
                  output.kind === "plotchar"
                    ? ("circle" as const)
                    : (output.style as
                        | "circle"
                        | "square"
                        | "arrowUp"
                        | "arrowDown"),
                color: p.color,
                text: output.text + (p.closed ? "" : " · provisional"),
                size: output.kind === "plotchar" ? 0 : 1,
              })),
          ),
        );
    }
    if (!scriptResult.overlay) api.panes()[pane]?.setHeight(180);
  }, [scriptResult, indicators, chartType, volume]);
  useEffect(() => {
    if (fitToken) chart.current?.timeScale().fitContent();
  }, [fitToken]);
  const bar = hover ?? candles.at(-1);
  const fmt = (x: number) =>
    x.toLocaleString("en-US", { maximumFractionDigits: 8 });
  return (
    <div className="chart-wrapper">
      <div className="ohlc">
        {bar ? (
          <>
            <span>
              {new Date(bar.time * 1000).toLocaleString("es-MX", {
                timeZone: "UTC",
              })}{" "}
              UTC
            </span>
            {(["open", "high", "low", "close"] as const).map((key, i) => (
              <span key={key}>
                {["O", "H", "L", "C"][i]}{" "}
                <b className={bar.close >= bar.open ? "positive" : "negative"}>
                  {fmt(bar[key])}
                </b>
              </span>
            ))}
            <span>
              V <b>{fmt(bar.volume)}</b>
            </span>
            <span className="bar-state">
              {bar.closed ? "Cerrada" : "En formación"}
            </span>
          </>
        ) : (
          <span>Esperando velas del proveedor…</span>
        )}
      </div>
      <div className="chart-stage">
        <div className="chart-canvas" ref={container} />
        {drawingApi && structure && (
          <StructureLayer
            api={drawingApi.api}
            series={drawingApi.series}
            candles={candles}
            result={structure}
            config={structureConfig}
          />
        )}
        {drawingApi && (
          <DrawingLayer
            key={marketKey}
            api={drawingApi.api}
            series={drawingApi.series}
            candles={candles}
            drawings={drawings}
            tool={tool}
            onTool={onTool}
            onChange={onDrawingsChange}
            selected={selectedDrawing}
            onSelected={onSelectedDrawing}
          />
        )}
      </div>
    </div>
  );
}
export type ChartTime = Time;
