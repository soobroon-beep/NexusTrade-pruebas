// @vitest-environment jsdom
import { beforeEach, afterEach, it, expect, vi } from "vitest";
import {
  render,
  fireEvent,
  screen,
  waitFor,
  cleanup,
} from "@testing-library/react";
import { ScriptWorkbench } from "./ScriptWorkbench";
import { useScripts } from "../state/scripts";
import { requestWorker } from "../pine/client";
import { compile } from "../pine/compiler";
import { execute } from "../pine/runtime";
import type { Candle } from "../domain/types";
vi.mock("../pine/client", () => ({ requestWorker: vi.fn() }));
const candles: Candle[] = [
  {
    time: 60,
    open: 1,
    high: 3,
    low: 1,
    close: 2,
    volume: 3,
    closeTime: 119999,
    closed: true,
    source: "Binance Spot",
    receivedAt: 0,
  },
];
beforeEach(() => {
  useScripts.getState().setData({ version: 1, items: [], active: null });
  HTMLDialogElement.prototype.showModal = function () {
    this.setAttribute("open", "");
  };
  HTMLDialogElement.prototype.close = function () {
    this.removeAttribute("open");
  };
  vi.mocked(requestWorker).mockImplementation(async (r) => {
    const c = compile(r.source);
    return {
      id: r.id,
      ok: true,
      report: {
        title: c.title,
        overlay: c.overlay,
        version: c.program.version,
        inputs: c.inputs,
        plots: c.plots,
        warnings: c.warnings,
      },
      result: r.candles ? execute(c, r.candles, r.parameters) : undefined,
    };
  });
});
afterEach(() => {
  cleanup();
  vi.clearAllMocks();
});
it("mantiene la instantánea cuando llega una vela y permite añadir/retirar el script", async () => {
  const view = render(
    <ScriptWorkbench candles={candles} marketKey="BTC-1h" busy={false} />,
  );
  fireEvent.click(screen.getByText("〈/〉 Editor de scripts"));
  fireEvent.click(screen.getByText("Vista previa · 1 barras"));
  await waitFor(() =>
    expect(
      (screen.getByText("Añadir a la gráfica") as HTMLButtonElement).disabled,
    ).toBe(false),
  );
  view.rerender(
    <ScriptWorkbench
      candles={[{ ...candles[0], close: 2.5 }]}
      marketKey="BTC-1h"
      busy={false}
    />,
  );
  expect(
    (screen.getByText("Añadir a la gráfica") as HTMLButtonElement).disabled,
  ).toBe(false);
  fireEvent.click(screen.getByText("Añadir a la gráfica"));
  expect(useScripts.getState().data.active).toBe(
    useScripts.getState().data.items[0].id,
  );
  view.rerender(
    <ScriptWorkbench
      candles={candles}
      marketKey="BTC-1h"
      activeName="Test"
      busy={false}
    />,
  );
  fireEvent.click(screen.getByText("Retirar script"));
  expect(useScripts.getState().data.active).toBeNull();
});
it("importa texto sin ejecutarlo y conserva el original al editar y guardar", async () => {
  const view = render(
    <ScriptWorkbench candles={candles} marketKey="BTC-1h" busy={false} />,
  );
  fireEvent.click(screen.getByText("〈/〉 Editor de scripts"));
  const original = '//@version=6\nindicator("Importado")\nplot(close)';
  const file = new File([original], "importado.pine", { type: "text/plain" });
  Object.defineProperty(file, "text", { value: async () => original });
  fireEvent.change(view.container.querySelector("input[type=file]")!, {
    target: { files: [file] },
  });
  await waitFor(() =>
    expect(
      (screen.getByLabelText("Código Pine") as HTMLTextAreaElement).value,
    ).toBe(original),
  );
  expect(requestWorker).not.toHaveBeenCalled();
  fireEvent.change(screen.getByLabelText("Código Pine"), {
    target: { value: original.replace("plot(close)", "plot(open)") },
  });
  fireEvent.click(screen.getByText("Guardar *"));
  expect(useScripts.getState().data.items[0]).toMatchObject({
    original,
    source: original.replace("plot(close)", "plot(open)"),
  });
  expect(useScripts.getState().data.active).toBeNull();
});
