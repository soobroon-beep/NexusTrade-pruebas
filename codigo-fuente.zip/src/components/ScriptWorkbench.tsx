import { useEffect, useMemo, useRef, useState } from "react";
import type { Candle } from "../domain/types";
import { newId } from "../domain/id";
import { useScripts } from "../state/scripts";
import { scriptsSchema, type Script } from "../storage/scripts";
import { examples } from "../pine/examples";
import { completions, constants } from "../pine/compiler";
import { lex, type Value } from "../pine/language";
import { requestWorker } from "../pine/client";
import type { Report } from "../pine/protocol";
import type { Result } from "../pine/runtime";
const fresh = (source = examples[0].source, name = "Mi indicador"): Script => ({
  id: newId(),
  name,
  description: "",
  revision: 1,
  source,
  original: source,
  updatedAt: Date.now(),
  parameters: {},
});
function download(name: string, text: string) {
  const url = URL.createObjectURL(
    new Blob([text], { type: "text/plain;charset=utf-8" }),
  );
  const a = document.createElement("a");
  a.href = url;
  a.download = name;
  a.click();
  setTimeout(() => URL.revokeObjectURL(url), 500);
}
function Highlight({ source }: { source: string }) {
  const spans = useMemo(() => {
    try {
      const tokens = lex(source);
      let start = 0;
      return tokens.flatMap((t, i) => {
        const gap = source.slice(start, t.start);
        start = t.end;
        return [
          <span key={"g" + i}>{gap}</span>,
          <span key={i} className={"syntax-" + t.kind}>
            {source.slice(t.start, t.end)}
          </span>,
        ];
      });
    } catch {
      return source;
    }
  }, [source]);
  return (
    <>
      {spans}
      {"\n"}
    </>
  );
}
export function ScriptWorkbench({
  candles,
  marketKey,
  activeName,
  busy,
  error,
}: {
  candles: Candle[];
  marketKey: string;
  activeName?: string;
  busy: boolean;
  error?: string;
}) {
  const { data, setData, warning } = useScripts();
  const [open, setOpen] = useState(false),
    [draft, setDraft] = useState<Script>(() => data.items[0] ?? fresh()),
    [dirty, setDirty] = useState(false),
    [report, setReport] = useState<Report>(),
    [preview, setPreview] = useState<Result>(),
    [diagnostic, setDiagnostic] = useState<{
      message: string;
      line: number;
      column: number;
    }>(),
    [working, setWorking] = useState(false),
    [suggestions, setSuggestions] = useState<string[]>([]),
    [notice, setNotice] = useState("");
  const dialog = useRef<HTMLDialogElement>(null),
    editor = useRef<HTMLTextAreaElement>(null),
    highlight = useRef<HTMLPreElement>(null),
    gutter = useRef<HTMLPreElement>(null),
    request = useRef<AbortController | null>(null);
  const invalidate = () => {
    request.current?.abort();
    setWorking(false);
    setReport(undefined);
    setPreview(undefined);
    setDiagnostic(undefined);
  };
  useEffect(() => {
    if (open) dialog.current?.showModal();
    else {
      dialog.current?.close();
      request.current?.abort();
      setWorking(false);
    }
  }, [open]);
  useEffect(() => {
    request.current?.abort();
    setWorking(false);
    setPreview(undefined);
  }, [marketKey]);
  useEffect(() => () => request.current?.abort(), []);
  const change = (patch: Partial<Script>, sourceChanged = false) => {
    invalidate();
    setDraft((d) => ({
      ...d,
      ...patch,
      ...(sourceChanged ? { parameters: {} } : {}),
    }));
    setDirty(true);
    setNotice("");
  };
  const select = (s: Script) => {
    if (dirty && !confirm("Descartar los cambios sin guardar del editor?"))
      return;
    invalidate();
    setDraft(s);
    setDirty(false);
    setNotice("");
  };
  const save = (activate = false) => {
    const existing = data.items.find((x) => x.id === draft.id);
    if (!existing && data.items.length >= 30) {
      setNotice("Máximo 30 scripts.");
      return;
    }
    if (!draft.name.trim()) {
      setNotice("Escribe un nombre.");
      return;
    }
    const saved = {
      ...draft,
      name: draft.name.trim(),
      revision: existing ? existing.revision + (dirty ? 1 : 0) : 1,
      updatedAt: Date.now(),
    };
    const items = existing
      ? data.items.map((x) => (x.id === saved.id ? saved : x))
      : [...data.items, saved];
    setData({
      ...data,
      items,
      active: activate
        ? saved.id
        : data.active === saved.id && dirty
          ? null
          : data.active,
    });
    setDraft(saved);
    setDirty(false);
    setNotice(
      activate ? "Indicador añadido a la gráfica." : "Script guardado.",
    );
  };
  const validate = async (run: boolean) => {
    request.current?.abort();
    const controller = new AbortController();
    request.current = controller;
    setWorking(true);
    setDiagnostic(undefined);
    setPreview(undefined);
    try {
      const r = await requestWorker(
        {
          id: Date.now(),
          source: draft.source,
          parameters: draft.parameters,
          candles: run ? candles : undefined,
        },
        controller.signal,
      );
      if (controller.signal.aborted) return;
      if (r.ok) {
        setReport(r.report);
        setPreview(r.result);
      } else {
        setReport(undefined);
        setDiagnostic(r.error);
      }
    } catch (e) {
      if (!controller.signal.aborted)
        setDiagnostic({
          message: e instanceof Error ? e.message : "Error desconocido",
          line: 1,
          column: 1,
        });
    } finally {
      if (!controller.signal.aborted) setWorking(false);
    }
  };
  const setParameter = (id: string, value: Value) => {
    request.current?.abort();
    setWorking(false);
    setPreview(undefined);
    setDiagnostic(undefined);
    setDraft((d) => ({ ...d, parameters: { ...d.parameters, [id]: value } }));
    setDirty(true);
  };
  const importFile = async (file?: File) => {
    if (!file) return;
    try {
      if (file.size > 4_000_000)
        throw new Error("Archivo demasiado grande (máximo 4 MB).");
      const text = await file.text();
      if (file.name.endsWith(".json")) {
        const parsed = scriptsSchema.parse(JSON.parse(text));
        if (
          confirm(
            "Sustituir la colección de scripts? Se importarán desactivados.",
          )
        ) {
          setData({ ...parsed, active: null });
          select(parsed.items[0] ?? fresh());
        }
      } else {
        if (file.size > 64000) throw new Error("El script supera 64 KB.");
        select(fresh(text, file.name.replace(/\.[^.]+$/, "").slice(0, 80)));
        setDirty(true);
      }
    } catch (e) {
      setNotice(e instanceof Error ? e.message : "Archivo inválido.");
    }
  };
  const complete = (value: string) => {
    const el = editor.current;
    if (!el) return;
    const end = el.selectionStart,
      start = draft.source.slice(0, end).search(/[\w.]*$/);
    const source =
      draft.source.slice(0, start) +
      value +
      draft.source.slice(el.selectionEnd);
    change({ source }, true);
    setSuggestions([]);
    requestAnimationFrame(() => {
      el.focus();
      el.setSelectionRange(start + value.length, start + value.length);
    });
  };
  return (
    <>
      <div className="script-toolbar">
        <button onClick={() => setOpen(true)}>〈/〉 Editor de scripts</button>
        <span>
          {activeName
            ? `${activeName} · ${!candles.length ? "Esperando datos" : busy ? "Calculando…" : error ? "Error de ejecución" : "Activo"}`
            : "Pine v5/v6 · subconjunto documentado"}
        </span>
        {activeName && (
          <button onClick={() => setData({ ...data, active: null })}>
            Retirar script
          </button>
        )}
        {error && (
          <span className="negative" role="alert">
            {error}
          </span>
        )}
        {warning && <span role="alert">{warning}</span>}
      </div>
      <dialog
        ref={dialog}
        className="script-dialog"
        onCancel={() => setOpen(false)}
        aria-labelledby="script-title"
      >
        <header>
          <div>
            <h2 id="script-title">Editor de indicadores</h2>
            <p>
              Motor propio · Pine v5/v6 parcial · sin órdenes ni backtesting
            </p>
          </div>
          <button aria-label="Cerrar editor" onClick={() => setOpen(false)}>
            ×
          </button>
        </header>
        <div className="script-actions">
          <select
            aria-label="Scripts guardados"
            value={data.items.some((x) => x.id === draft.id) ? draft.id : ""}
            onChange={(e) => {
              const s = data.items.find((x) => x.id === e.target.value);
              if (s) select(s);
            }}
          >
            <option value="" disabled>
              Script nuevo
            </option>
            {data.items.map((s) => (
              <option key={s.id} value={s.id}>
                {s.name} · v{s.revision}
              </option>
            ))}
          </select>
          <button onClick={() => select(fresh())}>Nuevo</button>
          <button
            onClick={() => {
              select({
                ...draft,
                id: newId(),
                name: (draft.name + " copia").slice(0, 80),
                revision: 1,
              });
              setDirty(true);
            }}
          >
            Duplicar
          </button>
          <label className="file-button">
            Importar
            <input
              type="file"
              accept=".pine,.txt,.json"
              onChange={(e) => {
                void importFile(e.target.files?.[0]);
                e.target.value = "";
              }}
            />
          </label>
          <button onClick={() => download(draft.name + ".pine", draft.source)}>
            Exportar código
          </button>
          <button
            onClick={() =>
              download(draft.name + "-original.pine", draft.original)
            }
          >
            Exportar original
          </button>
          <button
            onClick={() =>
              download("scripts-terminal.json", JSON.stringify(data, null, 2))
            }
          >
            Exportar colección
          </button>
          <button
            disabled={!data.items.some((x) => x.id === draft.id)}
            onClick={() => {
              if (confirm("Eliminar este script guardado?")) {
                setData({
                  ...data,
                  items: data.items.filter((x) => x.id !== draft.id),
                  active: data.active === draft.id ? null : data.active,
                });
                invalidate();
                setDraft(fresh());
                setDirty(false);
              }
            }}
          >
            Eliminar
          </button>
        </div>
        <div className="script-meta">
          <label>
            Nombre
            <input
              maxLength={80}
              value={draft.name}
              onChange={(e) => change({ name: e.target.value })}
            />
          </label>
          <label>
            Descripción
            <input
              maxLength={1000}
              value={draft.description}
              onChange={(e) => change({ description: e.target.value })}
            />
          </label>
          <label>
            Ejemplos
            <select
              defaultValue=""
              onChange={(e) => {
                const s = examples[Number(e.target.value)];
                if (s) select(fresh(s.source, s.name));
                e.target.value = "";
              }}
            >
              <option value="" disabled>
                Elegir ejemplo…
              </option>
              {examples.map((x, i) => (
                <option key={x.name} value={i}>
                  {x.name}
                </option>
              ))}
            </select>
          </label>
        </div>
        <div className="code-editor">
          <pre ref={gutter} className="line-numbers" aria-hidden="true">
            {draft.source
              .split("\n")
              .map((_, i) => i + 1)
              .join("\n")}
          </pre>
          <div className="code-stack">
            <pre ref={highlight} aria-hidden="true">
              <Highlight source={draft.source} />
            </pre>
            <textarea
              ref={editor}
              aria-label="Código Pine"
              value={draft.source}
              spellCheck={false}
              wrap="off"
              maxLength={64000}
              onScroll={(e) => {
                if (highlight.current) {
                  highlight.current.scrollTop = e.currentTarget.scrollTop;
                  highlight.current.scrollLeft = e.currentTarget.scrollLeft;
                }
                if (gutter.current)
                  gutter.current.scrollTop = e.currentTarget.scrollTop;
              }}
              onChange={(e) => {
                change({ source: e.target.value }, true);
                setSuggestions([]);
              }}
              onKeyDown={(e) => {
                if ((e.ctrlKey || e.metaKey) && e.code === "Space") {
                  e.preventDefault();
                  const prefix =
                    draft.source
                      .slice(0, e.currentTarget.selectionStart)
                      .match(/[\w.]*$/)?.[0] ?? "";
                  setSuggestions(
                    [
                      ...completions,
                      ...Object.keys(constants),
                      "close",
                      "open",
                      "high",
                      "low",
                      "volume",
                      "time",
                      "bar_index",
                      "barstate.isconfirmed",
                    ]
                      .filter((s) => s.startsWith(prefix))
                      .slice(0, 12),
                  );
                }
                if (e.key === "Escape") setSuggestions([]);
              }}
            />
          </div>
        </div>
        {suggestions.length > 0 && (
          <div className="script-actions" aria-label="Sugerencias de código">
            {suggestions.map((s) => (
              <button key={s} onClick={() => complete(s)}>
                {s}
              </button>
            ))}
          </div>
        )}
        <div className="script-actions">
          <button onClick={() => save()}>Guardar{dirty ? " *" : ""}</button>
          <button disabled={working} onClick={() => void validate(false)}>
            Validar compatibilidad
          </button>
          <button
            disabled={working || !candles.length}
            onClick={() => void validate(true)}
          >
            Vista previa · {candles.length} barras
          </button>
          <button disabled={!preview || working} onClick={() => save(true)}>
            Añadir a la gráfica
          </button>
          {working && (
            <button
              onClick={() => {
                request.current?.abort();
                setWorking(false);
              }}
            >
              Cancelar cálculo
            </button>
          )}
          <small>
            Ctrl/Espacio: completar · {marketKey} ·{" "}
            {dirty ? "Cambios sin guardar" : `Revisión ${draft.revision}`}
          </small>
        </div>
        {notice && <p role="status">{notice}</p>}
        {diagnostic && (
          <p className="data-warning" role="alert">
            <button
              onClick={() => {
                const offset =
                  draft.source
                    .split("\n")
                    .slice(0, diagnostic.line - 1)
                    .reduce((n, s) => n + s.length + 1, 0) +
                  diagnostic.column -
                  1;
                editor.current?.focus();
                editor.current?.setSelectionRange(offset, offset + 1);
              }}
            >
              L{diagnostic.line}:{diagnostic.column}
            </button>{" "}
            {diagnostic.message}
          </p>
        )}
        {report && (
          <section className="compat-report">
            <h3>Compatible con el subconjunto · v{report.version}</h3>
            <p>
              {report.title} ·{" "}
              {report.overlay ? "Sobre precio" : "Panel independiente"} ·{" "}
              {report.plots.length} salidas
            </p>
            {report.warnings.map((w) => (
              <p key={w}>{w}</p>
            ))}
            <div className="script-inputs">
              {report.inputs.map((p) => (
                <label key={p.id}>
                  {p.title}
                  {p.kind === "bool" ? (
                    <input
                      type="checkbox"
                      checked={Boolean(draft.parameters[p.id] ?? p.value)}
                      onChange={(e) => setParameter(p.id, e.target.checked)}
                    />
                  ) : (
                    <input
                      type={p.kind === "string" ? "text" : "number"}
                      min={p.min}
                      max={p.max}
                      step={p.step ?? (p.kind === "int" ? 1 : "any")}
                      value={String(draft.parameters[p.id] ?? p.value)}
                      onChange={(e) =>
                        setParameter(
                          p.id,
                          p.kind === "string"
                            ? e.target.value
                            : e.target.value === ""
                              ? null
                              : Number(e.target.value),
                        )
                      }
                    />
                  )}
                </label>
              ))}
            </div>
          </section>
        )}
        {preview && (
          <section className="compat-report">
            <h3>Vista previa calculada · instantánea</h3>
            <p>
              {preview.bars} barras · {preview.operations.toLocaleString()}{" "}
              operaciones · última barra{" "}
              {preview.lastClosed ? "cerrada" : "provisional"}. Las formas
              muestran el precio de su ancla.
            </p>
            <div className="script-table">
              <table>
                <thead>
                  <tr>
                    <th>Salida</th>
                    {(preview.plots[0]?.points ?? []).slice(-3).map((c) => (
                      <th key={c.time}>
                        {new Date(c.time * 1000).toISOString().slice(5, 16)} UTC
                      </th>
                    ))}
                  </tr>
                </thead>
                <tbody>
                  {preview.plots.map((p) => (
                    <tr key={p.id}>
                      <th>{p.title}</th>
                      {p.points.slice(-3).map((x) => (
                        <td key={x.time}>
                          {x.value === null
                            ? "na"
                            : x.value.toLocaleString("en-US", {
                                maximumFractionDigits: 8,
                              })}
                        </td>
                      ))}
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </section>
        )}
        <details>
          <summary>Construcciones admitidas y límites</summary>
          <p>
            indicator(), strategy() sólo análisis; plot(), hline(), plotshape(),
            plotchar(); input.int/float/bool/string; OHLCV, time, bar_index,
            barstate.isconfirmed; variables globales, var, :=, ?:, operadores y
            variable[n]; ta.sma/ema/rsi/atr/macd/crossover/crossunder; na() y
            nz().
          </p>
          <p>
            No disponibles: bloques if, funciones del usuario, bucles, arrays,
            objetos, request.security, bgcolor, fill, órdenes y alertas. No se
            eliminan instrucciones para aceptar un script. Un script activo, 30
            guardados, 16 salidas; 64 KB, 800 nodos, profundidad 48, 10.000
            barras, 2 millones de celdas/operaciones, 3 segundos por ejecución.
          </p>
          <p>
            La colección de scripts se exporta por separado de las plantillas de
            las fases anteriores. El original importado se conserva; los
            cálculos se reconstruyen sobre el histórico cargado en cada
            actualización, sin estado intrabar persistente.
          </p>
        </details>
      </dialog>
    </>
  );
}
