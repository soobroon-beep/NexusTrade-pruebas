import { timeIndex } from "../domain/chartTime";
export { timeIndex } from "../domain/chartTime";
import { newId } from "../domain/id";
import {
  useEffect,
  useRef,
  useState,
  type PointerEvent as ReactPointerEvent,
} from "react";
import type { IChartApi, ISeriesApi, Logical } from "lightweight-charts";
import type { Candle } from "../domain/types";
import {
  fibLevels,
  moveDrawing,
  pointCount,
  positionMetrics,
  type Drawing,
  type DrawingTool,
  type Point,
} from "../drawings/model";
export type PriceSeries = ISeriesApi<"Candlestick" | "Bar" | "Line" | "Area">;
type Screen = { x: number; y: number };
export function DrawingLayer({
  api,
  series,
  candles,
  drawings,
  tool,
  onTool,
  onChange,
  selected,
  onSelected,
}: {
  api: IChartApi;
  series: PriceSeries;
  candles: Candle[];
  drawings: Drawing[];
  tool: DrawingTool | null;
  onTool: (t: DrawingTool | null) => void;
  onChange: (items: Drawing[]) => void;
  selected: string | null;
  onSelected: (s: string | null) => void;
}) {
  const svg = useRef<SVGSVGElement>(null);
  const [view, setView] = useState<{
    w: number;
    h: number;
    points: Record<string, Screen[]>;
  }>({ w: 0, h: 0, points: {} });
  const [pending, setPending] = useState<Point[]>([]);
  const [preview, setPreview] = useState<Drawing | null>(null);
  const drag = useRef<{
    drawing: Drawing;
    start: Point;
    anchor: number | null;
  } | null>(null);
  const livePreview = useRef<Drawing | null>(null);
  const frameData = useRef({ drawings, preview, pending, candles });
  frameData.current = { drawings, preview, pending, candles };
  useEffect(() => {
    setPending([]);
    setPreview(null);
    livePreview.current = null;
    drag.current = null;
  }, [tool]);
  useEffect(() => {
    let stopped = false,
      frame = 0,
      last = "";
    const update = () => {
      if (stopped) return;
      try {
        const { drawings, preview, pending, candles } = frameData.current;
        const w = api.timeScale().width(),
          h = api.panes()[0]?.getHeight() ?? 0;
        const points: Record<string, Screen[]> = {};
        const project = (p: Point) => ({
          x:
            api
              .timeScale()
              .logicalToCoordinate(timeIndex(p.time, candles) as Logical) ??
            -10000,
          y: series.priceToCoordinate(p.price) ?? -10000,
        });
        if (candles.length) {
          for (const d of drawings)
            if (d.visible)
              points[d.id] = (preview?.id === d.id ? preview : d).points.map(
                project,
              );
          points.pending = pending.map(project);
        }
        const signature = JSON.stringify({ w, h, points });
        if (signature !== last) {
          last = signature;
          setView({ w, h, points });
        }
      } catch {
        /* Chart recreation can invalidate an old frame. */
      }
      frame = requestAnimationFrame(update);
    };
    frame = requestAnimationFrame(update);
    return () => {
      stopped = true;
      cancelAnimationFrame(frame);
    };
  }, [api, series]);
  const domain = (e: ReactPointerEvent): Point | null => {
    if (!svg.current || !candles.length) return null;
    const rect = svg.current.getBoundingClientRect();
    const x = e.clientX - rect.left,
      y = e.clientY - rect.top;
    if (x < 0 || x > view.w || y < 0 || y > view.h) return null;
    const logical = api.timeScale().coordinateToLogical(x);
    const index = logical === null ? -1 : Math.round(logical);
    if (index < 0 || index >= candles.length) return null;
    const price = series.coordinateToPrice(y);
    return price === null ? null : { time: candles[index].time, price };
  };
  const begin = (e: ReactPointerEvent, d: Drawing, anchor: number | null) => {
    if (tool) return;
    e.stopPropagation();
    onSelected(d.id);
    if (d.locked) return;
    const start = domain(e);
    if (!start) return;
    drag.current = { drawing: d, start, anchor };
    svg.current?.setPointerCapture(e.pointerId);
  };
  const end = () => {
    if (drag.current && livePreview.current) {
      onChange(
        drawings.map((d) =>
          d.id === livePreview.current!.id ? livePreview.current! : d,
        ),
      );
    }
    drag.current = null;
    livePreview.current = null;
    setPreview(null);
  };
  const create = (e: ReactPointerEvent) => {
    if (!tool) {
      if (e.target === svg.current) onSelected(null);
      return;
    }
    const p = domain(e);
    if (!p || drawings.length >= 100) return;
    const points = [...pending, p];
    if (points.length < pointCount(tool)) {
      setPending(points);
      return;
    }
    let text = "";
    if (tool === "text") {
      const answer = prompt("Texto de la etiqueta", "Nivel");
      if (answer === null) {
        setPending([]);
        onTool(null);
        return;
      }
      text = answer.slice(0, 100);
    }
    const drawing: Drawing = {
      id: newId(),
      tool,
      points,
      color: "#8fdcc8",
      width: 2,
      dash: false,
      extend: false,
      text,
      visible: true,
      locked: false,
    };
    onChange([...drawings, drawing]);
    onSelected(drawing.id);
    setPending([]);
    onTool(null);
  };
  return (
    <svg
      ref={svg}
      className={"drawing-layer " + (tool ? "drawing-active" : "")}
      width={view.w}
      height={view.h}
      style={{ touchAction: tool || selected ? "none" : "auto" }}
      onPointerDown={create}
      onPointerMove={(e) => {
        const active = drag.current;
        if (!active) return;
        const p = domain(e);
        if (!p) return;
        let next: Drawing;
        if (active.anchor === null)
          next = moveDrawing(
            active.drawing,
            p.time - active.start.time,
            p.price - active.start.price,
          );
        else
          next = {
            ...active.drawing,
            points: active.drawing.points.map((old, i) =>
              i === active.anchor ? p : old,
            ),
          };
        livePreview.current = next;
        setPreview(next);
      }}
      onPointerUp={end}
      onPointerCancel={() => {
        drag.current = null;
        livePreview.current = null;
        setPreview(null);
      }}
    >
      <defs>
        <marker
          id="drawing-arrow-head"
          markerWidth="8"
          markerHeight="8"
          refX="7"
          refY="4"
          orient="auto"
        >
          <path d="M0,0 L8,4 L0,8 Z" fill="context-stroke" />
        </marker>
      </defs>
      {drawings
        .filter((d) => d.visible && view.points[d.id])
        .map((original) => {
          const d = preview?.id === original.id ? preview : original;
          const points = view.points[d.id];
          return (
            <g
              key={d.id}
              className={
                "drawing-object " +
                (selected === d.id ? "drawing-selected" : "")
              }
              stroke={d.color}
              strokeWidth={d.width}
              strokeDasharray={d.dash ? "6 4" : undefined}
              fill="none"
              style={{
                pointerEvents: tool ? "none" : "visiblePainted",
                cursor: d.locked ? "default" : "move",
              }}
              onPointerDown={(e) => begin(e, d, null)}
              onDoubleClick={() => onSelected(d.id)}
            >
              <DrawingShape
                drawing={d}
                points={points}
                w={view.w}
                h={view.h}
                candles={candles}
                priceToY={(p) => series.priceToCoordinate(p) ?? -10000}
              />
              {selected === d.id &&
                !d.locked &&
                points.map((p, i) => (
                  <circle
                    key={i}
                    cx={p.x}
                    cy={p.y}
                    r="5"
                    fill="#0c121b"
                    stroke="#ffffff"
                    strokeDasharray="none"
                    strokeWidth="1.5"
                    onPointerDown={(e) => begin(e, d, i)}
                  />
                ))}
            </g>
          );
        })}
      {view.points.pending?.map((p, i) => (
        <circle key={i} cx={p.x} cy={p.y} r="4" fill="#9ef1d8" />
      ))}
    </svg>
  );
}
function DrawingShape({
  drawing: d,
  points,
  w,
  h,
  candles,
  priceToY,
}: {
  drawing: Drawing;
  points: Screen[];
  w: number;
  h: number;
  candles: Candle[];
  priceToY: (p: number) => number;
}) {
  const a = points[0],
    b = points[1] ?? a,
    c = points[2] ?? b;
  const fmt = (n: number) =>
    n.toLocaleString("en-US", { maximumFractionDigits: 6 });
  const line = (p: Screen, q: Screen, key?: string) => (
    <line
      key={key}
      x1={p.x}
      y1={p.y}
      x2={q.x}
      y2={q.y}
      vectorEffect="non-scaling-stroke"
    />
  );
  const label = (text: string, x = a.x + 7, y = a.y - 8, key?: string) => (
    <text
      key={key}
      className="drawing-label"
      x={x}
      y={y}
      fill={d.color}
      stroke="#0b121b"
      strokeWidth="3"
      strokeDasharray="none"
      paintOrder="stroke"
      fontSize="11"
    >
      {text}
    </text>
  );
  const x1 = Math.min(a.x, b.x),
    x2 = Math.max(a.x, b.x),
    y1 = Math.min(a.y, b.y),
    y2 = Math.max(a.y, b.y);
  switch (d.tool) {
    case "horizontal":
      return (
        <>
          {line({ x: 0, y: a.y }, { x: w, y: a.y })}
          {label(`${d.text || "Nivel"} ${fmt(d.points[0].price)}`, 8, a.y - 6)}
        </>
      );
    case "vertical":
      return (
        <>
          {line({ x: a.x, y: 0 }, { x: a.x, y: h })}
          {label(
            d.text ||
              new Date(d.points[0].time * 1000).toISOString().slice(5, 16),
            a.x + 6,
            17,
          )}
        </>
      );
    case "text":
      return label(d.text || "Texto", a.x, a.y);
    case "rectangle":
      return (
        <>
          <rect
            x={x1}
            y={y1}
            width={Math.max(1, x2 - x1)}
            height={Math.max(1, y2 - y1)}
            fill={d.color + "14"}
          />
          {d.text && label(d.text, x1 + 6, y1 - 6)}
        </>
      );
    case "arrow":
      return (
        <>
          <line
            x1={a.x}
            y1={a.y}
            x2={b.x}
            y2={b.y}
            markerEnd="url(#drawing-arrow-head)"
          />
          {d.text && label(d.text)}
        </>
      );
    case "trend":
    case "ray": {
      if (Math.abs(b.x - a.x) < 0.001)
        return (
          <>
            {line(
              d.extend ? { x: a.x, y: 0 } : a,
              d.extend || d.tool === "ray"
                ? { x: a.x, y: b.y >= a.y ? h : 0 }
                : b,
            )}
            {d.text && label(d.text)}
          </>
        );
      const slope = (b.y - a.y) / (b.x - a.x || 0.00001);
      const start =
        d.extend && d.tool === "trend" ? { x: 0, y: a.y - slope * a.x } : a;
      const end =
        d.tool === "ray" || d.extend
          ? {
              x: b.x >= a.x ? w : 0,
              y: a.y + slope * ((b.x >= a.x ? w : 0) - a.x),
            }
          : b;
      return (
        <>
          {line(start, end)}
          {d.text && label(d.text)}
        </>
      );
    }
    case "channel": {
      if (Math.abs(b.x - a.x) < 0.001)
        return (
          <>
            {line(a, b)}
            {line({ x: c.x, y: a.y }, { x: c.x, y: b.y })}
            <polygon
              points={`${a.x},${a.y} ${b.x},${b.y} ${c.x},${b.y} ${c.x},${a.y}`}
              fill={d.color + "13"}
            />
          </>
        );
      const dy =
        c.y - (a.y + ((b.y - a.y) * (c.x - a.x)) / (b.x - a.x || 0.00001));
      return (
        <>
          <polygon
            points={`${a.x},${a.y} ${b.x},${b.y} ${b.x},${b.y + dy} ${a.x},${a.y + dy}`}
            fill={d.color + "13"}
          />
          {line(a, b)}
          {line({ x: a.x, y: a.y + dy }, { x: b.x, y: b.y + dy })}
          {d.text && label(d.text)}
        </>
      );
    }
    case "measure": {
      const delta = d.points[1].price - d.points[0].price;
      return (
        <>
          {line(a, b)}
          <rect
            x={x1}
            y={y1}
            width={Math.max(1, x2 - x1)}
            height={Math.max(1, y2 - y1)}
            fill={d.color + "13"}
          />
          {label(
            `${fmt(delta)} · ${d.points[0].price ? ((delta / d.points[0].price) * 100).toFixed(2) + "%" : "% no disponible"} · ${Math.abs(Math.round((d.points[1].time - d.points[0].time) / 60))} min`,
            x1 + 4,
            y1 - 8,
          )}
        </>
      );
    }
    case "fib":
    case "extension": {
      const levels =
        d.tool === "fib"
          ? fibLevels(d.points[0].price, d.points[1].price)
          : fibLevels(
              d.points[2].price,
              d.points[2].price + d.points[1].price - d.points[0].price,
              true,
            );
      return (
        <>
          {levels.map((l) => {
            const y = priceToY(l.price);
            return (
              <g key={l.ratio}>
                {line(
                  { x: x1, y },
                  { x: d.extend ? w : Math.max(x2, x1 + 50), y },
                )}
                {label(`${l.ratio} · ${fmt(l.price)}`, x1 + 5, y - 4)}
              </g>
            );
          })}
          {d.tool === "extension" && (
            <>
              {line(a, b)}
              {line(b, c)}
            </>
          )}
        </>
      );
    }
    case "extrema": {
      const bars = candles.filter(
        (bar) =>
          bar.time >= Math.min(d.points[0].time, d.points[1].time) &&
          bar.time <= Math.max(d.points[0].time, d.points[1].time),
      );
      if (!bars.length) return label("Sin datos en el rango");
      const hi = Math.max(...bars.map((c) => c.high)),
        lo = Math.min(...bars.map((c) => c.low));
      return (
        <>
          {[hi, lo].map((p, i) => (
            <g key={i}>
              {line({ x: x1, y: priceToY(p) }, { x: x2, y: priceToY(p) })}
              {label(`${i ? "Mín" : "Máx"} ${fmt(p)}`, x1 + 5, priceToY(p) - 5)}
            </g>
          ))}
        </>
      );
    }
    case "long":
    case "short": {
      const metrics = positionMetrics(d);
      const right = Math.max(a.x + 70, b.x, c.x);
      return (
        <>
          <rect
            x={a.x}
            y={Math.min(a.y, b.y)}
            width={Math.max(1, right - a.x)}
            height={Math.abs(b.y - a.y)}
            fill="#f0758330"
            stroke="#f07583"
          />
          <rect
            x={a.x}
            y={Math.min(a.y, c.y)}
            width={Math.max(1, right - a.x)}
            height={Math.abs(c.y - a.y)}
            fill="#46d5ae30"
            stroke="#46d5ae"
          />
          {line(a, { x: right, y: a.y })}
          {label(`Entrada ${fmt(d.points[0].price)}`, a.x + 5, a.y - 5)}
          {label(`Stop ${fmt(d.points[1].price)}`, a.x + 5, b.y - 5)}
          {label(
            `Objetivo ${fmt(d.points[2].price)} · ${metrics.ratio === null ? "Revisar stop/objetivo" : "R:R " + metrics.ratio.toFixed(2)}`,
            a.x + 5,
            c.y - 5,
          )}
        </>
      );
    }
  }
}
