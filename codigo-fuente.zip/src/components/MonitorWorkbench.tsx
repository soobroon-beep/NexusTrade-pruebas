import { useEffect, useRef, useState } from "react";
import { newId } from "../domain/id";
import type { Candle, Interval } from "../domain/types";
import type { IndicatorConfig } from "../indicators/registry";
import { registry } from "../indicators/registry";
import type { Drawing } from "../drawings/model";
import type { Script } from "../storage/scripts";
import type { Result } from "../pine/runtime";
import {
  conditionNames,
  comparisons,
  ruleSchema,
  type AlertRule,
  type Condition,
  type Comparison,
} from "../alerts/model";
import { evaluateRule } from "../alerts/engine";
import { useMonitor } from "../state/monitor";
import { monitorSchema } from "../storage/monitor";
import {
  structureConfigSchema,
  type StructureResult,
} from "../structure/engine";
import { useLevels, priorLevels } from "../market/useLevels";
const fmt = (n: number | undefined) =>
  n === undefined
    ? "—"
    : n.toLocaleString("en-US", { maximumFractionDigits: 8 });
const utc = (n: number) =>
  new Date(n).toISOString().replace("T", " ").slice(0, 19) + " UTC";
function download(text: string) {
  const url = URL.createObjectURL(
    new Blob([text], { type: "application/json" }),
  );
  const a = document.createElement("a");
  a.href = url;
  a.download = "monitor-terminal.json";
  a.click();
  setTimeout(() => URL.revokeObjectURL(url), 500);
}
type Context = {
  candles: Candle[];
  symbol: string;
  interval: Interval;
  indicators: IndicatorConfig[];
  drawings: Drawing[];
  script: { active?: Script; result?: Result; busy?: boolean };
};
function RuleEditor({
  context,
  rule,
  onSave,
  onCancel,
}: {
  context: Context;
  rule?: AlertRule;
  onSave: (rule: AlertRule) => void;
  onCancel: () => void;
}) {
  const [kind, setKind] = useState<Condition["kind"]>(
      rule?.condition.kind ?? "price",
    ),
    [source, setSource] = useState(rule ? "snapshot" : ""),
    [comparison, setComparison] = useState<Comparison>(
      "comparison" in (rule?.condition ?? {})
        ? (rule!.condition as Condition & { comparison: Comparison }).comparison
        : "above",
    ),
    [output, setOutput] = useState(
      "output" in (rule?.condition ?? {})
        ? String((rule!.condition as Condition & { output: number }).output)
        : "0",
    ),
    [scriptMode, setScriptMode] = useState<"threshold" | "present">(
      rule?.condition.kind === "script" ? rule.condition.mode : "threshold",
    ),
    [direction, setDirection] = useState<"up" | "down">(
      rule?.condition.kind === "cross" ? rule.condition.direction : "up",
    ),
    [error, setError] = useState(""),
    [check, setCheck] = useState("");
  const initialThreshold =
    rule && "threshold" in rule.condition
      ? rule.condition.threshold
      : (context.candles.at(-1)?.close ?? 0);
  const chosenIndicator =
    source === "snapshot" &&
    rule &&
    (rule.condition.kind === "indicator" || rule.condition.kind === "cross")
      ? rule.condition.config
      : context.indicators.find((x) => x.id === source);
  const chosenDrawing =
    source === "snapshot" && rule?.condition.kind === "drawing"
      ? rule.condition.drawing
      : context.drawings.find((x) => x.id === source);
  const chosenScript =
    source === "snapshot" && rule?.condition.kind === "script"
      ? rule.condition.script
      : source === "active"
        ? context.script.active
        : undefined;
  const build = (form: HTMLFormElement): AlertRule => {
    const data = new FormData(form),
      threshold = Number(data.get("threshold")),
      now = Date.now();
    let condition: Condition;
    if (kind === "price" || kind === "percent")
      condition = { kind, comparison, threshold };
    else if (kind === "indicator") {
      if (!chosenIndicator)
        throw new Error("Selecciona un indicador añadido al espacio.");
      condition = {
        kind,
        comparison,
        threshold,
        config: chosenIndicator,
        output: Number(output),
      };
    } else if (kind === "cross") {
      if (!chosenIndicator)
        throw new Error("Añade y selecciona un indicador Cruces de medias.");
      condition = { kind, config: chosenIndicator, direction };
    } else if (kind === "drawing") {
      if (!chosenDrawing) throw new Error("Selecciona un dibujo compatible.");
      condition = {
        kind,
        drawing: chosenDrawing,
        comparison: comparison === "cross_down" ? "cross_down" : "cross_up",
      };
    } else {
      if (!chosenScript)
        throw new Error(
          "Activa un script validado antes de crear esta alerta.",
        );
      condition = {
        kind,
        script: chosenScript,
        mode: scriptMode,
        comparison,
        threshold,
        output: Number(output),
      };
    }
    const expiresAt = new Date(String(data.get("expires")) + "Z").getTime();
    if (!Number.isFinite(expiresAt) || expiresAt <= now)
      throw new Error("La expiración debe estar en el futuro.");
    return ruleSchema.parse({
      id: rule?.id ?? newId(),
      name: String(data.get("name")).trim(),
      symbol: rule?.symbol ?? context.symbol,
      interval: rule?.interval ?? context.interval,
      condition,
      frequency: data.get("frequency"),
      createdAt: rule?.createdAt ?? now,
      updatedAt: now,
      expiresAt,
      status: "armed",
    });
  };
  const form = useRef<HTMLFormElement>(null);
  return (
    <form
      ref={form}
      className="rule-form"
      onSubmit={(e) => {
        e.preventDefault();
        try {
          onSave(build(e.currentTarget));
        } catch (e) {
          setError(e instanceof Error ? e.message : "Regla inválida.");
        }
      }}
    >
      <h3>
        {rule ? "Editar" : "Nueva"} alerta · {rule?.symbol ?? context.symbol} ·{" "}
        {rule?.interval ?? context.interval}
      </h3>
      <div className="monitor-fields">
        <label>
          Nombre
          <input
            name="name"
            required
            maxLength={80}
            defaultValue={rule?.name ?? ""}
            placeholder="Ej. BTC rompe resistencia"
          />
        </label>
        <label>
          Condición
          <select
            value={kind}
            onChange={(e) => {
              const kind = e.target.value as Condition["kind"];
              setKind(kind);
              setSource("");
              setOutput("0");
              setCheck("");
              if (kind === "drawing") setComparison("cross_up");
            }}
          >
            {Object.entries(conditionNames).map(([k, v]) => (
              <option key={k} value={k}>
                {v}
              </option>
            ))}
          </select>
        </label>
        {(kind === "indicator" || kind === "cross") && (
          <label>
            Indicador · copia de parámetros
            <select
              value={source}
              onChange={(e) => {
                setSource(e.target.value);
                setOutput("0");
              }}
            >
              <option value="">Seleccionar…</option>
              {rule &&
                (rule.condition.kind === "indicator" ||
                  rule.condition.kind === "cross") && (
                  <option value="snapshot">
                    Configuración guardada en esta alerta
                  </option>
                )}
              {context.indicators
                .filter((i) => kind !== "cross" || i.kind === "cross")
                .map((i) => (
                  <option key={i.id} value={i.id}>
                    {registry[i.kind].name} · {i.params.period} /{" "}
                    {i.params.fast} / {i.params.slow}
                  </option>
                ))}
            </select>
          </label>
        )}
        {kind === "indicator" && chosenIndicator && (
          <label>
            Salida
            <select value={output} onChange={(e) => setOutput(e.target.value)}>
              {registry[chosenIndicator.kind].outputs.map((o, i) => (
                <option key={i} value={i}>
                  {o.name}
                </option>
              ))}
            </select>
          </label>
        )}
        {kind === "cross" && (
          <label>
            Dirección
            <select
              value={direction}
              onChange={(e) => setDirection(e.target.value as "up" | "down")}
            >
              <option value="up">Rápida cruza sobre lenta</option>
              <option value="down">Rápida cruza bajo lenta</option>
            </select>
          </label>
        )}
        {kind === "drawing" && (
          <label>
            Dibujo · copia de coordenadas
            <select value={source} onChange={(e) => setSource(e.target.value)}>
              <option value="">Seleccionar…</option>
              {rule?.condition.kind === "drawing" && (
                <option value="snapshot">Dibujo guardado en esta alerta</option>
              )}
              {context.drawings
                .filter((d) => ["horizontal", "trend", "ray"].includes(d.tool))
                .map((d) => (
                  <option key={d.id} value={d.id}>
                    {d.tool} · {d.text || fmt(d.points[0].price)}
                  </option>
                ))}
            </select>
          </label>
        )}
        {kind === "script" && (
          <>
            <label>
              Script
              <select
                value={source}
                onChange={(e) => {
                  setSource(e.target.value);
                  setOutput(String(context.script.result?.plots[0]?.id ?? 0));
                }}
              >
                <option value="">Seleccionar…</option>
                {rule?.condition.kind === "script" && (
                  <option value="snapshot">
                    Fuente guardada en esta alerta
                  </option>
                )}
                {context.script.active && (
                  <option value="active">
                    Activo: {context.script.active.name}
                  </option>
                )}
              </select>
            </label>
            <label>
              Salida
              <select
                value={output}
                onChange={(e) => setOutput(e.target.value)}
              >
                <option value="0">Seleccionar…</option>
                {source === "snapshot" && rule?.condition.kind === "script" ? (
                  <option value={rule.condition.output}>
                    Salida #{rule.condition.output} guardada
                  </option>
                ) : (
                  context.script.result?.plots.map((p) => (
                    <option key={p.id} value={p.id}>
                      {p.title} · {p.kind}
                    </option>
                  ))
                )}
              </select>
            </label>
            <label>
              Modo
              <select
                value={scriptMode}
                onChange={(e) =>
                  setScriptMode(e.target.value as "threshold" | "present")
                }
              >
                <option value="threshold">Comparar valor numérico</option>
                <option value="present">Salida presente (no na)</option>
              </select>
            </label>
          </>
        )}
        {kind !== "cross" &&
          !(kind === "script" && scriptMode === "present") && (
            <label>
              Comparación
              <select
                value={comparison}
                onChange={(e) => setComparison(e.target.value as Comparison)}
              >
                {Object.entries(comparisons)
                  .filter(([k]) => kind !== "drawing" || k.startsWith("cross_"))
                  .map(([k, v]) => (
                    <option key={k} value={k}>
                      {v}
                    </option>
                  ))}
              </select>
            </label>
          )}
        {kind !== "cross" &&
          kind !== "drawing" &&
          !(kind === "script" && scriptMode === "present") && (
            <label>
              Umbral {kind === "percent" ? "% (cierre / cierre anterior)" : ""}
              <input
                name="threshold"
                type="number"
                step="any"
                required
                defaultValue={initialThreshold}
              />
            </label>
          )}
        <label>
          Frecuencia
          <select name="frequency" defaultValue={rule?.frequency ?? "once"}>
            <option value="once">Una vez; después se desactiva</option>
            <option value="bar">Una vez por vela cerrada</option>
          </select>
        </label>
        <label>
          Expiración · UTC
          <input
            name="expires"
            type="datetime-local"
            required
            defaultValue={new Date(rule?.expiresAt ?? Date.now() + 86400000)
              .toISOString()
              .slice(0, 16)}
          />
        </label>
      </div>
      <p>
        Se evalúa al cierre desde la próxima vela, sólo en este mercado
        seleccionado y con conexión en vivo. Indicadores, dibujos y código se
        guardan como copias; editarlos fuera no cambia la regla.
      </p>
      <div className="monitor-actions">
        <button type="submit">Guardar y armar</button>
        <button
          type="button"
          onClick={() => {
            try {
              const r = build(form.current!);
              if (
                r.symbol !== context.symbol ||
                r.interval !== context.interval
              )
                throw new Error(
                  "Selecciona el mercado de la alerta para comprobarla.",
                );
              const e = evaluateRule(r, context.candles, context.script);
              setCheck(
                e.ready
                  ? `Comprobación histórica: ${e.match ? "cumplida" : "no cumplida"} · valor ${fmt(e.value)}. No genera una alerta.`
                  : e.reason,
              );
              setError("");
            } catch (e) {
              setError(e instanceof Error ? e.message : "Error");
            }
          }}
        >
          Comprobar último cierre
        </button>
        <button type="button" onClick={onCancel}>
          Cancelar
        </button>
      </div>
      {check && <p role="status">{check}</p>}
      {error && (
        <p className="negative" role="alert">
          {error}
        </p>
      )}
    </form>
  );
}
export function MonitorWorkbench({
  context,
  structure,
  messages,
  now,
  onSelect,
}: {
  context: Context;
  structure?: StructureResult;
  messages: Record<string, string>;
  now: number;
  onSelect: (symbol: string, interval: Interval) => void;
}) {
  const { data, setData, warning } = useMonitor();
  const [panel, setPanel] = useState<"alerts" | "structure" | "levels" | null>(
      null,
    ),
    [editor, setEditor] = useState<string | null>(null),
    [error, setError] = useState("");
  const dialog = useRef<HTMLDialogElement>(null);
  const unread = data.events.filter((e) => !e.read).length;
  const levels = useLevels(
    context.symbol,
    panel === "levels" && data.showLevels,
  );
  useEffect(() => {
    if (panel) dialog.current?.showModal();
    else dialog.current?.close();
  }, [panel]);
  const saveRule = (rule: AlertRule) => {
    if (!data.rules.some((r) => r.id === rule.id) && data.rules.length >= 40)
      throw new Error("Máximo 40 alertas.");
    setData({
      ...data,
      rules: data.rules.some((r) => r.id === rule.id)
        ? data.rules.map((r) => (r.id === rule.id ? rule : r))
        : [...data.rules, rule],
    });
    setEditor(null);
  };
  return (
    <>
      <div className="monitor-toolbar">
        <button onClick={() => setPanel("alerts")}>
          ♧ Alertas <b>{unread || data.rules.length}</b>
        </button>
        <button
          className={data.structure.enabled ? "active" : ""}
          onClick={() => setPanel("structure")}
        >
          Estructura {data.structure.enabled ? "ON" : "OFF"}
        </button>
        <button onClick={() => setPanel("levels")}>Niveles D / W</button>
        <span>
          Alertas locales · sólo mercado seleccionado · cierre de vela
        </span>
      </div>
      {unread > 0 && (
        <div className="alert-banner" role="status">
          <b>{data.events.find((e) => !e.read)?.name}</b>
          <span>{unread} alerta(s) sin leer</span>
          <button onClick={() => setPanel("alerts")}>Ver historial</button>
        </div>
      )}
      <dialog
        ref={dialog}
        className="monitor-dialog"
        aria-labelledby="monitor-title"
        onCancel={() => setPanel(null)}
      >
        <header>
          <div>
            <h2 id="monitor-title">
              {panel === "alerts"
                ? "Alertas e historial"
                : panel === "structure"
                  ? "Estructura de mercado"
                  : "Niveles de referencia"}
            </h2>
            <p>
              Binance Spot · {context.symbol} · {context.interval}
            </p>
          </div>
          <button aria-label="Cerrar monitor" onClick={() => setPanel(null)}>
            ×
          </button>
        </header>
        <nav className="monitor-actions" aria-label="Secciones del monitor">
          {(["alerts", "structure", "levels"] as const).map((p) => (
            <button
              key={p}
              className={panel === p ? "active" : ""}
              onClick={() => setPanel(p)}
            >
              {p === "alerts"
                ? "Alertas"
                : p === "structure"
                  ? "Estructura"
                  : "Niveles"}
            </button>
          ))}
        </nav>
        {(warning || error) && (
          <p role="alert" className="negative">
            {warning || error}
          </p>
        )}
        {panel === "alerts" && (
          <>
            <p className="monitor-notice">
              No hay servidor de alertas: la pestaña debe estar abierta, activa
              y con el símbolo/temporalidad de la regla seleccionado. El
              navegador puede suspender pestañas en segundo plano. No se
              recuperan alertas perdidas durante cierres o desconexiones.
            </p>
            <div className="monitor-actions">
              <button
                disabled={data.rules.length >= 40}
                onClick={() => setEditor("new")}
              >
                Nueva alerta
              </button>
              <button
                disabled={!unread}
                onClick={() =>
                  setData({
                    ...data,
                    events: data.events.map((e) => ({ ...e, read: true })),
                  })
                }
              >
                Marcar historial leído
              </button>
              <button onClick={() => download(JSON.stringify(data, null, 2))}>
                Exportar monitor
              </button>
              <label className="file-button">
                Importar monitor
                <input
                  type="file"
                  accept=".json"
                  onChange={async (e) => {
                    const file = e.target.files?.[0];
                    e.target.value = "";
                    if (!file) return;
                    try {
                      if (file.size > 4_000_000)
                        throw new Error("Máximo 4 MB.");
                      const parsed = monitorSchema.parse(
                        JSON.parse(await file.text()),
                      );
                      if (
                        confirm(
                          "Sustituir monitor? Las alertas importadas quedarán pausadas.",
                        )
                      ) {
                        setData({
                          ...parsed,
                          rules: parsed.rules.map((r) => ({
                            ...r,
                            status: "paused",
                            updatedAt: Date.now(),
                          })),
                        });
                        setEditor(null);
                        setError("");
                      }
                    } catch (e) {
                      setError(
                        e instanceof Error ? e.message : "Archivo inválido.",
                      );
                    }
                  }}
                />
              </label>
            </div>
            {editor && (
              <RuleEditor
                key={editor + context.symbol + context.interval}
                context={context}
                rule={data.rules.find((r) => r.id === editor)}
                onSave={saveRule}
                onCancel={() => setEditor(null)}
              />
            )}
            <div className="alert-rules">
              {!data.rules.length && (
                <p>
                  No hay alertas. Crea una regla; no se disparará con datos
                  anteriores a su activación.
                </p>
              )}
              {data.rules.map((r) => (
                <article key={r.id}>
                  <div>
                    <b>{r.name}</b>
                    <span>
                      {r.symbol} · {r.interval} ·{" "}
                      {conditionNames[r.condition.kind]}
                    </span>
                    <small>
                      {now >= r.expiresAt
                        ? "Expirada"
                        : r.status === "armed"
                          ? "Armada"
                          : r.status === "paused"
                            ? "Pausada"
                            : "Disparada"}{" "}
                      · hasta {utc(r.expiresAt)}
                    </small>
                    <p>{messages[r.id] ?? "Esperando evaluación."}</p>
                  </div>
                  <div className="monitor-actions">
                    <button
                      onClick={() => {
                        onSelect(r.symbol, r.interval);
                        setPanel(null);
                      }}
                    >
                      Ir al mercado
                    </button>
                    <button onClick={() => setEditor(r.id)}>Editar</button>
                    <button
                      disabled={now >= r.expiresAt}
                      onClick={() =>
                        setData({
                          ...data,
                          rules: data.rules.map((x) =>
                            x.id === r.id
                              ? {
                                  ...x,
                                  status:
                                    x.status === "armed" ? "paused" : "armed",
                                  updatedAt: Date.now(),
                                }
                              : x,
                          ),
                        })
                      }
                    >
                      {r.status === "armed" ? "Pausar" : "Armar"}
                    </button>
                    <button
                      onClick={() => {
                        if (
                          confirm(
                            "Eliminar esta regla? Su historial se conserva.",
                          )
                        )
                          setData({
                            ...data,
                            rules: data.rules.filter((x) => x.id !== r.id),
                          });
                      }}
                    >
                      Eliminar
                    </button>
                  </div>
                </article>
              ))}
            </div>
            <h3>Historial local · últimas 300 alertas</h3>
            <div className="monitor-table">
              <table>
                <thead>
                  <tr>
                    <th>Observada UTC</th>
                    <th>Regla</th>
                    <th>Mercado</th>
                    <th>Vela UTC</th>
                    <th>Valor</th>
                    <th>Referencia</th>
                    <th>Estado</th>
                  </tr>
                </thead>
                <tbody>
                  {data.events.map((e) => (
                    <tr key={e.id}>
                      <td>{utc(e.observedAt)}</td>
                      <td>{e.name}</td>
                      <td>
                        {e.symbol} {e.interval}
                      </td>
                      <td>{utc(e.time * 1000)}</td>
                      <td>{fmt(e.value)}</td>
                      <td>{e.reference === null ? "—" : fmt(e.reference)}</td>
                      <td>{e.read ? "Leída" : "Nueva"}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
              {!data.events.length && (
                <p>
                  Sin disparos. Las comprobaciones manuales no se registran como
                  alertas.
                </p>
              )}
            </div>
          </>
        )}
        {panel === "structure" && (
          <>
            <form
              key={JSON.stringify(data.structure)}
              onSubmit={(e) => {
                e.preventDefault();
                const fd = new FormData(e.currentTarget);
                try {
                  const c = structureConfigSchema.parse({
                    ...data.structure,
                    ...Object.fromEntries(
                      [
                        "enabled",
                        "swings",
                        "breaks",
                        "sweeps",
                        "fvg",
                        "blocks",
                        "session",
                      ].map((k) => [k, fd.get(k) === "on"]),
                    ),
                    ...Object.fromEntries(
                      [
                        "left",
                        "right",
                        "minGapPercent",
                        "blockLookback",
                        "sessionStart",
                        "sessionEnd",
                      ].map((k) => [k, Number(fd.get(k))]),
                    ),
                  });
                  setData({ ...data, structure: c });
                  setError("");
                } catch (e) {
                  setError(
                    e instanceof Error ? e.message : "Configuración inválida.",
                  );
                }
              }}
            >
              <div className="monitor-checks">
                {(
                  [
                    ["enabled", "Mostrar estructura"],
                    ["swings", "Swings y niveles"],
                    ["breaks", "Rupturas / BOS / CHoCH"],
                    ["sweeps", "Barridos de mecha"],
                    ["fvg", "FVG (3 velas)"],
                    ["blocks", "Bloque previo a ruptura"],
                    ["session", "Rango de sesión UTC"],
                  ] as const
                ).map(([k, label]) => (
                  <label key={k}>
                    <input
                      name={k}
                      type="checkbox"
                      defaultChecked={data.structure[k]}
                    />
                    {label}
                  </label>
                ))}
              </div>
              <div className="monitor-fields">
                {(
                  [
                    ["left", "Barras a la izquierda", 1, 20, 1],
                    ["right", "Barras de confirmación", 1, 20, 1],
                    ["minGapPercent", "FVG mínimo %", 0, 10, 0.01],
                    ["blockLookback", "Buscar bloque en n barras", 1, 100, 1],
                    ["sessionStart", "Inicio sesión UTC (hora)", 0, 23, 1],
                    ["sessionEnd", "Fin sesión UTC (hora)", 0, 23, 1],
                  ] as const
                ).map(([k, label, min, max, step]) => (
                  <label key={k}>
                    {label}
                    <input
                      name={k}
                      type="number"
                      required
                      min={min}
                      max={max}
                      step={step}
                      defaultValue={data.structure[k]}
                    />
                  </label>
                ))}
              </div>
              <button type="submit">Aplicar estructura</button>
            </form>
            <p className="monitor-notice">
              Sólo velas cerradas. Los swings se marcan en la barra de
              confirmación, no retrospectivamente en su origen. Las zonas son
              patrones definidos por reglas; no identifican actividad
              institucional ni garantizan una operación.
            </p>
            {structure ? (
              <>
                <div className="monitor-stats">
                  <span>
                    Orientación:{" "}
                    <b>
                      {structure.bias === 0
                        ? "Sin ruptura"
                        : structure.bias === 1
                          ? "Alcista"
                          : "Bajista"}
                    </b>
                  </span>
                  <span>
                    Soporte swing: <b>{fmt(structure.support)}</b>
                  </span>
                  <span>
                    Resistencia swing: <b>{fmt(structure.resistance)}</b>
                  </span>
                  <span>
                    {structure.bars} cierres
                    {structure.truncated ? " · últimos 2.000" : ""} ·{" "}
                    {structure.gaps} huecos
                  </span>
                </div>
                <h3>Eventos confirmados · últimos 30</h3>
                <div className="monitor-table">
                  <table>
                    <thead>
                      <tr>
                        <th>Confirmación UTC</th>
                        <th>Origen UTC</th>
                        <th>Tipo</th>
                        <th>Nivel</th>
                        <th>Criterio</th>
                      </tr>
                    </thead>
                    <tbody>
                      {structure.events
                        .slice(-30)
                        .reverse()
                        .map((e) => (
                          <tr key={e.id}>
                            <td>{utc(e.time * 1000)}</td>
                            <td>{utc(e.origin * 1000)}</td>
                            <td>{e.type}</td>
                            <td>{fmt(e.price)}</td>
                            <td>{e.description}</td>
                          </tr>
                        ))}
                    </tbody>
                  </table>
                </div>
                <h3>Zonas calculadas · últimas 20</h3>
                <div className="monitor-table">
                  <table>
                    <thead>
                      <tr>
                        <th>Tipo</th>
                        <th>Confirmación UTC</th>
                        <th>Rango</th>
                        <th>Estado</th>
                      </tr>
                    </thead>
                    <tbody>
                      {structure.zones
                        .slice(-20)
                        .reverse()
                        .map((z) => (
                          <tr key={z.id}>
                            <td>{z.type}</td>
                            <td>{utc(z.time * 1000)}</td>
                            <td>
                              {fmt(z.low)} — {fmt(z.high)}
                            </td>
                            <td>{z.status}</td>
                          </tr>
                        ))}
                    </tbody>
                  </table>
                </div>
              </>
            ) : (
              <p>
                Activa Mostrar estructura y aplica la configuración para
                calcular los módulos.
              </p>
            )}
            <details>
              <summary>Reglas y limitaciones</summary>
              <p>
                Swings: extremo estricto entre n barras izquierdas y derechas;
                los empates se descartan. Primera ruptura de swing por cierre:
                Ruptura. Ruptura posterior en la misma orientación: BOS;
                opuesta: CHoCH. Barrido: mecha atraviesa el swing sin que el
                cierre lo rompa, una vez por swing.
              </p>
              <p>
                FVG: hueco entre máximo/mínimo de la primera y tercera vela,
                confirmado al cerrar la tercera. Tocada al alcanzar el borde
                próximo; cubierta al alcanzar el lejano. Bloque: rango completo
                de la última vela de cuerpo opuesto en la ventana anterior a una
                ruptura; se publica al confirmar la ruptura. No presupone
                órdenes institucionales.
              </p>
              <p>
                Los huecos reinician swings/orientación y cortan zonas abiertas.
                Sesiones: rango de barras cerradas completamente dentro de la
                ventana UTC; se etiqueta parcial, sin afirmar cobertura íntegra.
                Máximo 2.000 cierres, 300 eventos y 100 zonas; la gráfica
                muestra las últimas 35 zonas y 80 marcas. Ampliar historial
                puede cambiar semillas y orientación.
              </p>
            </details>
          </>
        )}
        {panel === "levels" && (
          <>
            <label className="monitor-toggle">
              <input
                type="checkbox"
                checked={data.showLevels}
                onChange={(e) =>
                  setData({ ...data, showLevels: e.target.checked })
                }
              />
              Consultar velas diarias y semanales nativas
            </label>
            <p>
              REST Binance Spot · revisión cada 60 s mientras este panel está
              abierto. Precios en la divisa cotizada del par. El periodo actual
              es provisional; los pivotes usan el último periodo cerrado. Estos
              niveles son referencias actuales, no series históricas
              multi-temporalidad.
            </p>
            {data.showLevels &&
              (
                [
                  ["Diario", levels.daily],
                  ["Semanal", levels.weekly],
                ] as const
              ).map(([name, q]) => {
                const prior = priorLevels(q.data ?? []),
                  current = q.data?.at(-1);
                return (
                  <section className="levels-card" key={name}>
                    <h3>
                      {name} ·{" "}
                      {q.isFetching
                        ? "Actualizando…"
                        : q.data
                          ? "Datos reales"
                          : "Esperando datos"}
                    </h3>
                    {q.error && (
                      <p className="negative" role="alert">
                        {q.error.message} · Los valores conservados pueden estar
                        desactualizados.
                      </p>
                    )}
                    {q.dataUpdatedAt > 0 && (
                      <p>
                        Consulta: {utc(q.dataUpdatedAt)} · fuente Binance Spot
                      </p>
                    )}
                    {current && (
                      <p>
                        Última vela: {utc(current.time * 1000)} ·{" "}
                        {current.closed
                          ? "cerrada"
                          : "en formación, provisional"}{" "}
                        · H {fmt(current.high)} / L {fmt(current.low)}
                      </p>
                    )}
                    {prior ? (
                      <>
                        <p>
                          Periodo cerrado usado: {utc(prior.bar.time * 1000)} ·
                          cierre {utc(prior.bar.closeTime)}
                        </p>
                        <div className="monitor-stats">
                          {[
                            ["Máximo", prior.bar.high],
                            ["Mínimo", prior.bar.low],
                            ["P", prior.p],
                            ["R1", prior.r1],
                            ["S1", prior.s1],
                            ["R2", prior.r2],
                            ["S2", prior.s2],
                          ].map(([k, v]) => (
                            <span key={k}>
                              <small>{k}</small>
                              <b>{fmt(v as number)}</b>
                            </span>
                          ))}
                        </div>
                      </>
                    ) : (
                      <p>No hay un periodo cerrado disponible.</p>
                    )}
                    <button
                      onClick={() => void q.refetch()}
                      disabled={q.isFetching}
                    >
                      Actualizar {name.toLowerCase()}
                    </button>
                  </section>
                );
              })}
            <details>
              <summary>Fórmulas de pivotes clásicos</summary>
              <p>
                P = (H + L + C) / 3; R1 = 2P − L; S1 = 2P − H; R2 = P + H − L;
                S2 = P − H + L. Se utiliza exclusivamente la última vela cerrada
                de cada intervalo nativo. No son predicciones.
              </p>
            </details>
          </>
        )}
      </dialog>
    </>
  );
}
