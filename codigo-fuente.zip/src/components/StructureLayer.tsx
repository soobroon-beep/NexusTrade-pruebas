import { useEffect, useRef, useState } from "react";
import type { IChartApi, Logical } from "lightweight-charts";
import type { Candle } from "../domain/types";
import { timeIndex, type PriceSeries } from "./DrawingLayer";
import type { StructureConfig, StructureResult } from "../structure/engine";
export function StructureLayer({
  api,
  series,
  candles,
  result,
  config,
}: {
  api: IChartApi;
  series: PriceSeries;
  candles: Candle[];
  result: StructureResult;
  config: StructureConfig;
}) {
  const latest = useRef({ candles, result, config });
  latest.current = { candles, result, config };
  const [view, setView] = useState<{
    width: number;
    height: number;
    zones: {
      id: string;
      x: number;
      y: number;
      width: number;
      height: number;
      color: string;
      text: string;
    }[];
    events: { id: string; x: number; y: number; color: string; text: string }[];
    levels: { y: number; text: string; color: string }[];
  }>({ width: 0, height: 0, zones: [], events: [], levels: [] });
  useEffect(() => {
    let frame = 0,
      stopped = false,
      last = "";
    const update = () => {
      if (stopped) return;
      try {
        const { candles, result, config } = latest.current,
          width = api.timeScale().width(),
          height = api.panes()[0]?.getHeight() ?? 0;
        const x = (time: number) =>
            api
              .timeScale()
              .logicalToCoordinate(timeIndex(time, candles) as Logical) ??
            -99999,
          y = (p: number) => series.priceToCoordinate(p) ?? -99999;
        const zones = result.zones
          .filter((z) =>
            z.type === "FVG"
              ? config.fvg
              : z.type === "OB"
                ? config.blocks
                : config.session,
          )
          .slice(-35)
          .map((z) => {
            const left = x(z.time),
              right = x(z.end);
            return {
              id: z.id,
              x: Math.max(-100, left),
              y: y(z.high),
              width: Math.max(
                3,
                Math.min(width + 100, right) - Math.max(-100, left),
              ),
              height: Math.max(2, y(z.low) - y(z.high)),
              color:
                z.type === "Sesión"
                  ? "#b79cee"
                  : z.direction === 1
                    ? "#46d5ae"
                    : "#f07583",
              text: `${z.type} · ${z.status}`,
            };
          })
          .filter((z) => z.x < width && z.y + z.height >= 0 && z.y < height);
        const events = result.events
          .filter((e) =>
            e.type === "SH" || e.type === "SL"
              ? config.swings
              : e.type === "Barrido"
                ? config.sweeps
                : config.breaks,
          )
          .slice(-80)
          .map((e) => ({
            id: e.id,
            x: x(e.time),
            y: y(e.price),
            color: e.direction === 1 ? "#46d5ae" : "#f07583",
            text: e.type,
          }))
          .filter((e) => e.x >= 0 && e.x < width && e.y >= 0 && e.y < height);
        const levels = [
          ...(result.support !== undefined
            ? [
                {
                  y: y(result.support),
                  text: "Swing soporte",
                  color: "#46d5ae",
                },
              ]
            : []),
          ...(result.resistance !== undefined
            ? [
                {
                  y: y(result.resistance),
                  text: "Swing resistencia",
                  color: "#f07583",
                },
              ]
            : []),
        ];
        const next = { width, height, zones, events, levels },
          signature = JSON.stringify(next);
        if (signature !== last) {
          last = signature;
          setView(next);
        }
      } catch {
        /* Chart teardown ends the frame loop on cleanup. */
      }
      frame = requestAnimationFrame(update);
    };
    update();
    return () => {
      stopped = true;
      cancelAnimationFrame(frame);
    };
  }, [api, series]);
  return (
    <svg
      className="structure-layer"
      aria-label="Estructura calculada sobre velas cerradas"
      width={view.width}
      height={view.height}
      style={{ overflow: "hidden" }}
    >
      {view.zones.map((z) => (
        <g key={z.id}>
          <rect
            x={z.x}
            y={z.y}
            width={z.width}
            height={z.height}
            fill={z.color + "12"}
            stroke={z.color + "60"}
          />
          <text x={z.x + 4} y={Math.max(12, z.y + 12)} fill={z.color}>
            {z.text}
          </text>
        </g>
      ))}
      {config.swings &&
        view.levels.map((l) => (
          <g key={l.text}>
            <line
              x1={0}
              x2={view.width}
              y1={l.y}
              y2={l.y}
              stroke={l.color + "70"}
              strokeDasharray="4 6"
            />
            <text x={8} y={l.y - 5} fill={l.color}>
              {l.text}
            </text>
          </g>
        ))}
      {view.events.map((e) => (
        <g key={e.id}>
          <circle cx={e.x} cy={e.y} r={3} fill={e.color} />
          <text x={e.x + 5} y={e.y - 6} fill={e.color}>
            {e.text}
          </text>
        </g>
      ))}
    </svg>
  );
}
