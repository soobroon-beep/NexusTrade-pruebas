import { newId } from "../domain/id";
import { useEffect, useRef, useState } from "react";
import { useAnalysis } from "../state/analysis";
import { useWorkspace } from "../state/workspace";
import {
  registry,
  kinds,
  newIndicator,
  indicatorSchema,
  parameterLabels,
  type IndicatorConfig,
  type IndicatorKind,
} from "../indicators/registry";
import {
  toolNames,
  drawingSchema,
  type DrawingTool,
  type Drawing,
} from "../drawings/model";
import { bundleSchema, parseBundle, templateSchema } from "../storage/analysis";
function exportFile(name: string, data: unknown) {
  const url = URL.createObjectURL(
    new Blob([JSON.stringify(data, null, 2)], { type: "application/json" }),
  );
  const a = document.createElement("a");
  a.href = url;
  a.download = name;
  a.click();
  setTimeout(() => URL.revokeObjectURL(url), 500);
}
export function AnalysisWorkbench({
  marketKey,
  tool,
  onTool,
  selected,
  onSelected,
}: {
  marketKey: string;
  tool: DrawingTool | null;
  onTool: (t: DrawingTool | null) => void;
  selected: string | null;
  onSelected: (id: string | null) => void;
}) {
  const { analysis, setAnalysis, setDrawings, undo, redo, histories, warning } =
    useAnalysis();
  const { workspace, update } = useWorkspace();
  const [panel, setPanel] = useState<
    "indicators" | "drawings" | "templates" | null
  >(null);
  const [kind, setKind] = useState<IndicatorKind>("sma");
  const [error, setError] = useState("");
  const dialog = useRef<HTMLDialogElement>(null);
  const drawings = analysis.setup.drawings[marketKey] ?? [];
  const changeIndicators = (indicators: IndicatorConfig[]) =>
    setAnalysis({ ...analysis, setup: { ...analysis.setup, indicators } });
  const changeDrawing = (drawing: Drawing) =>
    setDrawings(
      marketKey,
      drawings.map((d) => (d.id === drawing.id ? drawing : d)),
    );
  useEffect(() => {
    if (panel) dialog.current?.showModal();
    else dialog.current?.close();
    setError("");
  }, [panel]);
  useEffect(() => {
    const key = (e: KeyboardEvent) => {
      if ((e.target as HTMLElement).closest("input,textarea,select,dialog"))
        return;
      if (e.key === "Escape") {
        onTool(null);
        onSelected(null);
      }
      if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === "z") {
        e.preventDefault();
        if (e.shiftKey) redo(marketKey);
        else undo(marketKey);
      }
      if (e.key === "Delete" && selected) {
        const state = useAnalysis.getState();
        const items = state.analysis.setup.drawings[marketKey] ?? [];
        if (!items.find((d) => d.id === selected)?.locked) {
          state.setDrawings(
            marketKey,
            items.filter((d) => d.id !== selected),
          );
          onSelected(null);
        }
      }
    };
    window.addEventListener("keydown", key);
    return () => window.removeEventListener("keydown", key);
  }, [marketKey, selected, onTool, onSelected, undo, redo]);
  const addTemplate = () => {
    if (analysis.templates.length >= 20) {
      setError("Máximo 20 plantillas.");
      return;
    }
    const name = prompt("Nombre de la plantilla")?.trim();
    if (!name) return;
    try {
      const template = templateSchema.parse({
        id: newId(),
        name,
        updatedAt: Date.now(),
        workspace,
        setup: analysis.setup,
      });
      setAnalysis({
        ...analysis,
        templates: [...analysis.templates, template],
      });
    } catch {
      setError("Nombre de 1 a 60 caracteres.");
    }
  };
  return (
    <>
      <div className="analysis-toolbar">
        <button onClick={() => setPanel("indicators")}>
          ƒx Indicadores <span>{analysis.setup.indicators.length}</span>
        </button>
        <select
          aria-label="Herramienta de dibujo"
          value={tool ?? ""}
          onChange={(e) => {
            onTool((e.target.value as DrawingTool) || null);
            onSelected(null);
          }}
        >
          <option value="">Cursor / seleccionar</option>
          {Object.entries(toolNames).map(([key, name]) => (
            <option key={key} value={key}>
              {name}
            </option>
          ))}
        </select>
        <button onClick={() => setPanel("drawings")}>
          Objetos ({drawings.length})
        </button>
        <button
          disabled={!histories[marketKey]?.past.length}
          onClick={() => undo(marketKey)}
          title="Ctrl+Z"
        >
          Deshacer
        </button>
        <button
          disabled={!histories[marketKey]?.future.length}
          onClick={() => redo(marketKey)}
          title="Ctrl+Mayús+Z"
        >
          Rehacer
        </button>
        <button onClick={() => setPanel("templates")}>Plantillas</button>
      </div>
      {tool && (
        <div className="drawing-help">
          {toolNames[tool]} ·{" "}
          {["horizontal", "vertical", "text"].includes(tool)
            ? "1 clic"
            : ["channel", "extension", "long", "short"].includes(tool)
              ? "3 clics"
              : "2 clics"}{" "}
          en el panel de precio.{" "}
          {["long", "short"].includes(tool)
            ? "Entrada, stop y objetivo."
            : tool === "channel"
              ? "Inicio, final y separación."
              : tool === "extension"
                ? "Origen, impulso y retroceso."
                : ""}{" "}
          Esc cancela.
        </div>
      )}
      {!!analysis.setup.indicators.length && (
        <div className="indicator-chips">
          {analysis.setup.indicators.map((i) => (
            <button
              key={i.id}
              onClick={() => setPanel("indicators")}
              style={{ color: i.visible ? i.color : "#6b7c90" }}
            >
              {registry[i.kind].name}{" "}
              {registry[i.kind].fields.map((f) => i.params[f]).join(" / ")}{" "}
              {!i.visible ? "(oculto)" : ""}
            </button>
          ))}
        </div>
      )}
      {warning && (
        <div role="alert" className="data-warning">
          {warning}
        </div>
      )}
      <dialog
        className="analysis-dialog"
        ref={dialog}
        onCancel={() => setPanel(null)}
        aria-labelledby="analysis-title"
        onClick={(e) => {
          if (e.target === dialog.current) setPanel(null);
        }}
      >
        <header className="dialog-header">
          <h2 id="analysis-title">
            {panel === "indicators"
              ? "Indicadores nativos"
              : panel === "drawings"
                ? "Objetos del gráfico"
                : "Plantillas de análisis"}
          </h2>
          <button onClick={() => setPanel(null)} aria-label="Cerrar análisis">
            ✕
          </button>
        </header>
        <div className="analysis-content">
          {error && (
            <p role="alert" className="negative">
              {error}
            </p>
          )}
          {panel === "indicators" && (
            <>
              <div className="analysis-add">
                <select
                  aria-label="Indicador para añadir"
                  value={kind}
                  onChange={(e) => setKind(e.target.value as IndicatorKind)}
                >
                  {kinds.map((k) => (
                    <option key={k} value={k}>
                      {registry[k].name}
                    </option>
                  ))}
                </select>
                <button
                  className="primary-button"
                  disabled={analysis.setup.indicators.length >= 16}
                  onClick={() =>
                    changeIndicators([
                      ...analysis.setup.indicators,
                      newIndicator(kind),
                    ])
                  }
                >
                  Añadir
                </button>
              </div>
              <p className="muted">
                Hasta 16 instancias. Las señales de la vela abierta son
                provisionales. Sin suficientes barras, la serie no se dibuja.
              </p>
              {analysis.setup.indicators.map((config, index) => (
                <IndicatorEditor
                  key={
                    config.id +
                    JSON.stringify(config.params) +
                    config.color +
                    config.width +
                    config.height
                  }
                  config={config}
                  onApply={(value) =>
                    changeIndicators(
                      analysis.setup.indicators.map((i) =>
                        i.id === config.id ? value : i,
                      ),
                    )
                  }
                  onDelete={() =>
                    changeIndicators(
                      analysis.setup.indicators.filter(
                        (i) => i.id !== config.id,
                      ),
                    )
                  }
                  onMove={() => {
                    const items = [...analysis.setup.indicators];
                    [items[index - 1], items[index]] = [
                      items[index],
                      items[index - 1],
                    ];
                    changeIndicators(items);
                  }}
                  canMove={index > 0}
                />
              ))}
            </>
          )}
          {panel === "drawings" && (
            <>
              <p className="muted">
                {marketKey} · selecciona un objeto o arrastra sus anclas en el
                gráfico. Objetos bloqueados sólo permiten desbloqueo y
                visibilidad.
              </p>
              {!drawings.length && (
                <p>
                  Elige una herramienta en la barra y marca sus puntos sobre la
                  gráfica.
                </p>
              )}
              {drawings.map((d) => (
                <section
                  className={
                    "analysis-card " + (selected === d.id ? "focused" : "")
                  }
                  key={d.id}
                >
                  <div className="analysis-card-heading">
                    <button
                      onClick={() => {
                        onSelected(d.id);
                        setPanel(null);
                      }}
                    >
                      {toolNames[d.tool]} {d.text}
                    </button>
                    <div>
                      <button
                        onClick={() =>
                          changeDrawing({ ...d, visible: !d.visible })
                        }
                      >
                        {d.visible ? "Ocultar" : "Mostrar"}
                      </button>
                      <button
                        onClick={() =>
                          changeDrawing({ ...d, locked: !d.locked })
                        }
                      >
                        {d.locked ? "Desbloquear" : "Bloquear"}
                      </button>
                      <button
                        disabled={d.locked || drawings.length >= 100}
                        onClick={() =>
                          setDrawings(marketKey, [
                            ...drawings,
                            {
                              ...d,
                              id: newId(),
                              points: d.points.map((p) => ({
                                ...p,
                                price: p.price * 1.002,
                              })),
                            },
                          ])
                        }
                      >
                        Duplicar
                      </button>
                      <button
                        disabled={d.locked}
                        onClick={() =>
                          setDrawings(
                            marketKey,
                            drawings.filter((x) => x.id !== d.id),
                          )
                        }
                      >
                        Eliminar
                      </button>
                    </div>
                  </div>
                  <DrawingEditor
                    key={JSON.stringify(d)}
                    drawing={d}
                    onApply={changeDrawing}
                  />
                </section>
              ))}
            </>
          )}
          {panel === "templates" && (
            <>
              <p>
                Una plantilla guarda símbolo, temporalidad, listas, paneles,
                indicadores y dibujos. Aplicarla reemplaza el espacio actual; la
                colección de plantillas se conserva.
              </p>
              <div className="analysis-add">
                <button className="primary-button" onClick={addTemplate}>
                  Guardar plantilla actual
                </button>
                <button
                  onClick={() =>
                    exportFile("cripto-chart-workspace-v2.json", {
                      version: 2,
                      workspace,
                      analysis,
                    })
                  }
                >
                  Exportar espacio completo
                </button>
              </div>
              <label className="import-button">
                Importar plantilla o espacio
                <input
                  type="file"
                  accept=".json"
                  onChange={async (e) => {
                    const file = e.target.files?.[0];
                    if (!file) return;
                    try {
                      if (file.size > 5_000_000)
                        throw new Error(
                          "Archivo demasiado grande (máximo 5 MB).",
                        );
                      const raw = JSON.parse(await file.text());
                      const template = templateSchema.safeParse(raw);
                      if (template.success) {
                        if (analysis.templates.length >= 20)
                          throw new Error("Máximo 20 plantillas.");
                        setAnalysis({
                          ...analysis,
                          templates: [
                            ...analysis.templates,
                            { ...template.data, id: newId() },
                          ],
                        });
                      } else {
                        const bundle = bundleSchema.parse(parseBundle(raw));
                        if (
                          confirm(
                            "¿Restaurar este espacio? Se reemplazarán los indicadores, dibujos y listas actuales.",
                          )
                        ) {
                          setAnalysis(bundle.analysis);
                          update(bundle.workspace);
                        }
                      }
                      setError("");
                    } catch (err) {
                      setError(
                        err instanceof Error
                          ? err.message
                          : "Archivo inválido.",
                      );
                    }
                    e.target.value = "";
                  }}
                />
              </label>
              {analysis.templates.map((t) => (
                <section className="analysis-card" key={t.id}>
                  <b>{t.name}</b>
                  <p className="muted">
                    {t.workspace.symbol} · {t.workspace.interval} ·{" "}
                    {t.setup.indicators.length} indicadores ·{" "}
                    {new Date(t.updatedAt).toLocaleString("es-MX")}
                  </p>
                  <div className="template-actions">
                    <button
                      onClick={() => {
                        if (
                          confirm(
                            "¿Aplicar la plantilla y reemplazar el espacio actual?",
                          )
                        ) {
                          setAnalysis({ ...analysis, setup: t.setup });
                          update(t.workspace);
                          onSelected(null);
                          onTool(null);
                          setPanel(null);
                        }
                      }}
                    >
                      Aplicar
                    </button>
                    <button
                      onClick={() => {
                        const name = prompt("Nuevo nombre", t.name)?.trim();
                        if (name && name.length <= 60)
                          setAnalysis({
                            ...analysis,
                            templates: analysis.templates.map((x) =>
                              x.id === t.id
                                ? { ...x, name, updatedAt: Date.now() }
                                : x,
                            ),
                          });
                      }}
                    >
                      Renombrar
                    </button>
                    <button
                      disabled={analysis.templates.length >= 20}
                      onClick={() =>
                        setAnalysis({
                          ...analysis,
                          templates: [
                            ...analysis.templates,
                            {
                              ...t,
                              id: newId(),
                              name: (t.name + " copia").slice(0, 60),
                              updatedAt: Date.now(),
                            },
                          ],
                        })
                      }
                    >
                      Duplicar
                    </button>
                    <button
                      onClick={() =>
                        exportFile("plantilla-" + t.id + ".json", t)
                      }
                    >
                      Exportar
                    </button>
                    <button
                      onClick={() => {
                        if (confirm("¿Eliminar esta plantilla?"))
                          setAnalysis({
                            ...analysis,
                            templates: analysis.templates.filter(
                              (x) => x.id !== t.id,
                            ),
                          });
                      }}
                    >
                      Eliminar
                    </button>
                  </div>
                </section>
              ))}
            </>
          )}
        </div>
      </dialog>
    </>
  );
}
function IndicatorEditor({
  config,
  onApply,
  onDelete,
  onMove,
  canMove,
}: {
  config: IndicatorConfig;
  onApply: (i: IndicatorConfig) => void;
  onDelete: () => void;
  onMove: () => void;
  canMove: boolean;
}) {
  const [error, setError] = useState("");
  const definition = registry[config.kind];
  return (
    <form
      className="analysis-card"
      onSubmit={(e) => {
        e.preventDefault();
        const fd = new FormData(e.currentTarget);
        const params = { ...config.params };
        for (const f of definition.fields) params[f] = Number(fd.get(f));
        const parsed = indicatorSchema.safeParse({
          ...config,
          params,
          color: fd.get("color"),
          width: Number(fd.get("width")),
          height: Number(fd.get("height") ?? config.height),
        });
        if (parsed.success) {
          onApply(parsed.data);
          setError("");
        } else setError(parsed.error.issues[0].message);
      }}
    >
      <div className="analysis-card-heading">
        <b>{definition.name}</b>
        <div>
          <button
            type="button"
            onClick={() => onApply({ ...config, visible: !config.visible })}
          >
            {config.visible ? "Ocultar" : "Mostrar"}
          </button>
          <button type="button" disabled={!canMove} onClick={onMove}>
            Subir
          </button>
          <button type="button" onClick={onDelete}>
            Eliminar
          </button>
        </div>
      </div>
      <p className="muted">{definition.description}</p>
      <div className="analysis-fields">
        {definition.fields.map((f) => (
          <label key={f}>
            {parameterLabels[f]}
            <input
              name={f}
              type="number"
              required
              min={f === "multiplier" ? 0.1 : 1}
              max={f === "multiplier" ? 20 : 500}
              step={f === "multiplier" ? 0.1 : 1}
              defaultValue={config.params[f]}
            />
          </label>
        ))}
        <label>
          Color
          <input name="color" type="color" defaultValue={config.color} />
        </label>
        <label>
          Grosor
          <select name="width" defaultValue={config.width}>
            {[1, 2, 3, 4].map((n) => (
              <option key={n}>{n}</option>
            ))}
          </select>
        </label>
        {definition.location === "pane" && (
          <label>
            Alto de panel
            <input
              type="number"
              name="height"
              min="90"
              max="300"
              required
              defaultValue={config.height}
            />
          </label>
        )}
      </div>
      {error && (
        <p role="alert" className="negative">
          {error}
        </p>
      )}
      <button className="primary-button" type="submit">
        Aplicar cambios
      </button>
    </form>
  );
}
function DrawingEditor({
  drawing: d,
  onApply,
}: {
  drawing: Drawing;
  onApply: (d: Drawing) => void;
}) {
  const [error, setError] = useState("");
  return (
    <form
      onSubmit={(e) => {
        e.preventDefault();
        const fd = new FormData(e.currentTarget);
        const points = d.points.map((p, i) => ({
          time: Date.parse(String(fd.get("time" + i)) + "Z") / 1000,
          price: Number(fd.get("price" + i)),
        }));
        const result = drawingSchema.safeParse({
          ...d,
          points,
          text: fd.get("text"),
          color: fd.get("color"),
          width: Number(fd.get("width")),
          dash: fd.has("dash"),
          extend: fd.has("extend"),
        });
        if (result.success) {
          onApply(result.data);
          setError("");
        } else setError("Revisa las coordenadas y los parámetros.");
      }}
    >
      <fieldset disabled={d.locked}>
        <div className="analysis-fields">
          <label>
            Etiqueta
            <input name="text" maxLength={100} defaultValue={d.text} />
          </label>
          <label>
            Color
            <input name="color" type="color" defaultValue={d.color} />
          </label>
          <label>
            Grosor
            <select name="width" defaultValue={d.width}>
              {[1, 2, 3, 4].map((n) => (
                <option key={n}>{n}</option>
              ))}
            </select>
          </label>
          <label>
            <input name="dash" type="checkbox" defaultChecked={d.dash} />{" "}
            Discontinua
          </label>
          {["trend", "fib"].includes(d.tool) && (
            <label>
              <input name="extend" type="checkbox" defaultChecked={d.extend} />{" "}
              Extender
            </label>
          )}
        </div>
        {d.points.map((p, i) => (
          <div className="analysis-fields" key={i}>
            <label>
              Ancla {i + 1} · fecha UTC
              <input
                type="datetime-local"
                step="1"
                name={"time" + i}
                required
                defaultValue={new Date(p.time * 1000)
                  .toISOString()
                  .slice(0, 19)}
              />
            </label>
            <label>
              Precio
              <input
                type="number"
                step="any"
                required
                name={"price" + i}
                defaultValue={p.price}
              />
            </label>
          </div>
        ))}
        <button type="submit">Guardar objeto</button>
      </fieldset>
      {error && (
        <p role="alert" className="negative">
          {error}
        </p>
      )}
    </form>
  );
}
