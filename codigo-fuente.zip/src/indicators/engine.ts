import type { Candle } from "../domain/types";
import { indicatorSchema, type IndicatorConfig } from "./registry";
type Smooth = { count: number; sum: number; value?: number };
type State = {
  windows: Record<string, number[]>;
  smooth: Record<string, Smooth>;
  v: Record<string, number>;
};
export type IndicatorRow = {
  time: number;
  values: (number | null)[];
  signal?: 1 | -1;
  closed: boolean;
  direction?: number;
};
const initial = (): State => ({ windows: {}, smooth: {}, v: {} });
function step(s: State, c: Candle, config: IndicatorConfig): IndicatorRow {
  const {
    period: p,
    fast,
    slow,
    signal,
    smooth,
    multiplier: m,
  } = config.params;
  const window = (key: string, x: number, n: number) => {
    const a = s.windows[key] ?? (s.windows[key] = []);
    a.push(x);
    if (a.length > n) a.shift();
    return a;
  };
  const sma = (key: string, x: number | undefined, n: number) => {
    if (x === undefined) return undefined;
    const a = window(key, x, n);
    return a.length === n ? a.reduce((a, b) => a + b, 0) / n : undefined;
  };
  const average = (
    key: string,
    x: number | undefined,
    n: number,
    alpha: number,
  ) => {
    if (x === undefined) return undefined;
    const v = s.smooth[key] ?? (s.smooth[key] = { count: 0, sum: 0 });
    if (v.value === undefined) {
      v.sum += x;
      v.count++;
      if (v.count === n) v.value = v.sum / n;
    } else v.value += alpha * (x - v.value);
    return v.value;
  };
  const ema = (key: string, x: number | undefined, n: number) =>
    average(key, x, n, 2 / (n + 1));
  const rma = (key: string, x: number | undefined, n: number) =>
    average(key, x, n, 1 / n);
  const prev = s.v.close;
  const tr =
    prev === undefined
      ? c.high - c.low
      : Math.max(
          c.high - c.low,
          Math.abs(c.high - prev),
          Math.abs(c.low - prev),
        );
  let values: (number | undefined)[] = [];
  let cross: 1 | -1 | undefined;
  let direction: number | undefined;
  switch (config.kind) {
    case "sma":
      values = [sma("main", c.close, p)];
      break;
    case "ema":
      values = [ema("main", c.close, p)];
      break;
    case "wma": {
      const a = window("main", c.close, p);
      values = [
        a.length === p
          ? a.reduce((sum, x, i) => sum + x * (i + 1), 0) / ((p * (p + 1)) / 2)
          : undefined,
      ];
      break;
    }
    case "vwap": {
      const day = Math.floor(c.time / 86400);
      if (s.v.day !== day) {
        s.v.day = day;
        s.v.pv = 0;
        s.v.volume = 0;
      }
      s.v.pv += ((c.high + c.low + c.close) / 3) * c.volume;
      s.v.volume += c.volume;
      values = [s.v.volume ? s.v.pv / s.v.volume : undefined];
      break;
    }
    case "bb": {
      const mean = sma("main", c.close, p);
      const a = s.windows.main;
      const dev =
        mean === undefined
          ? undefined
          : Math.sqrt(a.reduce((sum, x) => sum + (x - mean) ** 2, 0) / p);
      values = [
        mean,
        mean !== undefined && dev !== undefined ? mean + m * dev : undefined,
        mean !== undefined && dev !== undefined ? mean - m * dev : undefined,
      ];
      break;
    }
    case "atr":
      values = [rma("tr", tr, p)];
      break;
    case "rsi": {
      const gain = prev === undefined ? undefined : Math.max(0, c.close - prev);
      const loss = prev === undefined ? undefined : Math.max(0, prev - c.close);
      const g = rma("gain", gain, p),
        l = rma("loss", loss, p);
      values = [
        g === undefined || l === undefined
          ? undefined
          : g === 0 && l === 0
            ? 50
            : l === 0
              ? 100
              : 100 - 100 / (1 + g / l),
      ];
      break;
    }
    case "macd": {
      const a = ema("fast", c.close, fast),
        b = ema("slow", c.close, slow);
      const value = a !== undefined && b !== undefined ? a - b : undefined;
      const sig = ema("signal", value, signal);
      values = [
        value,
        sig,
        value !== undefined && sig !== undefined ? value - sig : undefined,
      ];
      break;
    }
    case "stochastic": {
      const h = window("high", c.high, p),
        l = window("low", c.low, p);
      const hi = Math.max(...h),
        lo = Math.min(...l);
      const raw =
        h.length === p
          ? hi === lo
            ? 50
            : (100 * (c.close - lo)) / (hi - lo)
          : undefined;
      const k = sma("k", raw, smooth);
      values = [k, sma("d", k, signal)];
      break;
    }
    case "volume":
      values = [c.volume];
      break;
    case "obv":
      s.v.obv =
        (s.v.obv ?? 0) +
        (prev === undefined
          ? 0
          : c.close > prev
            ? c.volume
            : c.close < prev
              ? -c.volume
              : 0);
      values = [s.v.obv];
      break;
    case "supertrend": {
      const atr = rma("tr", tr, p);
      if (atr === undefined) {
        values = [undefined];
        break;
      }
      const upper = (c.high + c.low) / 2 + m * atr,
        lower = (c.high + c.low) / 2 - m * atr;
      const fu =
        s.v.upper === undefined || upper < s.v.upper || prev > s.v.upper
          ? upper
          : s.v.upper;
      const fl =
        s.v.lower === undefined || lower > s.v.lower || prev < s.v.lower
          ? lower
          : s.v.lower;
      direction =
        s.v.direction === undefined
          ? -1
          : s.v.direction === -1
            ? c.close > fu
              ? 1
              : -1
            : c.close < fl
              ? -1
              : 1;
      s.v.upper = fu;
      s.v.lower = fl;
      s.v.direction = direction;
      values = [direction === 1 ? fl : fu];
      break;
    }
    case "cross": {
      const a = sma("fast", c.close, fast),
        b = sma("slow", c.close, slow);
      if (a !== undefined && b !== undefined) {
        const difference = a - b;
        if (s.v.difference !== undefined) {
          if (difference > 0 && s.v.difference <= 0) cross = 1;
          if (difference < 0 && s.v.difference >= 0) cross = -1;
        }
        s.v.difference = difference;
      }
      values = [a, b];
      break;
    }
  }
  s.v.close = c.close;
  return {
    time: c.time,
    values: values.map((x) =>
      x !== undefined && Number.isFinite(x) ? x : null,
    ),
    signal: cross,
    closed: c.closed,
    direction,
  };
}
/** Keeps one rollback checkpoint before the open bar, rather than seeding recursive averages on every tick. */
export class IndicatorEngine {
  private state = initial();
  private checkpoint = initial();
  private bars: Candle[] = [];
  private rows: IndicatorRow[] = [];
  readonly config: IndicatorConfig;
  constructor(config: IndicatorConfig) {
    this.config = indicatorSchema.parse(config);
  }
  update(candles: Candle[]): IndicatorRow[] {
    let from = 0;
    if (
      this.bars.length > 0 &&
      candles.length >= this.bars.length &&
      candles.length <= this.bars.length + 1 &&
      this.bars.slice(0, -1).every((c, i) => c === candles[i]) &&
      candles[this.bars.length - 1]?.time === this.bars.at(-1)?.time
    ) {
      from = this.bars.length - 1;
      this.state = structuredClone(this.checkpoint);
      this.rows = this.rows.slice(0, from);
    } else {
      this.state = initial();
      this.rows = [];
    }
    for (let i = from; i < candles.length; i++) {
      if (i === candles.length - 1)
        this.checkpoint = structuredClone(this.state);
      this.rows.push(step(this.state, candles[i], this.config));
    }
    this.bars = candles;
    return this.rows;
  }
}
export function calculate(candles: Candle[], config: IndicatorConfig) {
  return new IndicatorEngine(config).update(candles);
}
