import { describe, it, expect } from "vitest";
import { calculate, IndicatorEngine } from "./engine";
import {
  newIndicator,
  kinds,
  indicatorSchema,
  type IndicatorKind,
  type Parameters,
} from "./registry";
import type { Candle } from "../domain/types";
const bars = (values: number[]): Candle[] =>
  values.map((close, i) => ({
    time: i * 60,
    open: close,
    high: close + 1,
    low: close - 1,
    close,
    volume: i + 1,
    closeTime: i * 60000 + 59999,
    closed: true,
    receivedAt: 1,
    source: "Binance Spot",
  }));
const config = (kind: IndicatorKind, params: Partial<Parameters> = {}) => {
  const c = newIndicator(kind);
  return { ...c, params: { ...c.params, ...params } };
};
const values = (
  kind: IndicatorKind,
  closes: number[],
  params: Partial<Parameters> = {},
) => calculate(bars(closes), config(kind, params)).map((r) => r.values);
describe("referencias numéricas independientes", () => {
  it("SMA tiene calentamiento explícito", () => {
    expect(values("sma", [1, 2, 3, 4, 5], { period: 3 })).toEqual([
      [null],
      [null],
      [2],
      [3],
      [4],
    ]);
  });
  it("EMA semilla SMA y factor 2/(n+1)", () => {
    const a = values("ema", [2, 4, 8, 16, 32], { period: 3 });
    expect(a[2][0]).toBeCloseTo(14 / 3);
    expect(a[3][0]).toBeCloseTo(31 / 3);
    expect(a[4][0]).toBeCloseTo(127 / 6);
  });
  it("WMA usa pesos 1..n", () => {
    expect(values("wma", [1, 2, 3], { period: 3 })[2][0]).toBeCloseTo(14 / 6);
  });
  it("Bollinger usa varianza poblacional", () => {
    const a = values("bb", [1, 2, 3], { period: 3, multiplier: 2 })[2];
    expect(a[0]).toBe(2);
    expect(a[1]).toBeCloseTo(2 + 2 * Math.sqrt(2 / 3));
    expect(a[2]).toBeCloseTo(2 - 2 * Math.sqrt(2 / 3));
  });
  it("VWAP reinicia en UTC y no divide por volumen cero", () => {
    const c = bars([10, 20, 30]);
    c[0].volume = 2;
    c[1].volume = 1;
    c[2].time = 86400;
    const result = calculate(c, config("vwap"));
    expect(result[1].values[0]).toBeCloseTo(40 / 3);
    expect(result[2].values[0]).toBe(30);
    expect(
      calculate([{ ...c[0], volume: 0 }], config("vwap"))[0].values[0],
    ).toBeNull();
  });
  it("ATR suaviza TR con Wilder", () => {
    const a = values("atr", [10, 12, 11, 15], { period: 3 });
    expect(a[2][0]).toBeCloseTo(7 / 3);
    expect(a[3][0]).toBeCloseTo(29 / 9);
  });
  it("RSI diferencia mercado plano, ganancias y pérdidas", () => {
    expect(
      values("rsi", [10, 11, 10, 12, 11], { period: 3 })[3][0],
    ).toBeCloseTo(75);
    expect(
      values("rsi", [10, 11, 10, 12, 11], { period: 3 })[4][0],
    ).toBeCloseTo(600 / 11);
    expect(values("rsi", [1, 1, 1], { period: 2 })[2][0]).toBe(50);
    expect(values("rsi", [1, 2, 3], { period: 2 })[2][0]).toBe(100);
    expect(values("rsi", [3, 2, 1], { period: 2 })[2][0]).toBe(0);
  });
  it("MACD y señal respetan sus calentamientos", () => {
    const a = values("macd", [1, 2, 3, 4, 5], { fast: 2, slow: 3, signal: 2 });
    expect(a[2]).toEqual([0.5, null, null]);
    expect(a[3]).toEqual([0.5, 0.5, 0]);
  });
  it("Stochastic K y D usan rango y SMA", () => {
    const a = values("stochastic", [1, 2, 3, 4], {
      period: 3,
      smooth: 1,
      signal: 2,
    });
    expect(a[2][0]).toBe(75);
    expect(a[3]).toEqual([75, 75]);
  });
  it("OBV empieza en cero, ignora cierres iguales", () => {
    expect(values("obv", [10, 11, 11, 9])).toEqual([[0], [2], [2], [-2]]);
  });
  it("volumen conserva unidades y valores", () => {
    expect(values("volume", [10, 11, 12])).toEqual([[1], [2], [3]]);
  });
  it("Supertrend sigue bandas finales y cambia alza", () => {
    const a = values("supertrend", [10, 11, 12, 20], {
      period: 2,
      multiplier: 1,
    });
    expect(a).toEqual([[null], [13], [13], [14.5]]);
  });
  it("cruces sólo ocurren en la transición, marcando cierre", () => {
    const a = calculate(
      bars([3, 2, 1, 4, 5, 6]),
      config("cross", { fast: 1, slow: 3 }),
    );
    expect(a.filter((r) => r.signal).map((r) => [r.time, r.signal])).toEqual([
      [180, 1],
    ]);
  });
});
describe("seguridad y actualización incremental", () => {
  it("valida parámetros y no genera valores con datos insuficientes", () => {
    expect(() => indicatorSchema.parse(config("sma", { period: 0 }))).toThrow();
    expect(() =>
      indicatorSchema.parse(config("macd", { fast: 30, slow: 10 })),
    ).toThrow();
    expect(calculate([], config("sma"))).toEqual([]);
  });
  it.each(kinds)(
    "%s: ticks, cierre y recarga de historial coinciden con cálculo completo",
    (kind) => {
      const c = bars(
        Array.from({ length: 90 }, (_, i) => 100 + Math.sin(i) * 8 + i / 10),
      );
      const cfg = config(kind);
      const engine = new IndicatorEngine(cfg);
      engine.update(c);
      const next = [
        ...c.slice(0, -1),
        { ...c.at(-1)!, close: c.at(-1)!.close + 0.5, closed: false },
      ];
      expect(engine.update(next)).toEqual(calculate(next, cfg));
      expect(engine.update(next)).toEqual(calculate(next, cfg));
      const appended = [...next, { ...c.at(-1)!, time: 90 * 60 }];
      expect(engine.update(appended)).toEqual(calculate(appended, cfg));
      const prepended = [{ ...c[0], time: -60 }, ...appended];
      expect(engine.update(prepended)).toEqual(calculate(prepended, cfg));
    },
  );
  it("no usa barras futuras", () => {
    for (const kind of kinds) {
      const cfg = config(kind);
      const c = bars(
        Array.from({ length: 80 }, (_, i) => 100 + Math.cos(i) * 8),
      );
      expect(calculate(c, cfg).slice(0, 50)).toEqual(
        calculate(c.slice(0, 50), cfg),
      );
    }
  });
});
