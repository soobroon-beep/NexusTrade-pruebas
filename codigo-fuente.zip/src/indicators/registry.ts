import { newId } from "../domain/id";
import { z } from "zod";
export const kinds = [
  "sma",
  "ema",
  "wma",
  "vwap",
  "bb",
  "atr",
  "rsi",
  "macd",
  "stochastic",
  "volume",
  "obv",
  "supertrend",
  "cross",
] as const;
export type IndicatorKind = (typeof kinds)[number];
const period = z.number().int().min(1).max(500);
export const parametersSchema = z.object({
  period: period.default(14),
  fast: period.default(12),
  slow: period.default(26),
  signal: period.default(9),
  smooth: period.default(3),
  multiplier: z.number().min(0.1).max(20).default(2),
});
export type Parameters = z.infer<typeof parametersSchema>;
export const indicatorSchema = z
  .object({
    id: z.string().min(1),
    kind: z.enum(kinds),
    params: parametersSchema,
    color: z.string().regex(/^#[0-9a-fA-F]{6}$/),
    width: z.number().int().min(1).max(4),
    visible: z.boolean(),
    height: z.number().int().min(90).max(300),
  })
  .refine(
    (x) => !["macd", "cross"].includes(x.kind) || x.params.fast < x.params.slow,
    "El período rápido debe ser menor que el lento",
  );
export type IndicatorConfig = z.infer<typeof indicatorSchema>;
export type Output = { name: string; style: "line" | "histogram" };
export type Definition = {
  name: string;
  description: string;
  location: "overlay" | "pane";
  fields: (keyof Parameters)[];
  defaults: Partial<Parameters>;
  outputs: Output[];
};
const line = (...names: string[]): Output[] =>
  names.map((name) => ({ name, style: "line" }));
export const registry: Record<IndicatorKind, Definition> = {
  sma: {
    name: "SMA",
    description: "Media móvil simple del cierre.",
    location: "overlay",
    fields: ["period"],
    defaults: { period: 20 },
    outputs: line("SMA"),
  },
  ema: {
    name: "EMA",
    description: "Media exponencial; semilla SMA.",
    location: "overlay",
    fields: ["period"],
    defaults: { period: 20 },
    outputs: line("EMA"),
  },
  wma: {
    name: "WMA",
    description: "Media ponderada lineal, mayor peso al cierre reciente.",
    location: "overlay",
    fields: ["period"],
    defaults: { period: 20 },
    outputs: line("WMA"),
  },
  vwap: {
    name: "VWAP · sesión UTC",
    description:
      "Precio típico ponderado por volumen. Reinicio a las 00:00 UTC. En intervalos de un día o mayores equivale al precio típico de cada barra.",
    location: "overlay",
    fields: [],
    defaults: {},
    outputs: line("VWAP"),
  },
  bb: {
    name: "Bollinger Bands",
    description: "SMA ± multiplicador × desviación estándar poblacional.",
    location: "overlay",
    fields: ["period", "multiplier"],
    defaults: { period: 20, multiplier: 2 },
    outputs: line("Media", "Superior", "Inferior"),
  },
  atr: {
    name: "ATR",
    description:
      "RMA de Wilder del rango verdadero. Primera TR = máximo − mínimo.",
    location: "pane",
    fields: ["period"],
    defaults: { period: 14 },
    outputs: line("ATR"),
  },
  rsi: {
    name: "RSI",
    description: "Ganancias/pérdidas con RMA de Wilder. Mercado plano: 50.",
    location: "pane",
    fields: ["period"],
    defaults: { period: 14 },
    outputs: line("RSI"),
  },
  macd: {
    name: "MACD",
    description: "EMA rápida − lenta; EMA de señal. Semillas SMA.",
    location: "pane",
    fields: ["fast", "slow", "signal"],
    defaults: { fast: 12, slow: 26, signal: 9 },
    outputs: [
      ...line("MACD", "Señal"),
      { name: "Histograma", style: "histogram" },
    ],
  },
  stochastic: {
    name: "Stochastic",
    description: "%K bruto suavizado con SMA; %D = SMA de %K. Rango plano: 50.",
    location: "pane",
    fields: ["period", "smooth", "signal"],
    defaults: { period: 14, smooth: 3, signal: 3 },
    outputs: line("%K", "%D"),
  },
  volume: {
    name: "Volumen",
    description: "Volumen de cada vela, en unidades del activo base.",
    location: "pane",
    fields: [],
    defaults: {},
    outputs: [{ name: "Volumen", style: "histogram" }],
  },
  obv: {
    name: "OBV",
    description:
      "Volumen acumulado según cambio del cierre; comienza en cero en la primera barra cargada.",
    location: "pane",
    fields: [],
    defaults: {},
    outputs: line("OBV"),
  },
  supertrend: {
    name: "Supertrend",
    description:
      "Bandas HL2 ± multiplicador × ATR Wilder, con seguimiento de dirección; inicia bajista.",
    location: "overlay",
    fields: ["period", "multiplier"],
    defaults: { period: 10, multiplier: 3 },
    outputs: line("Supertrend"),
  },
  cross: {
    name: "Cruce de medias SMA",
    description:
      "Dos medias simples. Flechas al cruzar, provisionales si la vela está abierta.",
    location: "overlay",
    fields: ["fast", "slow"],
    defaults: { fast: 20, slow: 50 },
    outputs: line("Rápida", "Lenta"),
  },
};
export function newIndicator(kind: IndicatorKind): IndicatorConfig {
  return indicatorSchema.parse({
    id: newId(),
    kind,
    params: parametersSchema.parse(registry[kind].defaults),
    color: "#67d9b7",
    width: 2,
    visible: true,
    height: 130,
  });
}
export const parameterLabels: Record<keyof Parameters, string> = {
  period: "Período",
  fast: "Rápida",
  slow: "Lenta",
  signal: "Señal / %D",
  smooth: "Suavizado %K",
  multiplier: "Multiplicador",
};
