import { create } from "zustand";
import {
  loadMonitor,
  saveMonitor,
  monitorSchema,
  type Monitor,
} from "../storage/monitor";
import type { AlertEvent } from "../alerts/model";
const initial = loadMonitor({ getItem: (key) => localStorage.getItem(key) });
function persist(data: Monitor) {
  try {
    saveMonitor(localStorage, data);
    return "";
  } catch {
    return "No se pudo guardar el monitor; exporta una copia.";
  }
}
export const useMonitor = create<{
  data: Monitor;
  warning: string;
  setData: (data: Monitor) => void;
  record: (event: AlertEvent) => void;
}>((set) => ({
  ...initial,
  setData: (data) => {
    const checked = monitorSchema.parse(data);
    set({ data: checked, warning: persist(checked) });
  },
  record: (event) =>
    set((s) => {
      if (s.data.events.some((e) => e.id === event.id)) return s;
      const rule = s.data.rules.find((r) => r.id === event.ruleId);
      if (!rule || rule.status !== "armed") return s;
      const data: Monitor = {
        ...s.data,
        events: [event, ...s.data.events].slice(0, 300),
        rules: s.data.rules.map((r) =>
          r.id === rule.id && r.frequency === "once"
            ? { ...r, status: "triggered" }
            : r,
        ),
      };
      return { data, warning: persist(data) };
    }),
}));
