import { create } from "zustand";
import {
  loadAnalysis,
  saveAnalysis,
  analysisSchema,
  type Analysis,
} from "../storage/analysis";
import { pushHistory, type Drawing, type History } from "../drawings/model";
const initial = loadAnalysis({ getItem: (key) => localStorage.getItem(key) });
type Store = {
  analysis: Analysis;
  warning: string;
  histories: Record<string, History>;
  setAnalysis: (data: Analysis) => void;
  setDrawings: (key: string, items: Drawing[]) => void;
  undo: (key: string) => void;
  redo: (key: string) => void;
};
function persist(data: Analysis) {
  try {
    saveAnalysis(localStorage, data);
    return "";
  } catch {
    return "No se pudo guardar el análisis. Exporta una copia para conservar los cambios.";
  }
}
export const useAnalysis = create<Store>((set) => ({
  analysis: initial.data,
  warning: initial.warning,
  histories: {},
  setAnalysis: (data) => {
    const checked = analysisSchema.parse(data);
    set((s) => ({
      analysis: checked,
      warning: persist(checked),
      histories:
        data.setup.drawings === s.analysis.setup.drawings ? s.histories : {},
    }));
  },
  setDrawings: (key, items) =>
    set((s) => {
      const data = {
        ...s.analysis,
        setup: {
          ...s.analysis.setup,
          drawings: { ...s.analysis.setup.drawings, [key]: items },
        },
      };
      analysisSchema.parse(data);
      return {
        analysis: data,
        warning: persist(data),
        histories: {
          ...s.histories,
          [key]: pushHistory(
            s.histories[key] ?? { past: [], future: [] },
            s.analysis.setup.drawings[key] ?? [],
          ),
        },
      };
    }),
  undo: (key) =>
    set((s) => {
      const h = s.histories[key];
      if (!h?.past.length) return s;
      const drawings = h.past.at(-1)!;
      const data = {
        ...s.analysis,
        setup: {
          ...s.analysis.setup,
          drawings: { ...s.analysis.setup.drawings, [key]: drawings },
        },
      };
      return {
        analysis: data,
        warning: persist(data),
        histories: {
          ...s.histories,
          [key]: {
            past: h.past.slice(0, -1),
            future: [s.analysis.setup.drawings[key] ?? [], ...h.future],
          },
        },
      };
    }),
  redo: (key) =>
    set((s) => {
      const h = s.histories[key];
      if (!h?.future.length) return s;
      const data = {
        ...s.analysis,
        setup: {
          ...s.analysis.setup,
          drawings: { ...s.analysis.setup.drawings, [key]: h.future[0] },
        },
      };
      return {
        analysis: data,
        warning: persist(data),
        histories: {
          ...s.histories,
          [key]: {
            past: [...h.past, s.analysis.setup.drawings[key] ?? []],
            future: h.future.slice(1),
          },
        },
      };
    }),
}));
