import { z } from "zod";
import { intervals, type MarketSymbol } from "../domain/types";
import type { Workspace } from "../storage/workspace";
export interface Tool {
  name: string;
  description: string;
  inputSchema: object;
  annotations: { readOnlyHint: boolean };
  execute: (input: unknown) => unknown;
}
export interface ModelContext {
  registerTool: (
    tool: Tool,
    options: { signal: AbortSignal },
  ) => void | Promise<void>;
}
const inputSchema = z
  .object({ symbol: z.string(), interval: z.enum(intervals) })
  .strict();
export function registerMarketTool(
  context: ModelContext,
  symbols: MarketSymbol[],
  update: (patch: Partial<Workspace>) => void,
) {
  const lifecycle = new AbortController();
  const tool: Tool = {
    name: "select_market",
    description:
      "Selecciona un par real de Binance Spot y una temporalidad; actualiza la gráfica visible y guarda esta preferencia local.",
    inputSchema: {
      type: "object",
      properties: {
        symbol: { type: "string" },
        interval: { type: "string", enum: intervals },
      },
      required: ["symbol", "interval"],
      additionalProperties: false,
    },
    annotations: { readOnlyHint: false },
    execute(input) {
      const parsed = inputSchema.parse(input);
      if (!symbols.some((s) => s.symbol === parsed.symbol))
        throw new Error("Símbolo no disponible en el catálogo de Binance Spot");
      update(parsed);
      return {
        symbol: parsed.symbol,
        interval: parsed.interval,
        status: "selected",
      };
    },
  };
  try {
    void Promise.resolve(
      context.registerTool(tool, { signal: lifecycle.signal }),
    ).catch(() => {});
  } catch {
    /* Optional API unavailable. */
  }
  return () => lifecycle.abort();
}
