import { it, expect, vi } from "vitest";
import { registerMarketTool, type Tool } from "./webmcp";
it("registra selección, valida entrada y libera el contexto", () => {
  let tool: Tool | undefined;
  let signal: AbortSignal | undefined;
  const update = vi.fn();
  const cleanup = registerMarketTool(
    {
      registerTool: (t, o) => {
        tool = t;
        signal = o.signal;
      },
    },
    [{ symbol: "BTCUSDT", baseAsset: "BTC", quoteAsset: "USDT" }],
    update,
  );
  expect(tool?.name).toBe("select_market");
  expect(tool?.annotations.readOnlyHint).toBe(false);
  expect(tool?.execute({ symbol: "BTCUSDT", interval: "1h" })).toEqual({
    symbol: "BTCUSDT",
    interval: "1h",
    status: "selected",
  });
  expect(update).toHaveBeenCalledWith({ symbol: "BTCUSDT", interval: "1h" });
  expect(() => tool?.execute({ symbol: "FAKE", interval: "1h" })).toThrow();
  expect(() =>
    tool?.execute({ symbol: "BTCUSDT", interval: "arbitrary" }),
  ).toThrow();
  expect(update).toHaveBeenCalledTimes(1);
  cleanup();
  expect(signal?.aborted).toBe(true);
});
