// @vitest-environment jsdom
import { beforeEach, it, expect } from "vitest";
import { useAnalysis } from "./analysis";
import { emptyAnalysis, analysisKey } from "../storage/analysis";
import type { Drawing } from "../drawings/model";
const item: Drawing = {
  id: "drawing-1",
  tool: "horizontal",
  points: [{ time: 60, price: 100 }],
  color: "#ffffff",
  width: 2,
  dash: false,
  extend: false,
  text: "",
  visible: true,
  locked: false,
};
beforeEach(() => {
  localStorage.clear();
  useAnalysis.setState({
    analysis: structuredClone(emptyAnalysis),
    histories: {},
    warning: "",
  });
});
it("deshacer y rehacer permanecen aislados por símbolo/temporalidad", () => {
  const s = useAnalysis.getState();
  s.setDrawings("BTCUSDT-1h", [item]);
  s.setDrawings("ETHUSDT-4h", [{ ...item, id: "eth" }]);
  s.undo("BTCUSDT-1h");
  expect(useAnalysis.getState().analysis.setup.drawings["BTCUSDT-1h"]).toEqual(
    [],
  );
  expect(
    useAnalysis.getState().analysis.setup.drawings["ETHUSDT-4h"],
  ).toHaveLength(1);
  s.redo("BTCUSDT-1h");
  expect(useAnalysis.getState().analysis.setup.drawings["BTCUSDT-1h"]).toEqual([
    item,
  ]);
  expect(
    JSON.parse(localStorage.getItem(analysisKey)!).setup.drawings["BTCUSDT-1h"],
  ).toEqual([item]);
});
it("una edición después de deshacer descarta el futuro", () => {
  const s = useAnalysis.getState();
  s.setDrawings("BTCUSDT-1h", [item]);
  s.undo("BTCUSDT-1h");
  s.setDrawings("BTCUSDT-1h", [{ ...item, text: "Nueva edición" }]);
  expect(useAnalysis.getState().histories["BTCUSDT-1h"].future).toEqual([]);
});
it("restaurar una plantilla reemplaza el análisis sin borrar la colección", () => {
  const template = {
    id: "t",
    name: "Prueba",
    updatedAt: 1,
    workspace: {
      version: 1 as const,
      symbol: "BTCUSDT",
      interval: "1h" as const,
      chartType: "candles" as const,
      volume: true,
      activeList: "main",
      lists: [{ id: "main", name: "Lista", symbols: ["BTCUSDT"] }],
      showWatchlist: true,
      showDetails: true,
    },
    setup: { indicators: [], drawings: { "BTCUSDT-1h": [item] } },
  };
  useAnalysis
    .getState()
    .setAnalysis({
      ...emptyAnalysis,
      templates: [template],
      setup: template.setup,
    });
  const state = useAnalysis.getState();
  expect(state.analysis.templates).toHaveLength(1);
  expect(state.analysis.setup.drawings["BTCUSDT-1h"]).toEqual([item]);
});
