import { create } from "zustand";
import {
  loadWorkspace,
  saveWorkspace,
  type Workspace,
} from "../storage/workspace";
const initial = loadWorkspace({ getItem: (key) => localStorage.getItem(key) });
export const useWorkspace = create<{
  workspace: Workspace;
  warning: string;
  update: (patch: Partial<Workspace>) => void;
}>((set) => ({
  workspace: initial.data,
  warning: initial.warning,
  update: (patch) =>
    set((state) => {
      const workspace = { ...state.workspace, ...patch };
      try {
        saveWorkspace(localStorage, workspace);
        return { workspace, warning: "" };
      } catch {
        return {
          workspace,
          warning:
            "No se pudieron guardar los cambios. Exporta tu espacio para evitar perderlos.",
        };
      }
    }),
}));
