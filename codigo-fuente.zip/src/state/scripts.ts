import { create } from "zustand";
import {
  loadScripts,
  saveScripts,
  scriptsSchema,
  type Scripts,
} from "../storage/scripts";
const initial = loadScripts({ getItem: (key) => localStorage.getItem(key) });
export const useScripts = create<{
  data: Scripts;
  warning: string;
  setData: (data: Scripts) => void;
}>((set) => ({
  ...initial,
  setData: (data) => {
    const checked = scriptsSchema.parse(data);
    let warning = "";
    try {
      saveScripts(localStorage, checked);
    } catch {
      warning = "No se pudo guardar. Exporta los scripts para conservarlos.";
    }
    set({ data: checked, warning });
  },
}));
