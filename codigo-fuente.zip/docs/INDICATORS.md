# Indicadores nativos: fórmulas y extensión

El registro está en `src/indicators/registry.ts`; el motor barra por barra en `engine.ts`. Las salidas de calentamiento son `null`, nunca cero de relleno. No hay acceso a barras futuras. Los cambios de la barra abierta restauran su estado anterior antes de recalcular; una barra cerrada aporta un único paso. Cambiar parámetros o anteponer histórico reconstruye el cálculo. La interfaz todavía envía las series calculadas completas a `setData`.

| Indicador | Convención implementada |
| --- | --- |
| SMA | Media aritmética de los últimos n cierres |
| EMA | Semilla SMA(n), alfa 2/(n+1) |
| WMA | Pesos 1..n, mayor peso al cierre reciente |
| VWAP | Suma(HLC3 × volumen)/suma(volumen), reinicio a medianoche UTC; volumen acumulado cero produce null |
| Bollinger | SMA ± multiplicador × desviación típica poblacional |
| ATR | True Range, primera barra high-low; suavizado Wilder, semilla SMA |
| RSI | Medias Wilder de cambios positivos/negativos; plano 50, sin pérdidas 100, sin ganancias 0 |
| MACD | EMA rápida menos lenta; señal EMA; histograma diferencia |
| Stochastic | K sobre máximos/mínimos n, suavizado SMA y D SMA; rango plano 50 |
| Volumen | Volumen base de la vela |
| OBV | Acumulación firmada por cambio de cierre, origen cero |
| Supertrend | Bandas HL2 ± multiplicador ATR con arrastre de bandas finales; dirección inicial bajista |
| Cruces | Dos SMA; señales en cruce de igualdad o lado opuesto al otro lado; barra abierta etiquetada provisional |

Los resultados recursivos dependen del comienzo del histórico cargado y sus semillas. El primer día de VWAP puede estar incompleto; OBV parte de la primera barra cargada. Los huecos de mercado siguen señalados por la capa de datos, sin interpolación; las ventanas cuentan barras disponibles. Una señal en la barra actual puede cambiar antes del cierre. No se promete paridad con un motor propietario ni que una señal sea rentable.

## Añadir un indicador

1. Añadir su identificador y metadatos al registro: descripción, ubicación, parámetros por defecto, campos editables y salidas con estilo de línea/histograma.
2. Extender el esquema Zod si requiere parámetros nuevos, con límites explícitos y validación cruzada.
3. Implementar el paso en el motor y su estado clonable: declarar semilla, calentamiento, datos ausentes, barra abierta y reinicios temporales.
4. Añadir referencias numéricas independientes y pruebas de ausencia de lookahead, sustitución de barra abierta y reconstrucción al anteponer historial.
5. Verificar que el renderizador genérico admite las salidas; extenderlo explícitamente si necesita otro tipo de visualización.

Los tests de `engine.test.ts` cubren los trece cálculos y comparan actualización incremental con reconstrucción. Esta suite no compara resultados con TradingView ni sustituye revisión de fórmulas externas.
