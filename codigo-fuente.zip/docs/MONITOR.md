# Monitor local · Fase 4

## Alertas

Abra Alertas → Nueva alerta, elija condición, frecuencia y expiración UTC. «Comprobar último cierre» calcula un resultado histórico sin registrar eventos. «Guardar y armar» establece la referencia inicial; el primer cierre ya cargado nunca dispara. Editar o rearmar reinicia esa referencia.

| Condición | Semántica |
| --- | --- |
| Precio | Cierre de la vela, en moneda cotizada |
| Variación | `(cierre / cierre anterior - 1) × 100`; no es variación de 24 horas |
| Indicador | Salida seleccionada de una instantánea de configuración nativa |
| Cruce de medias | Señal del indicador de dos SMA guardado en la regla |
| Dibujo | Cierre cruzando horizontal, tendencia o rayo guardado; respeta su dominio y extensión |
| Script | Umbral o presencia de salida no `na` ni transparente del mismo script activo |

Mayor/menor son comparaciones estrictas. Cruce ascendente exige valor anterior ≤ referencia anterior y actual > referencia actual; descendente invierte las desigualdades. Líneas se interpolan en índices de barras, igual que los dibujos del gráfico. Una regla conserva una copia de configuración, dibujo o script: cambios posteriores del objeto no modifican la alerta; edítela para adoptar cambios.

Los indicadores se calculan sobre el tramo cerrado consecutivo disponible; requieren calentamiento. Las reglas de script requieren idénticos identificador, código y parámetros activos, y esperan el Worker para el cierre. No ejecutan código adicional ni implementan `alert()`/`alertcondition()` de Pine. En modo presencia, un cero numérico también cuenta como salida presente. Las condiciones se evalúan sólo al cierre, nunca como señales intrabar.

Sólo se evalúa el símbolo/intervalo seleccionado con flujo en vivo y sin errores/huecos detectados. Al cambiar mercado, reconectar, recargar o perder cierres se reinicia la referencia: no se reproducen disparos históricos. Si faltan valores o hay huecos se omite el cálculo y se muestra el motivo. «Una vez» desarma al disparar; «Por barra» puede registrar cada cierre que cumpla. El identificador regla+barra impide duplicados en el historial local. La vigencia usa el reloj del dispositivo; tanto el instante de evaluación como el cierre deben estar antes de la expiración.

El historial muestra hora de detección y apertura de la vela en UTC por separado. No hay correo, sonido ni notificaciones del sistema. La pestaña debe permanecer abierta y ejecutándose; suspensión del navegador o sistema puede perder cierres. No hay coordinación entre pestañas: use una sola instancia como evaluador. No hay servicio continuo, sincronización entre dispositivos ni garantía con la pestaña cerrada.

## Estructura reproducible

Sólo se procesan velas cerradas. Swings y eventos se dibujan en su **momento de confirmación**, conservando el origen en la tabla; no se anticipan señales en la barra pivote.

- **SH/SL:** extremo estricto frente a L barras anteriores y R posteriores. Empates se descartan. Se confirma R barras después del origen. L/R entre 1 y 20, predeterminados 3/3.
- **Soporte/resistencia:** último swing confirmado aún no roto de cada dirección.
- **Ruptura:** cierre estrictamente más allá de un swing no roto. Primera ruptura define orientación; posteriores a favor se etiquetan BOS y opuestas CHoCH. Cada swing se rompe una vez. Son definiciones propias, no una clasificación universal.
- **Barrido:** mecha rebasa el swing y el cierre vuelve a su lado previo. Una señal por swing; dirección opuesta a la mecha.
- **FVG:** tres velas consecutivas; máximo de la primera menor al mínimo de la tercera (alcista), o mínimo de primera mayor al máximo de tercera (bajista). Ancho dividido por valor absoluto del cierre actual debe superar o igualar el porcentaje mínimo. Zona disponible al cierre de la tercera barra; no antes.
- **OB:** opcional. En una ruptura toma el rango completo de la última vela de cuerpo opuesto dentro del lookback (1–100). Aparece en la confirmación de ruptura, conserva el origen y no implica actividad institucional.
- **Zonas:** después de crearse, una mecha que alcanza el borde próximo marca «tocada»; al alcanzar el lejano, «cubierta» y termina su extensión. Un hueco termina las zonas pendientes como «interrumpida» y reinicia swings/orientación.
- **Sesión UTC:** rango descriptivo de velas cerradas completamente contenidas en la ventana horaria configurada, incluida medianoche. Siempre se etiqueta «rango parcial»: depende del histórico cargado y no certifica cobertura completa. Su rango acumulado se dibuja retrospectivamente sobre la sesión; no es una señal causal de entrada ni un nivel conocido al inicio.

Máximo 2000 velas para estructura, 300 eventos, 100 zonas y 10 sesiones. La gráfica muestra las últimas 80 marcas y 35 zonas; las tablas muestran subconjuntos recientes. Cargar historial puede cambiar extremos iniciales y calentamientos. Se recalcula el conjunto acotado; la optimización incremental queda pendiente. Las zonas no alteran la escala automática de precios. Pueden ocultarse módulos para reducir superposición de etiquetas.

## Niveles diarios y semanales

Consulta opcional de intervalos nativos `1d` y `1w` mediante el mismo adaptador Binance Spot. Se habilita con el panel abierto; refresco cada 60 segundos. Muestra fuente, fecha de consulta, periodos y unidad cotizada. H/L del periodo actual son provisionales hasta el cierre. Ante errores se informa y se distingue el dato conservado de una consulta actual.

Pivotes del último periodo cerrado: `P=(H+L+C)/3`, `R1=2P-L`, `S1=2P-H`, `R2=P+H-L`, `S2=P-H+L`. No son series históricas MTF, no habilitan `request.security`, ni incluyen interés abierto, funding, liquidaciones o capitalización.

## Persistencia y límites

Clave separada `cripto-chart-terminal.monitor.v1`, validación Zod, copia previa y lectura no destructiva ante corrupción. Hasta 40 reglas y 300 eventos. Exportar/importar monitor incluye reglas con sus instantáneas, historial, estructura y preferencia de niveles. Importación máxima 4 MB; conserva las reglas pausadas para evitar activaciones involuntarias. No activa scripts importados automáticamente.

Las plantillas de Fase 2 y las colecciones de scripts se exportan por separado. Eliminar una regla conserva sus eventos. Si el navegador rechaza el guardado, se muestra el fallo; el estado en memoria no implica persistencia. No hay backend, órdenes ni ejecución de operaciones financieras.
