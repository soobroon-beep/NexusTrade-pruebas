# Motor Pine parcial — entrega 0.3

Implementación original: lexer → parser de precedencia → AST/representación interna tipada y validada → intérprete barra por barra en un Web Worker. No convierte texto mediante sustituciones regulares, no usa IA para compilar y no usa `eval` ni `Function`. No hay afiliación con TradingView ni paridad completa con su motor.

## Flujo

Abra **Editor de scripts**, pegue código o importe `.pine`/`.txt`. Seleccione **Validar compatibilidad**, revise advertencias, ajuste los parámetros y ejecute **Vista previa**. Esta vista es una instantánea numérica sobre las velas cargadas; puede añadirse a la gráfica con **Añadir a la gráfica**. El script activo vuelve a calcularse con los datos nuevos. **Retirar script** cancela su trabajo y elimina sus salidas sin borrarlo de la colección.

El editor incluye resaltado, números de línea, diagnóstico de primera obstrucción con línea/columna y salto al texto, y sugerencias mediante Ctrl/Cmd+Espacio. No es un IDE completo. Guardar/duplicar no ejecuta scripts nuevos. Guardar cambios en uno activo lo desactiva hasta volver a aplicarlo. Cambiar el mercado invalida la vista previa; recibir una actualización de ese mercado no borra la instantánea.

Se guardan hasta 30 scripts y se ejecuta **uno a la vez**, con hasta 16 salidas. La revisión local aumenta al guardar cambios; no es la versión del lenguaje. Nombre, descripción, parámetros y modificación forman parte del registro. `original` conserva el texto inicial/importado al editar `source`. Las exportaciones de código y original son texto; la colección JSON contiene ambos. Importar una colección la valida y la deja desactivada. Los scripts tienen almacenamiento separado `scripts.v1` y copia `.backup`; no se incluyen todavía en las plantillas/archivos de espacio de las fases 1/2. Exporte la colección por separado. Las revisiones anteriores completas no se archivan individualmente.

## Matriz exacta

| Construcción | Alcance |
| --- | --- |
| `//@version=5`, `//@version=6` | Una declaración obligatoria. Rechazo de otras versiones |
| `indicator(title, shorttitle, overlay)` | Primera instrucción; título y opciones constantes; overlay false por defecto |
| `strategy(title, shorttitle, overlay)` | Sólo declaración de análisis visual, con advertencia. Sin backtest, órdenes ni `strategy.*` |
| `x = expresión`, `var x = expresión`, `x := expresión` | Variables globales, persistencia entre barras y reasignación; sin anotaciones explícitas `float`/`int`/etc. |
| `[m,s,h] = ta.macd(...)` | Tupla de exactamente tres nombres únicos; no arrays generales |
| `+ - * / %`, comparaciones, `and or not`, `?:` | Precedencia, comprobación básica de tipos; booleanos explícitos en condiciones |
| `variable[n]` | Entero literal 0–5000; no offsets negativos, dinámicos ni histórico de expresiones |
| `open high low close volume time bar_index` | Datos del activo y temporalidad seleccionados. `time` en milisegundos; `bar_index` desde la primera barra cargada |
| `hl2 hlc3 ohlc4 barstate.isconfirmed` | Promedios de OHLC y estado de cierre del proveedor |
| `input.int/float` | defval, title, minval, maxval, step constantes; int exige enteros |
| `input.bool/string` | defval y title constantes; string hasta 200 caracteres al ejecutar |
| `ta.sma/ema/rsi(source,length)` | Fuentes numéricas y periodo entero 1–500, constante durante cada ejecución |
| `ta.atr(length)` | True Range de OHLC y RMA Wilder |
| `ta.macd(source,fastlen,slowlen,siglen)` | EMAs, fastlen < slowlen; tres salidas |
| `ta.crossover/crossunder(source1,source2)` | Compara barra actual con anterior; primera barra false |
| `na(x)`, `nz(source,replacement)` | na prueba ausencia; nz sólo numérico, reemplazo 0 por defecto |
| `plot(series,title,color,linewidth,style)` | Serie numérica, línea o histograma; linewidth 1–4. Color por barra hexadecimal o constantes enumeradas |
| `hline(price,title,color,linewidth)` | Precio y metadatos constantes; no linestyle personalizado |
| `plotshape(series,title,style,location,color,text)` | Condición booleana; triangleup/down, circle, square; abovebar/belowbar |
| `plotchar(series,title,char,location,color)` | Un carácter, condición booleana, abovebar/belowbar; forma oculta y etiqueta de texto |

Las salidas gráficas son instrucciones globales independientes: no se pueden asignar sus identificadores ni usar `fill`. Constantes de color disponibles: aqua, blue, green, lime, red, orange, yellow, purple, white, gray, black, teal. No `color.new`. Títulos hasta 100 caracteres; texto de formas hasta 80. No desplazamiento de salidas, propiedades adicionales ni otros estilos. Las formas se anclan al máximo/mínimo de su barra y su ubicación visual usa el renderizador propio; no se promete identidad visual con TradingView.

**Rechazado explícitamente:** funciones del usuario, bloques `if/else`, bucles, continuaciones multilínea, arrays/objetos, anotaciones de tipo, imports, `varip`, `request.security` y otros MTF, `bgcolor`, `fill`, `plot.style_linebr`, órdenes, alertas, acceso DOM/red/almacenamiento y funciones desconocidas. Un error bloquea el script completo. El informe se detiene en la primera obstrucción; no elimina instrucciones ni adapta silenciosamente condiciones. Para adaptar un bloque condicional sencillo, calcule primero sus `ta.*` globales y exprese una selección de valores con `?:`; la adaptación debe ser explícita y volver a validarse.

## Semántica y diferencias

- Ejecución cronológica desde la primera barra disponible. Las variables históricas conservan el valor final de cada barra. Sin lectura futura. Sólo se calcula el dataset recibido, no todas las barras que el proveedor pudiera tener.
- En cada actualización se reconstruye el resultado completo en un Worker nuevo. Esto evita acumulación doble en la vela abierta y mantiene `var` entre barras, pero no entre ticks. No hay `varip` ni cálculo incremental del intérprete en esta entrega.
- `na` es ausencia, propagada en aritmética; dividir entre cero produce `na`. Datos fuera de rango producen error. SMA ignora fuentes ausentes y requiere n valores válidos. EMA inicia en el primer valor válido, con alfa 2/(n+1). RMA inicia con SMA(n), con alfa 1/n. Se mantienen resultados suavizados al recibir `na`.
- RSI usa cambios entre valores válidos, RMA de subidas/bajadas; sin cambios devuelve 50, sin pérdidas 100 y sin ganancias 0. ATR inicial usa high-low. MACD usa EMA desde el primer valor válido. **Estas semillas son distintas de las medias nativas de la Fase 2**, cuya EMA se inicializa con SMA.
- v5 propaga `na` en comparaciones/booleanos. v6 devuelve false al comparar con `na`, usa cortocircuito lógico y devuelve false para histórico booleano inexistente. `na(bool)` se admite como comprobación de ausencia (extensión del subconjunto, no paridad con el sistema de tipos de v6). No hay coerción implícita numérico→booleano, ni tipos int/float diferenciados. **Toda división es real, también con literales enteros en v5**; el informe advierte esta diferencia. Los literales decimales son admitidos; notación científica aún no.
- `ta.*` e `input.*` dentro de ramas condicionales, lado derecho de operadores lógicos o inicializadores `var` se rechazan. Deben calcularse de forma global en cada barra para que el historial no dependa del camino de ejecución.
- Los resultados dependen de cuánto histórico se haya cargado. Huecos no se rellenan; las ventanas cuentan valores disponibles. `barstate.isconfirmed` distingue barra cerrada y actual. Las formas en una barra abierta incluyen «provisional»; las líneas también pueden cambiar, indicado en la vista previa.
- Los metadatos y ciertos argumentos admiten sólo literales constantes; una expresión válida en Pine completo puede rechazarse aquí. Los periodos dinámicos se detectan al ejecutar y producen error, no un resultado aproximado.

## Aislamiento y límites

Texto importado nunca se evalúa como JavaScript. El intérprete resuelve un conjunto cerrado de nombres/operaciones; no expone capacidades del host. Aunque un Worker del navegador dispone de APIs propias, el lenguaje interpretado no tiene ninguna ruta para invocarlas. No se descargan scripts externos.

Límites por ejecución: 64.000 bytes de fuente, 8.000 tokens, 800 nodos, profundidad de parseo 48, hasta 10.000 barras, presupuesto de 2 millones de celdas calculado con nodos/instrucciones × barras y 2 millones de operaciones contabilizadas (incluidas sumas de ventanas). El límite de celdas es un presupuesto lógico, no una cuota exacta de bytes del navegador. El hilo principal termina el Worker a los 3 segundos; cancelar, cambiar contexto o desmontar también termina la instancia. Se ignoran respuestas obsoletas. No se ejecutan trabajos cuando no hay velas. Un script demasiado costoso muestra un diagnóstico y retira su resultado, sin sustituirlo por datos inventados.

## Pruebas y extensión

`runtime.test.ts` contiene referencias numéricas, ausencia de lookahead, barra abierta, estado persistente, diferencias v5/v6, errores sintácticos, nombres no permitidos y límites. `client.test.ts` verifica terminación, timeout y cancelación mediante Worker simulado. `useScript.test.tsx` cubre resultados tardíos al cambiar mercado; las pruebas del editor cubren importación, original intacto y la instantánea estable ante ticks.

Los ejemplos ejecutables están en `src/pine/examples.ts` y `examples/pine/`. Con cierres `[1,2,3,2,4,5]`, SMA(3) espera `[na,na,2,7/3,3,11/3]`; EMA(3) espera `[1,1.5,2.25,2.125,3.0625,4.03125]`. Los ejemplos MTF y de sintaxis deben fallar. Los fixtures de prueba no son cotizaciones de la aplicación.

Para ampliar: añadir gramática y nodos donde sea necesario; definir tipos/argumentos permitidos en el compilador; implementar semántica explícita sin acceso al host; limitar memoria/operaciones; añadir resultados de referencia y casos adversos; conectar salidas al renderizador; actualizar esta matriz antes de anunciar soporte.

Referencias primarias consultadas, no código copiado:
- https://www.tradingview.com/pine-script-docs/language/execution-model/
- https://www.tradingview.com/pine-script-docs/language/operators/
- https://www.tradingview.com/pine-script-docs/v5/language/execution-model/

La suite valida las reglas propias documentadas. No se ha comparado automáticamente con el motor propietario ni auditado externamente el aislamiento.
